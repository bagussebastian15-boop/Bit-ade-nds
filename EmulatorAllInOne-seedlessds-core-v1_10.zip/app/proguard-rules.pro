# ============================================================================
# Pengacakan & perlindungan anti-dekompilasi — Bit©ade / EmulatorAllInOne
# ============================================================================
# Tujuan: nama class/method/field diacak jadi huruf tak bermakna (a, b, c, ...),
# struktur paket diratakan jadi satu paket acak, dan kode mati dibuang supaya
# APK yang dibongkar (jadx/apktool) jauh lebih sulit dibaca atau dimodifikasi.
#
# PENTING: semua -keep di bawah ini WAJIB ada. Tanpanya aplikasi akan crash
# karena ada kode yang dipanggil lewat refleksi (ZeroTier, panggilan balik
# native→Java) atau lewat JNI (nama method native tidak boleh berubah).

# --- Pengacakan maksimal -----------------------------------------------
-repackageclasses ''
-allowaccessmodification
-optimizationpasses 5
-overloadaggressively
-flattenpackagehierarchy
-mergeinterfacesaggressively
-dontpreverify

# Hilangkan info baris asli di stack trace (lebih susah dipakai menelusuri
# balik ke kode sumber), tapi tetap tandai "SourceFile" generik agar crash
# tidak melempar NPE aneh di beberapa ROM Android lama.
-renamesourcefileattribute ""
-keepattributes !LineNumberTable,!LocalVariableTable,!LocalVariableTypeTable

# Buang semua log Logcat di build rilis: baik untuk performa, dan mencegah
# siapa pun yang mem-patch APK lalu menjalankannya dengan `adb logcat` untuk
# membaca alur kode lewat pesan log.
-assumenosideeffects class android.util.Log {
    public static *** v(...);
    public static *** d(...);
    public static *** i(...);
    public static *** w(...);
    public static *** e(...);
}

# ============================================================================
# KEEP — wajib, jangan dihapus
# ============================================================================

# Komponen Android yang dideklarasikan di manifest sudah otomatis dijaga oleh
# aturan bawaan AGP (proguard-android-optimize.txt + consumer rules), tapi
# ditegaskan lagi di sini untuk App/Activity milik proyek ini.
-keep class com.allinone.emulator.App

# Method/field yang ditandai @Keep (androidx.annotation) — dipakai di
# SeedlessBridge/SeedlessCore untuk fungsi `external fun` (JNI native).
# Aturan ini melengkapi consumer rule bawaan androidx.annotation agar pasti
# berlaku walau versi library berubah.
-keep @androidx.annotation.Keep class * { *; }
-keepclasseswithmembers class * {
    @androidx.annotation.Keep <methods>;
}
-keepclasseswithmembers class * {
    @androidx.annotation.Keep <fields>;
}

# Semua method native (JNI) di seluruh proyek — nama method native di sisi
# C/C++ (recon.c, seedless_native.c, dst.) di-hardcode lewat JNIEXPORT, jadi
# nama Java-nya TIDAK BOLEH diacak atau linker JNI akan gagal mencari symbol.
-keepclasseswithmembernames,includedescriptorclasses class * {
    native <methods>;
}

# ZeroTier SDK tertanam (opsional, hanya ikut bila zt-sdk/ tersedia saat build).
# ZtEngine.java memanggilnya lewat Class.forName(...) + refleksi (bukan import
# langsung), dan pustaka native libZeroTierOneJNI.so memanggil balik beberapa
# method Java di sini BY NAME lewat JNI — jadi seluruh paket harus dijaga utuh
# (nama class, nama method, urutan/tipe argumen) atau VPN akan langsung crash.
-keep class com.zerotier.sdk.** { *; }
-keepclassmembers class com.zerotier.sdk.** { *; }
-dontwarn com.zerotier.sdk.**

# LibretroDroid (GLRetroView dkk.) — wrapper JNI untuk core libretro (.so).
# Native code di libretrodroid memanggil balik ke beberapa method Kotlin lewat
# JNI by name, jadi paketnya dijaga utuh. Modul ini dibuild dari sumber
# (project(":libretrodroid")), bukan dependency biner, sehingga kena aturan
# -keep di app ini juga (R8 memproses seluruh modul yang digabung ke APK).
-keep class com.swordfish.libretrodroid.** { *; }
-dontwarn com.swordfish.libretrodroid.**

# ML Kit (OCR + terjemahan on-device): sebagian besar sudah membawa consumer
# rules sendiri, tapi beberapa model loader memakai refleksi untuk kelas
# proto internal — ditambahkan agar aman kalau versi library berubah.
-keep class com.google.mlkit.** { *; }
-keep class com.google.android.gms.internal.mlkit_** { *; }
-dontwarn com.google.mlkit.**
-dontwarn com.google.android.gms.internal.mlkit_**

# Enum (values()/valueOf() dipanggil lewat refleksi oleh banyak library,
# termasuk saat membaca pengaturan dari SharedPreferences via nama enum).
-keepclassmembers enum * {
    public static **[] values();
    public static ** valueOf(java.lang.String);
}

# Parcelable (dipakai lewat Intent antar-Activity, mis. EmulatorActivity).
-keepclassmembers class * implements android.os.Parcelable {
    public static final android.os.Parcelable$Creator *;
}

# Atribut yang dibutuhkan runtime untuk coroutine, refleksi Kotlin, dan
# exception chaining yang benar (jangan dihapus walau ukuran APK sedikit naik).
-keepattributes Signature, InnerClasses, EnclosingMethod, Exceptions, *Annotation*

# commons-compress / xz / junrar membaca beberapa class lewat nama (format
# arsip 7z/rar). Aman di-keep agar pembacaan ROM terkompresi tidak gagal diam-diam.
-dontwarn org.apache.commons.compress.**
-dontwarn org.tukaani.xz.**
-dontwarn com.github.junrar.**
-keep class org.apache.commons.compress.archivers.** { *; }
