package com.allinone.emulator.ui

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.view.KeyEvent
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import com.allinone.emulator.data.Settings
import com.allinone.emulator.input.KeyMap
import com.allinone.emulator.input.PadMap
import com.allinone.emulator.translate.TranslationEngine
import com.allinone.emulator.translate.VisionOcr

/** Dialog yang dipakai bersama oleh Library dan layar emulasi. */
object Menus {

    fun choose(ctx: Context, title: String, labels: List<String>, current: Int, onPick: (Int) -> Unit) {
        AlertDialog.Builder(ctx)
            .setTitle(title)
            .setSingleChoiceItems(labels.toTypedArray(), current) { d, which -> onPick(which); d.dismiss() }
            .setNegativeButton("Batal", null)
            .show()
    }

    internal fun pickInt(
        ctx: Context, title: String, values: List<Int>, current: Int, suffix: String, onPick: (Int) -> Unit
    ) = choose(ctx, title, values.map { "$it$suffix" }, values.indexOf(current)) { onPick(values[it]) }

    /** Filter gambar: (nama singkat, penjelasan untuk daftar pilihan). Indeks = Settings.shaderMode. */
    private val SHADERS = listOf(
        "halus" to "Halus (bilinear, bawaan): gambar lembut, piksel agak buram",
        "tajam" to "Tajam (sharp): tepi piksel tegas, huruf piksel lebih jelas dan lebih mudah dibaca OCR terjemahan",
        "composite" to "Composite (ala TV lama): SNES & Genesis memakai filter NTSC composite asli core; GBA & arcade memakai efek CRT lembut. Gambar lebih buram, kurang cocok untuk terjemahan"
    )

    /** Profil performa arcade: (nama singkat, penjelasan untuk daftar pilihan). */
    private val ARCADE_PERF = listOf(
        "standar" to "Standar (bawaan core)",
        "seimbang" to "Seimbang (tanpa frame dibuang; warna 16-bit & suara lebih ringan)",
        "ringan" to "Ringan (gambar digambar 1 dari tiap 2 frame; sprite ramai lebih lancar)",
        "maksimal" to "Maksimal (gambar digambar 1 dari tiap 3 frame; suara paling ringan)"
    )

    private fun engineLabel(s: Settings) =
        if (!s.translateOnline) "Offline (ML Kit)" else if (s.onlineEngine == 1) "Online (Groq)" else "Online (Google Translate)"

    private fun vpnName(t: Int) = when (t) { 1 -> "ZeroTier"; 2 -> "Tailscale"; else -> "VPN otomatis" }

    internal fun onOff(v: Boolean) = if (v) "aktif" else "mati"

    internal fun askText(ctx: Context, title: String, hintText: String, current: String, onOk: (String) -> Unit) {
        val et = android.widget.EditText(ctx).apply {
            setText(current); setHint(hintText); setSingleLine(true)
        }
        val box = android.widget.FrameLayout(ctx).apply {
            val m = (20 * ctx.resources.displayMetrics.density).toInt()
            setPadding(m, m / 2, m, 0)
            addView(et)
        }
        AlertDialog.Builder(ctx).setTitle(title).setView(box)
            .setPositiveButton("Simpan") { _, _ -> onOk(et.text.toString().trim()) }
            .setNegativeButton("Batal", null)
            .show()
    }

    const val GROQ_KEYS_URL = "https://console.groq.com/keys"

    /**
     * Minta API key Groq. Bila belum punya, tombol "Buka situs Groq" membuka halaman pendaftaran / pembuatan kunci di
     * browser; setelah kembali, dialog muncul lagi dengan isian terakhir. [onSaved] dipanggil hanya setelah kunci disimpan.
     * [show] memungkinkan pemanggil (mis. layar emulasi) menampilkan dialog dengan cara sendiri (menjeda game).
     * [allowEmpty] = true mengizinkan menyimpan kosong (menghapus kunci).
     */
    fun askGroqKey(
        ctx: Context, s: Settings, current: String = s.groqKey, allowEmpty: Boolean = false,
        show: (AlertDialog.Builder) -> Unit = { it.show() }, onSaved: () -> Unit
    ) {
        val et = android.widget.EditText(ctx).apply {
            setText(current); setHint("gsk_…"); setSingleLine(true)
        }
        val box = android.widget.FrameLayout(ctx).apply {
            val m = (20 * ctx.resources.displayMetrics.density).toInt()
            setPadding(m, m / 2, m, 0)
            addView(et)
        }
        show(AlertDialog.Builder(ctx)
            .setTitle("Masukkan API key Groq")
            .setMessage("Mesin Groq butuh API key. Belum punya? Ketuk \"Buka situs Groq\", daftar (gratis), lalu buat API key dan tempel di sini.")
            .setView(box)
            .setPositiveButton("Simpan") { _, _ ->
                val k = et.text.toString().trim()
                if (k.isEmpty() && !allowEmpty) {
                    SoundToast.makeText(ctx, "API key kosong, mesin tidak diubah", Toast.LENGTH_LONG).show()
                } else {
                    s.groqKey = k
                    onSaved()
                }
            }
            .setNeutralButton("Buka situs Groq") { _, _ ->
                try {
                    ctx.startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(GROQ_KEYS_URL))
                        .addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK))
                } catch (_: Exception) {
                    SoundToast.makeText(ctx, "Tidak bisa membuka browser. Buka $GROQ_KEYS_URL secara manual.", Toast.LENGTH_LONG).show()
                }
                askGroqKey(ctx, s, et.text.toString().trim(), allowEmpty, show, onSaved)
            }
            .setNegativeButton("Batal", null))
    }

    /** Satu kategori di menu pengaturan: judul, ringkasan nilai saat ini, dan baris pengaturan di dalamnya. */
    private class Category(
        val title: String,
        val summary: () -> String,
        val rows: () -> List<Pair<String, () -> Unit>>
    )

    /**
     * Menu pengaturan berkategori. Layar utama berisi daftar kategori (dengan ringkasan nilai saat ini);
     * mengetuk satu kategori membuka daftar pengaturannya. Daftar TETAP terbuka setelah tiap perubahan
     * (label otomatis diperbarui), jadi bisa mengubah beberapa pengaturan sekaligus. Tombol "Kembali" pada
     * kategori kembali ke daftar kategori; tombol "Tutup" menutup semuanya.
     * [extra] dievaluasi ulang tiap refresh; lambda-nya menerima fungsi untuk menutup seluruh menu.
     * Aksi tambahan ini ditaruh di kategori Terjemahan.
     * [onClosed] dipanggil sekali saat menu benar-benar tertutup.
     */
    fun settings(
        ctx: Context, s: Settings,
        extra: () -> List<Pair<String, (dismiss: () -> Unit) -> Unit>> = { emptyList() },
        onClosed: () -> Unit = {},
        padGroup: String? = null,   // sistem yang sedang dimainkan: pemetaan langsung membuka sistem ini
        arcadeGame: Boolean = false, // true hanya saat memainkan game arcade: pengaturan arcade ditampilkan
        onChangeCb: () -> Unit
    ): AlertDialog? {
        var refresh: () -> Unit = {}
        var dialog: AlertDialog? = null
        var subDialog: AlertDialog? = null
        var subRefresh: () -> Unit = {}
        val onChange: () -> Unit = { onChangeCb(); refresh(); subRefresh() }

        // ---- Kategori ----
        val performa = Category(
            "Performa & tampilan",
            { "Fast forward ${s.fastForward}x · Filter ${SHADERS.getOrElse(s.shaderMode) { SHADERS[0] }.first} · Layar 60 Hz ${onOff(s.lock60Hz)} · FPS ${onOff(s.showFps)}" }
        ) {
            val r = ArrayList<Pair<String, () -> Unit>>()
            r += "Filter gambar: ${SHADERS.getOrElse(s.shaderMode) { SHADERS[0] }.first} (langsung berlaku)" to {
                choose(ctx, "Filter gambar", SHADERS.map { it.second }, s.shaderMode) { s.shaderMode = it; onChange() }
            }
            r += "Kecepatan fast forward: ${s.fastForward}x" to {
                pickInt(ctx, "Fast forward", listOf(2, 3, 4, 8), s.fastForward, "x") { s.fastForward = it; onChange() }
            }
            r += "Frame skip: ${s.frameSkip} (saat game dimulai)" to {
                pickInt(ctx, "Frame skip", listOf(0, 1, 2, 3, 4, 5), s.frameSkip, "") { s.frameSkip = it; onChange() }
            }
            r += "Kunci layar 60 Hz: ${onOff(s.lock60Hz)} (saat game dimulai)" to {
                s.lock60Hz = !s.lock60Hz; onChange()
            }
            r += "Kecepatan CPU SNES: ${com.allinone.emulator.data.CpuTuning.snesLabel(s.snesCpu)} (langsung berlaku)" to {
                choose(ctx, "Kecepatan CPU SNES (naikkan bila game melambat, mis. Star Fox atau Gradius III)",
                    com.allinone.emulator.data.CpuTuning.SNES_CHOICES.map { com.allinone.emulator.data.CpuTuning.snesLabel(it) },
                    com.allinone.emulator.data.CpuTuning.SNES_CHOICES.indexOf(s.snesCpu)) {
                    s.snesCpu = com.allinone.emulator.data.CpuTuning.SNES_CHOICES[it]; onChange()
                }
            }
            r += "Kecepatan CPU Genesis: ${s.genesisCpu}% (langsung berlaku)" to {
                pickInt(ctx, "Kecepatan CPU Genesis (naikkan bila game melambat saat banyak sprite)",
                    com.allinone.emulator.data.CpuTuning.GENESIS_CHOICES, s.genesisCpu, "%") { s.genesisCpu = it; onChange() }
            }
            r += "Lewati frame duplikat: ${onOff(s.skipDuplicateFrames)} (saat game dimulai)" to {
                s.skipDuplicateFrames = !s.skipDuplicateFrames; onChange()
            }
            r += "Penghitung FPS di layar: ${onOff(s.showFps)}" to {
                s.showFps = !s.showFps; onChange()
            }
            r
        }

        val arcade = Category(
            "Arcade",
            {
                "Performa ${ARCADE_PERF.getOrElse(s.arcadePerf) { ARCADE_PERF[0] }.first} · CPU ${s.arcadeCpu}%"
            }
        ) {
            val r = ArrayList<Pair<String, () -> Unit>>()
            r += "Performa arcade: ${ARCADE_PERF.getOrElse(s.arcadePerf) { ARCADE_PERF[0] }.first} (langsung berlaku)" to {
                choose(ctx, "Performa arcade", ARCADE_PERF.map { it.second }, s.arcadePerf) { s.arcadePerf = it; onChange() }
            }
            r += "Kecepatan CPU arcade (semua core): ${s.arcadeCpu}% (langsung berlaku)" to {
                pickInt(ctx, "Kecepatan CPU arcade (naikkan bila game melambat saat sprite ramai)",
                    com.allinone.emulator.data.ArcadeTuning.CPU_CHOICES, s.arcadeCpu, "%") { s.arcadeCpu = it; onChange() }
            }
            r
        }

        val audio = Category(
            "Audio",
            { "Mode ${if (s.lowLatencyAudio) "latensi rendah" else "stabil"}" }
        ) {
            val r = ArrayList<Pair<String, () -> Unit>>()
            r += "Mode audio: ${if (s.lowLatencyAudio) "latensi rendah" else "stabil"} (saat game dimulai)" to {
                choose(ctx, "Mode audio",
                    listOf(
                        "Stabil (bawaan): suara mulus, bebas kresek, tapi sedikit terlambat dari gambar",
                        "Latensi rendah: suara cepat & sinkron, tapi bisa kresek bila perangkat berat"
                    ),
                    if (s.lowLatencyAudio) 1 else 0
                ) { s.lowLatencyAudio = (it == 1); onChange() }
            }
            r
        }

        val kontrol = Category(
            "Kontrol di layar",
            { "Transparansi ${s.padOpacity}% · ${if (s.analogPad) "stik analog" else "D-pad 8 arah"} · Getar ${onOff(s.haptics)}" }
        ) {
            val r = ArrayList<Pair<String, () -> Unit>>()
            r += "Transparansi kontrol layar: ${s.padOpacity}%" to {
                pickInt(ctx, "Transparansi", listOf(20, 40, 60, 80, 100), s.padOpacity, "%") { s.padOpacity = it; onChange() }
            }
            r += "Kontrol arah di layar: ${if (s.analogPad) "stik analog" else "D-pad 8 arah"}" to {
                choose(ctx, "Kontrol arah di layar", listOf("D-pad 8 arah (termasuk serong)", "Stik analog"), if (s.analogPad) 1 else 0) {
                    s.analogPad = it == 1; onChange()
                }
            }
            r += "Getar saat sentuh: ${onOff(s.haptics)}" to { s.haptics = !s.haptics; onChange() }
            r
        }

        val controller = Category(
            "Controller eksternal",
            { "Sembunyikan kontrol layar ${onOff(s.autoHidePad)} · Layar penuh ${onOff(s.stretchWithPad)}" }
        ) {
            val r = ArrayList<Pair<String, () -> Unit>>()
            r += "Sembunyikan kontrol layar saat gamepad terhubung: ${onOff(s.autoHidePad)}" to {
                s.autoHidePad = !s.autoHidePad; onChange()
            }
            r += "Gambar game memenuhi seluruh layar saat gamepad terhubung: ${onOff(s.stretchWithPad)}" to {
                s.stretchWithPad = !s.stretchWithPad; onChange()
            }
            r += (if (padGroup != null) "Pemetaan tombol controller: ${PadMap.groupLabel(padGroup)}"
                  else "Pemetaan tombol controller eksternal & kombo") to {
                (ctx as? Activity)?.let { if (padGroup != null) padMapOpen(it, padGroup, true) else padMapSystems(it) }
            }
            r += "Pintasan controller (simpan/muat, pengaturan, library, keluar)" to {
                (ctx as? Activity)?.let { remap(it) }
            }
            r += "Reset pintasan controller" to {
                KeyMap.clearAll(ctx)
                SoundToast.makeText(ctx, "Pintasan direset", Toast.LENGTH_SHORT).show()
            }
            r
        }

        val terjemahan = Category(
            "Terjemahan",
            {
                "${TranslationEngine.SOURCES.first { it.first == s.translateSource }.second} · " +
                    (if (s.translateBottomOnly) "area bawah layar" else "seluruh layar") +
                    " · huruf ${s.translateFontMin}-${s.translateFontMax} dp"
            }
        ) {
            val r = ArrayList<Pair<String, () -> Unit>>()
            r += "Bahasa teks game: ${TranslationEngine.SOURCES.first { it.first == s.translateSource }.second}" to {
                val keys = TranslationEngine.SOURCES.map { it.first }
                choose(ctx, "Bahasa teks game", TranslationEngine.SOURCES.map { it.second }, keys.indexOf(s.translateSource)) {
                    s.translateSource = keys[it]; onChange()
                }
            }
            r += "Jenis teks: ${if (s.translateKind == 1) "Menu awal game" else "Dialog"}" to {
                choose(ctx, "Jenis teks yang diterjemahkan (dua mode terpisah)",
                    listOf("Dialog (bawaan): balon/kotak dialog saat bermain",
                        "Menu awal game: tulisan Start, Option, Load, Save, dll. diterjemahkan satu per satu di tempatnya"),
                    s.translateKind) { s.translateKind = it; onChange() }
            }
            r += "Mesin terjemahan: ${engineLabel(s)}" to {
                choose(ctx, "Mesin terjemahan (tiap mesin terpisah, tidak saling menggantikan)",
                    listOf("Online (Google Translate): lebih akurat, wajib internet, teks dialog dikirim ke Google",
                        "Online (Groq): terjemahan AI (LLM), wajib internet + API key Groq, teks dikirim ke Groq",
                        "Offline (ML Kit): tanpa internet, kurang akurat; model bahasa diunduh sekali saja"),
                    if (!s.translateOnline) 2 else s.onlineEngine) {
                    if (it == 1 && s.groqKey.isEmpty()) {
                        // Groq dipilih tanpa kunci: minta kunci dulu; mesin baru berpindah setelah kunci disimpan.
                        askGroqKey(ctx, s) { s.translateOnline = true; s.onlineEngine = 1; onChange() }
                    } else {
                        s.translateOnline = it != 2
                        if (it != 2) s.onlineEngine = it
                        onChange()
                    }
                }
            }
            r += "API key Groq: ${if (s.groqKey.isEmpty()) "belum diisi" else "terisi (…" + s.groqKey.takeLast(4) + ")"}" to {
                askGroqKey(ctx, s, allowEmpty = true) { onChange() }
            }
            r += "Model Groq: ${s.groqModel}" to {
                askText(ctx, "Nama model Groq", TranslationEngine.GROQ_DEFAULT_MODEL, s.groqModel) { s.groqModel = it; onChange() }
            }
            r += "Bantuan OCR online (model gambar): ${if (s.visionOcr) "aktif (${VisionOcr.providerName(s.visionProvider)})" else "mati"}" to {
                if (s.visionOcr) { s.visionOcr = false; onChange() }
                else {
                    fun enable() { s.visionOcr = true; onChange() }
                    if (s.visionKey.isEmpty()) {
                        if (s.visionProvider == VisionOcr.PROVIDER_GROQ) askGroqKey(ctx, s) { enable() }
                        else askText(ctx, "API key Gemini (aistudio.google.com/apikey)", "AIza…", "") { k ->
                            if (k.isEmpty()) SoundToast.makeText(ctx, "API key kosong, bantuan OCR tidak diaktifkan", Toast.LENGTH_LONG).show()
                            else { s.geminiKey = k; enable() }
                        }
                    } else enable()
                }
            }
            r += "Penyedia model gambar: ${VisionOcr.providerName(s.visionProvider)}" to {
                choose(ctx, "Penyedia model gambar (membantu OCR bawaan; gambar layar game dikirim ke penyedia ini)",
                    listOf("Gemini: perlu API key Gemini (gratis di Google AI Studio)",
                        "Groq: memakai API key Groq yang sama dengan terjemahan"), s.visionProvider) {
                    s.visionProvider = it; onChange()
                }
            }
            r += "API key Gemini: ${if (s.geminiKey.isEmpty()) "belum diisi" else "terisi (…" + s.geminiKey.takeLast(4) + ")"}" to {
                askText(ctx, "API key Gemini (kosongkan untuk menghapus)", "AIza…", s.geminiKey) { s.geminiKey = it; onChange() }
            }
            r += "Model gambar: ${s.visionModel}" to {
                val g = s.visionProvider == VisionOcr.PROVIDER_GROQ
                askText(ctx, "Nama model gambar (${VisionOcr.providerName(s.visionProvider)})", VisionOcr.defaultModel(s.visionProvider), s.visionModel) {
                    if (g) s.visionModelGroq = it else s.visionModelGemini = it
                    onChange()
                }
            }
            r += "Area baca terjemahan: ${if (s.translateBottomOnly) "bagian bawah layar (dialog)" else "seluruh layar"}" to {
                s.translateBottomOnly = !s.translateBottomOnly; onChange()
            }
            r += "Ukuran huruf terjemahan minimal: ${s.translateFontMin} dp" to {
                pickInt(ctx, "Huruf minimal (naikkan bila terjemahan terlalu kecil)",
                    listOf(8, 10, 12, 14, 16, 20), s.translateFontMin, " dp") {
                    s.translateFontMin = it
                    if (s.translateFontMax < it) s.translateFontMax = it   // maksimal tidak boleh di bawah minimal
                    onChange()
                }
            }
            r += "Ukuran huruf terjemahan maksimal: ${s.translateFontMax} dp" to {
                pickInt(ctx, "Huruf maksimal (turunkan bila terjemahan terlalu besar)",
                    listOf(16, 20, 24, 28, 36, 48), s.translateFontMax, " dp") {
                    s.translateFontMax = it
                    if (s.translateFontMin > it) s.translateFontMin = it   // minimal tidak boleh di atas maksimal
                    onChange()
                }
            }
            // Aksi yang hanya muncul saat terjemahan sedang aktif (ganti teks asli/terjemahan, baca ulang)
            for ((label, action) in extra()) r += label to { action { dialog?.dismiss() } }
            r
        }

        val multiplayer = Category(
            "Multiplayer Online",
            { "${s.playerName} · " + (if (s.vpnIp.isBlank()) "IP otomatis" else "${vpnName(s.vpnType)} ${s.vpnIp}") }
        ) {
            val r = ArrayList<Pair<String, () -> Unit>>()
            r += "ZeroTier di aplikasi (VPN)" to {
                ctx.startActivity(Intent(ctx, ZeroTierActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
            r += "Alamat lobby: ${s.lobbyUrl.ifBlank { "(belum diisi)" }}" to {
                askText(ctx, "Alamat lobby", "mis. http://123.45.67.89:8080", s.lobbyUrl) { s.lobbyUrl = it; onChange() }
            }
            r += "Nama pemain: ${s.playerName}" to {
                askText(ctx, "Nama pemain", "Nama di daftar server", s.playerName) { s.playerName = it; onChange() }
            }
            r += "IP VPN/LAN saya: ${s.vpnIp.ifBlank { "otomatis" }}" to {
                askText(ctx, "IP VPN/LAN (kosong = otomatis)", "mis. 10.147.17.5", s.vpnIp) { s.vpnIp = it; onChange() }
            }
            r += "Node ID ZeroTier saya: ${s.zeroNodeId.ifBlank { "(belum diisi)" }}" to {
                askText(ctx, "Node ID ZeroTier One (10 karakter)", "mis. cd3c5e3a69", s.zeroNodeId) { s.zeroNodeId = it; onChange() }
            }
            r += "Kunci admin (pemilik jaringan): ${if (s.adminKey.isBlank()) "mati" else "terisi"}" to {
                askText(ctx, "Kunci admin lobby (kosongkan bila bukan pemilik)", "ADMIN_KEY di server lobby", s.adminKey) { s.adminKey = it; onChange() }
            }
            r += "Jenis VPN: ${vpnName(s.vpnType)}" to {
                choose(ctx, "Jenis VPN untuk server buatan sendiri",
                    listOf("Otomatis (lobby menebak dari IP)", "ZeroTier", "Tailscale"), s.vpnType
                ) { s.vpnType = it; onChange() }
            }
            r
        }

        // NDS: pengaturan sendiri (SeedlessSettings), terpisah dari semua pengaturan di atas.
        // Hanya muncul di Library (padGroup == null), tidak di layar emulator lain.
        val seedless = Category(
            "Nintendo DS",
            { SeedlessSettingsMenu.summary(com.allinone.emulator.data.SeedlessSettings(ctx)) }
        ) {
            listOf("Buka pengaturan Nintendo DS…" to {
                SeedlessSettingsMenu.show(ctx, com.allinone.emulator.data.SeedlessSettings(ctx), onClosed = { refresh() })
                Unit
            })
        }

        // Urutan = yang paling sering dipakai di atas
        val categories = ArrayList<Category>().apply {
            add(performa)
            if (arcadeGame) add(arcade)
            add(audio)
            add(kontrol)
            add(controller)
            add(terjemahan)
            add(multiplayer)
            if (padGroup == null && SeedlessSupport.available) add(seedless)
        }

        // ---- Layar kategori ----
        fun openCategory(c: Category) {
            var rows = c.rows()
            val labels = ArrayList(rows.map { it.first })
            val adapter = android.widget.ArrayAdapter(ctx, android.R.layout.simple_list_item_1, labels)
            val list = android.widget.ListView(ctx).apply {
                this.adapter = adapter
                setOnItemClickListener { _, _, i, _ -> rows.getOrNull(i)?.second?.invoke(); subRefresh() }
            }
            subRefresh = {
                rows = c.rows()
                labels.clear(); labels.addAll(rows.map { it.first })
                adapter.notifyDataSetChanged()
            }
            subDialog = AlertDialog.Builder(ctx).setTitle(c.title).setView(list)
                .setNegativeButton("Kembali", null)
                .setOnDismissListener { subDialog = null; subRefresh = {}; refresh() }
                .show()
        }

        // ---- Layar utama: daftar kategori + ringkasan ----
        val adapter = object : android.widget.ArrayAdapter<Category>(
            ctx, android.R.layout.simple_list_item_2, android.R.id.text1, categories
        ) {
            override fun getView(position: Int, convertView: android.view.View?, parent: android.view.ViewGroup): android.view.View {
                val v = super.getView(position, convertView, parent)
                val c = categories[position]
                v.findViewById<android.widget.TextView>(android.R.id.text1).apply {
                    text = c.title
                    textSize = 17f
                }
                v.findViewById<android.widget.TextView>(android.R.id.text2).apply {
                    text = c.summary()
                    textSize = 13f
                    alpha = 0.7f
                }
                return v
            }
        }
        val list = android.widget.ListView(ctx).apply {
            this.adapter = adapter
            setOnItemClickListener { _, _, i, _ -> categories.getOrNull(i)?.let { openCategory(it) } }
        }
        refresh = { adapter.notifyDataSetChanged() }
        dialog = AlertDialog.Builder(ctx).setTitle("Pengaturan").setView(list)
            .setNegativeButton("Tutup", null)
            .setOnDismissListener {
                subDialog?.dismiss()   // menutup menu dari luar (mis. muat ulang core) ikut menutup kategori yang terbuka
                onClosed()
            }
            .show()
        return dialog
    }

    // ---------------------------------------------------------------- pemetaan tombol controller + kombo

    private fun specLabel(spec: String) = spec.replace("+", " + ")

    /** Pilih sistem yang pemetaannya mau diatur (tiap sistem punya pemetaan sendiri). */
    fun padMapSystems(a: Activity) {
        val gs = PadMap.GROUPS
        val rows = gs.map { g ->
            val n = PadMap.entries(a, g).size
            PadMap.groupLabel(g) + if (n > 0) "  ($n pemetaan)" else ""
        }.toTypedArray()
        AlertDialog.Builder(a)
            .setTitle("Pemetaan tombol controller")
            .setItems(rows) { _, i -> padMapOpen(a, gs[i], false) }
            .setNegativeButton("Tutup", null)
            .show()
    }

    /** true bila layar pemetaan dibuka langsung untuk sistem yang sedang dimainkan (tanpa pilihan sistem). */
    private var padMapDirect = false

    fun padMapOpen(a: Activity, g: String, direct: Boolean) {
        padMapDirect = direct
        padMapButtons(a, g)
    }

    /**
     * Satu layar berisi SEMUA tombol game sistem [g] (mis. GBA: A, B, L, R, Select, Start, arah). Ketuk satu tombol
     * game (jadi hijau, menunggu), lalu tekan tombol di controller eksternal: langsung terpasang dan layar tetap
     * terbuka, jadi bisa lanjut memetakan tombol berikutnya. Tahan lama satu tombol game = kembali ke bawaan.
     */
    private fun padMapButtons(a: Activity, g: String) {
        val tokens = PadMap.tokens(g)
        val dp = a.resources.displayMetrics.density
        fun px(v: Int) = (v * dp).toInt()
        var listening: String? = null
        val swallowUp = HashSet<Int>()
        var refresh: () -> Unit = {}

        val info = TextView(a).apply { textSize = 14f; setPadding(px(20), px(12), px(20), px(8)) }
        val grid = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL; setPadding(px(12), 0, px(12), px(8)) }
        val root = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            addView(info)
            addView(ScrollView(a).apply { addView(grid) })
        }

        refresh = {
            val l = listening
            info.text = if (l != null) "Tekan tombol di controller untuk ${tokenName(l)}…"
                        else "Ketuk tombol game, lalu tekan tombol di controller. Tahan lama = kembali ke bawaan."
            grid.removeAllViews()
            for (pair in tokens.chunked(2)) {
                val row = LinearLayout(a).apply { orientation = LinearLayout.HORIZONTAL }
                for (tok in pair) {
                    val phys = PadMap.physFor(a, g, tok)
                    val waiting = tok == l
                    val b = Button(a).apply {
                        isAllCaps = false
                        textSize = 13f
                        text = tokenName(tok) + "\n" + when {
                            waiting -> "tekan tombol controller…"
                            phys.isEmpty() -> "(kosong)"
                            else -> phys.joinToString(", ") { physName(it) }
                        }
                        if (waiting) { setBackgroundColor(0xFF2E7D32.toInt()); setTextColor(Color.WHITE) }
                        setOnClickListener { listening = if (waiting) null else tok; refresh() }
                        setOnLongClickListener {
                            PadMap.resetToken(a, g, tok)
                            listening = null
                            SoundToast.makeText(a, "${tokenName(tok)} kembali ke bawaan", Toast.LENGTH_SHORT).show()
                            refresh(); true
                        }
                    }
                    row.addView(b, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                        .apply { setMargins(px(4), px(2), px(4), px(2)) })
                }
                if (pair.size < 2) row.addView(View(a), LinearLayout.LayoutParams(0, 1, 1f))
                grid.addView(row)
            }
        }
        refresh()

        val back = !padMapDirect
        val dialog = AlertDialog.Builder(a)
            .setTitle("Pemetaan tombol: ${PadMap.groupLabel(g)}")
            .setView(root)
            .setNeutralButton("Kombo / lanjutan") { _, _ -> padMapList(a, g) }
            .setPositiveButton("Reset semua", null)   // di-override di bawah supaya layar tidak tertutup
            .setNegativeButton(if (back) "Kembali" else "Tutup") { _, _ -> if (back) padMapSystems(a) }
            .create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                PadMap.clear(a, g)
                listening = null
                SoundToast.makeText(a, "Pemetaan ${PadMap.groupLabel(g)} dikembalikan ke bawaan", Toast.LENGTH_SHORT).show()
                refresh()
            }
        }
        dialog.setOnKeyListener { _, keyCode, ev ->
            val isPadKey = KeyEvent.isGamepadButton(keyCode) ||
                keyCode in KeyEvent.KEYCODE_DPAD_UP..KeyEvent.KEYCODE_DPAD_RIGHT
            val tok = listening
            when {
                !isPadKey || ev.device?.isVirtual != false -> false
                ev.action == KeyEvent.ACTION_UP && swallowUp.remove(keyCode) -> true
                tok == null -> false   // tidak menunggu: biarkan dipakai menavigasi dialog
                ev.action == KeyEvent.ACTION_DOWN && ev.repeatCount == 0 -> {
                    if (KeyMap.actionFor(a, keyCode) != null) {
                        SoundToast.makeText(a, "${physName(keyCode)} dipakai sebagai pintasan aplikasi", Toast.LENGTH_SHORT).show()
                    } else {
                        PadMap.bindToken(a, g, tok, keyCode)
                        swallowUp += keyCode
                        listening = null
                        SoundToast.makeText(a, "${tokenName(tok)} = ${physName(keyCode)}", Toast.LENGTH_SHORT).show()
                        refresh()
                    }
                    true
                }
                else -> true
            }
        }
        dialog.show()
    }

    private fun tokenName(tok: String) = when (tok) {
        "↑" -> "↑ Atas"; "↓" -> "↓ Bawah"; "←" -> "← Kiri"; "→" -> "→ Kanan"
        "SEL" -> "Select"; "START" -> "Start"; "SELECT" -> "Select"; "MODE" -> "Mode"; "KOIN" -> "Koin"
        else -> "Tombol $tok"
    }

    /** Daftar lanjutan: tombol fisik -> tombol game, termasuk kombo (beberapa tombol sekaligus). */
    private fun padMapList(a: Activity, g: String) {
        val ents = PadMap.entries(a, g)
        val rows = (ents.map { (k, spec) -> "${physName(k)}  →  ${specLabel(spec)}" } + "+ Tambah pemetaan").toTypedArray()
        AlertDialog.Builder(a)
            .setTitle("${PadMap.groupLabel(g)}: tombol fisik → tombol game")
            .setItems(rows) { _, i ->
                if (i == ents.size) padMapCapture(a, g, { k -> padMapPick(a, g, k) }) { padMapList(a, g) }
                else padMapEdit(a, g, ents[i])
            }
            .setNeutralButton("Reset") { _, _ ->
                PadMap.clear(a, g)
                SoundToast.makeText(a, "Pemetaan ${PadMap.groupLabel(g)} dikosongkan", Toast.LENGTH_SHORT).show()
                padMapList(a, g)
            }
            .setNegativeButton("Kembali") { _, _ -> padMapButtons(a, g) }
            .show()
    }

    private fun padMapEdit(a: Activity, g: String, e: Pair<Int, String>) {
        val (phys, spec) = e
        AlertDialog.Builder(a)
            .setTitle("${physName(phys)}  →  ${specLabel(spec)}")
            .setItems(arrayOf("Ubah tombol game / kombo", "Ganti tombol fisik", "Hapus pemetaan")) { _, i ->
                when (i) {
                    0 -> padMapPick(a, g, phys)
                    1 -> padMapCapture(a, g, { k ->
                        if (k != phys) { PadMap.remove(a, g, phys); PadMap.set(a, g, k, spec) }
                        padMapList(a, g)
                    }) { padMapList(a, g) }
                    else -> { PadMap.remove(a, g, phys); padMapList(a, g) }
                }
            }
            .setNegativeButton("Kembali") { _, _ -> padMapList(a, g) }
            .show()
    }

    /** Tekan tombol di controller untuk memilihnya. Tombol yang sudah jadi pintasan aplikasi ditolak. */
    private fun padMapCapture(a: Activity, g: String, onKey: (Int) -> Unit, onCancel: () -> Unit) {
        var done = false
        AlertDialog.Builder(a)
            .setTitle("Pilih tombol controller")
            .setMessage("Tekan tombol di controller yang ingin dipetakan.\n\nTombol yang sudah jadi pintasan aplikasi tidak bisa dipakai di sini.")
            .setNegativeButton("Batal") { _, _ -> onCancel() }
            .setOnCancelListener { if (!done) onCancel() }
            .setOnKeyListener { d, keyCode, ev ->
                val isPadKey = KeyEvent.isGamepadButton(keyCode) ||
                    keyCode in KeyEvent.KEYCODE_DPAD_UP..KeyEvent.KEYCODE_DPAD_RIGHT
                if (isPadKey && ev.device?.isVirtual == false) {
                    if (ev.action == KeyEvent.ACTION_DOWN && ev.repeatCount == 0) {
                        if (KeyMap.actionFor(a, keyCode) != null) {
                            SoundToast.makeText(a, "${physName(keyCode)} dipakai sebagai pintasan aplikasi", Toast.LENGTH_SHORT).show()
                        } else {
                            done = true
                            d.dismiss()
                            onKey(keyCode)
                        }
                    }
                    true
                } else false
            }
            .show()
    }

    /** Pilih tombol game untuk satu tombol fisik: satu pilihan = pemetaan ulang, beberapa pilihan = kombo (serentak). */
    private fun padMapPick(a: Activity, g: String, phys: Int) {
        val tokens = PadMap.tokens(g)
        val have = (PadMap.specFor(a, g, phys) ?: "").split('+').map { it.trim() }.toSet()
        val checked = BooleanArray(tokens.size) { tokens[it] in have }
        AlertDialog.Builder(a)
            .setTitle("${physName(phys)} menekan (pilih >1 = kombo):")
            .setMultiChoiceItems(tokens.toTypedArray(), checked) { _, i, v -> checked[i] = v }
            .setPositiveButton("Simpan") { _, _ ->
                val spec = tokens.filterIndexed { i, _ -> checked[i] }.joinToString("+")
                PadMap.set(a, g, phys, spec)   // kosong = hapus: tombol kembali diteruskan apa adanya
                padMapList(a, g)
            }
            .setNegativeButton("Batal") { _, _ -> padMapList(a, g) }
            .show()
    }

    private fun physName(code: Int) = KeyEvent.keyCodeToString(code).removePrefix("KEYCODE_")

    /**
     * Pintasan controller eksternal: daftar perintah aplikasi (simpan/muat state, pengaturan, kembali ke library,
     * keluar aplikasi, terjemahan). Ketuk satu perintah lalu tekan tombol di controller untuk memasangnya.
     */
    fun remap(activity: Activity) {
        val acts = KeyMap.Action.values()
        val rows = acts.map { a -> "${a.label}  →  ${KeyMap.keyFor(activity, a)?.let { physName(it) } ?: "(kosong)"}" }.toTypedArray()
        AlertDialog.Builder(activity)
            .setTitle("Pintasan controller")
            .setItems(rows) { _, i -> remapCapture(activity, acts[i]) }
            .setNeutralButton("Reset") { _, _ ->
                KeyMap.clearAll(activity)
                SoundToast.makeText(activity, "Pintasan dikembalikan ke bawaan", Toast.LENGTH_SHORT).show()
                remap(activity)
            }
            .setNegativeButton("Tutup", null)
            .show()
    }

    private fun remapCapture(activity: Activity, a: KeyMap.Action) {
        var captured = false
        AlertDialog.Builder(activity)
            .setTitle("Atur pintasan")
            .setMessage("Tekan tombol di controller untuk:\n\n${a.label}\n\nTombol ini tidak akan dikirim ke game lagi.")
            .setPositiveButton("Kosongkan") { _, _ -> KeyMap.unbind(activity, a); remap(activity) }
            .setNegativeButton("Batal") { _, _ -> remap(activity) }
            .setOnCancelListener { if (!captured) remap(activity) }
            .setOnKeyListener { d, keyCode, ev ->
                val isPadKey = KeyEvent.isGamepadButton(keyCode) ||
                    keyCode in KeyEvent.KEYCODE_DPAD_UP..KeyEvent.KEYCODE_DPAD_RIGHT
                if (isPadKey && ev.device?.isVirtual == false) {
                    if (ev.action == KeyEvent.ACTION_DOWN && ev.repeatCount == 0) {
                        captured = true
                        KeyMap.bind(activity, a, keyCode)
                        d.dismiss()
                        remap(activity)
                    }
                    true
                } else false
            }
            .show()
    }
}
