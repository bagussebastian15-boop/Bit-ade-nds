package com.allinone.emulator.translate

import android.content.res.AssetManager

/**
 * Kamus Inggris offline (assets/en_words.txt, ~83 ribu kata) untuk membetulkan salah baca OCR pada font piksel.
 *
 * Dua kegunaan:
 * 1. [knownRatio]: seberapa besar bagian huruf yang membentuk kata Inggris sungguhan. Dipakai untuk MEMILIH bacaan
 *    terbaik dari beberapa varian gambar (bacaan yang katanya paling banyak dikenal menang) dan untuk menolak
 *    bacaan acak.
 * 2. [fix]: kata yang TIDAK ada di kamus dicoba dibetulkan dengan menukar SATU huruf yang bentuknya mirip di font
 *    piksel (A<->R, H<->N, O<->D, ...). Hanya diganti bila hasilnya kata sungguhan dan pilihannya tidak ambigu.
 *    Contoh: "AICHER" -> "RICHER". Kata yang sudah ada di kamus tidak pernah diubah.
 */
object LatinFix {

    @Volatile private var words: HashSet<String>? = null

    val ready: Boolean get() = words != null

    fun init(am: AssetManager) {
        if (words != null) return
        synchronized(this) {
            if (words != null) return
            try {
                val s = HashSet<String>(120_000)
                am.open("en_words.txt").bufferedReader().useLines { seq -> seq.forEach { if (it.isNotEmpty()) s.add(it) } }
                s.addAll(EXTRA)
                words = s
            } catch (_: Exception) { /* tanpa kamus: fitur mati, OCR tetap jalan seperti biasa */ }
        }
    }

    /** Kata lisan/slang/kontraksi game yang tidak ada di kamus baku. */
    private val EXTRA = (
        "gonna gotta wanna gimme lemme kinda sorta ain't y'all ya yeah yep nope okay ok hey hi mafia " +
        "dunno outta lotta cuz tho thru nite whoa yikes phew gee golly howdy hiya c'mon 'cause 'til 'em " +
        "mmm hmm hm huh uh um ugh oof argh aw ah oh ha haha hehe heh yay yo yup nah bro dude kiddo " +
        "mario luigi zelda sonic pokemon " +
        "ok hq vip tv dj pc cd dvd dna fbi cia cpu gps usa uk usb"
        ).split(' ').toHashSet()

    /** Pasangan huruf yang sering tertukar pada font piksel (dua arah). */
    private val CONF: Map<Char, String> by lazy {
        val pairs = listOf(
            "ar", "ah", "rb", "hn", "nm", "mw", "od", "oq", "oc", "dq", "cg", "gs", "ef", "il", "it", "lt",
            "uv", "vy", "uy", "kx", "pb", "pf", "ec", "zs", "ue", "rn"
        )
        val m = HashMap<Char, StringBuilder>()
        for (p in pairs) {
            m.getOrPut(p[0]) { StringBuilder() }.append(p[1])
            m.getOrPut(p[1]) { StringBuilder() }.append(p[0])
        }
        m.mapValues { it.value.toString() }
    }

    private val SUFFIXES = listOf("'s", "'m", "'d", "'ll", "'re", "'ve", "'t", "'")

    /** true bila [w] (huruf kecil, boleh berapostrof) kata Inggris yang dikenal. */
    fun isWord(w: String): Boolean {
        val ws = words ?: return true
        if (w.isEmpty()) return false
        if (w in ws) return true
        for (suf in SUFFIXES) {
            if (w.length > suf.length + 1 && w.endsWith(suf)) {
                val stem = w.dropLast(suf.length)
                if (stem in ws) return true
                if (suf == "'t" && stem.endsWith("n") && stem.dropLast(1) in ws) return true   // don't, can't (ca+n), isn't
                if (suf == "'" && (stem + "g") in ws) return true                               // stinkin' / goin'
            }
        }
        return false
    }

    private val TOKEN = Regex("[A-Za-z]+(?:'[A-Za-z]+)?'?")

    /** Bagian huruf (0..1) yang menyusun kata dikenal. 1.0 bila tidak ada kamus atau tidak ada kata. */
    fun knownRatio(text: String): Float {
        if (words == null) return 1f
        var good = 0
        var total = 0
        for (m in TOKEN.findAll(text)) {
            val t = m.value
            val letters = t.count { it.isLetter() }
            total += letters
            val lw = t.lowercase()
            val ok = if (letters == 1) lw == "a" || lw == "i" else isWord(lw)
            if (ok) good += letters
        }
        return if (total == 0) 1f else good.toFloat() / total
    }

    private val COMMON by lazy {
        ("the be to of and a in that have i it for not on with he as you do at this but his by from they we say her she or an " +
            "will my one all would there their what so up out if about who get which go me when make can like time no just him " +
            "know take people into year your good some could them see other than then now look only come its over think also " +
            "back after use two how our work first well way even new want because any these give day most us is are was were " +
            "am been has had did does done let off on streets street head together meeting drive break island richer").split(' ').toHashSet()
    }

    /** Betulkan tiap kata yang tidak dikenal; kata yang dikenal dan tanda baca tidak diubah. */
    fun fix(text: String): String {
        if (words == null || text.isBlank()) return text
        return TOKEN.replace(text) { m -> fixWord(m.value) }
    }

    private fun fixWord(raw: String): String {
        val lw = raw.lowercase()
        val core = lw.trimEnd('\'')
        if (core.length < 4 || isWord(lw)) return raw
        if (core.contains('\'')) return raw            // kontraksi tak dikenal: jangan disentuh
        val cands = LinkedHashSet<String>()
        for (i in core.indices) {
            val subs = CONF[core[i]] ?: continue
            for (c in subs) {
                val n = core.substring(0, i) + c + core.substring(i + 1)
                if (isWord(n)) cands += n
            }
        }
        if (cands.isEmpty()) return raw
        val pick = when {
            cands.size == 1 -> cands.first()
            else -> cands.filter { it in COMMON }.let { if (it.size == 1) it[0] else null }
        } ?: return raw
        return matchCase(raw, pick + raw.substring(core.length))
    }

    private fun matchCase(src: String, dst: String): String {
        val letters = src.filter { it.isLetter() }
        return when {
            letters.isNotEmpty() && letters.all { it.isUpperCase() } -> dst.uppercase()
            letters.isNotEmpty() && letters[0].isUpperCase() -> dst.replaceFirstChar { it.uppercase() }
            else -> dst
        }
    }
}
