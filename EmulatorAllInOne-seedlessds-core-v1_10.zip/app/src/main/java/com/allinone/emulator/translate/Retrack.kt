package com.allinone.emulator.translate

import android.graphics.Bitmap
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Merapatkan jarak antarhuruf pada font piksel yang renggang (tiap huruf berdiri sendiri-sendiri, mis. dialog GBA).
 * OCR sering memotong/menghilangkan huruf pada teks seperti itu ("STREETS" -> "REET"). Tiap baris dipotong per huruf
 * lewat proyeksi kolom lalu disusun ulang dengan jarak huruf wajar dan jarak kata tetap terlihat; hasilnya hitam di
 * atas putih. Tinggi gambar tidak berubah, jadi hanya koordinat x hasil OCR yang perlu dikembalikan ([Result.unmap]).
 */
object Retrack {

    class Band(val y0: Int, val y1: Int, val xmap: IntArray)   // xmap[xBaru] = xAsli

    class Result(val bmp: Bitmap, private val bands: List<Band>) {
        fun unmap(l: Int, t: Int, r: Int, b: Int): IntArray {
            val cy = (t + b) / 2
            val band = bands.firstOrNull { cy >= it.y0 && cy < it.y1 }
                ?: bands.minByOrNull { abs((it.y0 + it.y1) / 2 - cy) }
                ?: return intArrayOf(l, t, r, b)
            val m = band.xmap
            val nl = m[l.coerceIn(0, m.size - 1)]
            val nr = max(nl + 1, m[r.coerceIn(0, m.size - 1)])
            return intArrayOf(nl, t, nr, b)
        }
    }

    /** null bila tidak ada baris berhuruf renggang (tidak perlu varian ini). */
    fun build(src: Bitmap): Result? {
        val w = src.width
        val h = src.height
        if (w < 64 || h < 24) return null
        val px = IntArray(w * h)
        src.getPixels(px, 0, w, 0, 0, w, h)

        // Warna latar = warna paling sering (dikelompokkan per 16 tingkat).
        val hist = HashMap<Int, Int>()
        var step = 1
        if (w * h > 600_000) step = 2
        var k = 0
        while (k < px.size) {
            val c = px[k]
            val key = (((c shr 20) and 0xF) shl 8) or (((c shr 12) and 0xF) shl 4) or ((c shr 4) and 0xF)
            hist[key] = (hist[key] ?: 0) + 1
            k += step
        }
        val top = hist.maxByOrNull { it.value }?.key ?: return null
        val br = ((top shr 8) and 0xF) * 16 + 8
        val bg = ((top shr 4) and 0xF) * 16 + 8
        val bb = (top and 0xF) * 16 + 8

        val ink = BooleanArray(w * h)
        for (i in px.indices) {
            val c = px[i]
            val d = max(abs(((c shr 16) and 0xFF) - br), max(abs(((c shr 8) and 0xFF) - bg), abs((c and 0xFF) - bb)))
            ink[i] = d >= 90
        }
        // Garis tepi balon (garis panjang tipis) bukan huruf.
        for (x in 0 until w) {
            var n = 0
            for (y in 0 until h) if (ink[y * w + x]) n++
            if (n > h * 0.55f) for (y in 0 until h) ink[y * w + x] = false
        }
        for (y in 0 until h) {
            var n = 0
            for (x in 0 until w) if (ink[y * w + x]) n++
            if (n > w * 0.8f) java.util.Arrays.fill(ink, y * w, y * w + w, false)
        }

        // Pita baris teks.
        val rowInk = IntArray(h)
        for (y in 0 until h) { var n = 0; for (x in 0 until w) if (ink[y * w + x]) n++; rowInk[y] = n }
        val raw = ArrayList<IntArray>()
        var y = 0
        while (y < h) {
            if (rowInk[y] > 0) {
                var e = y
                while (e < h && rowInk[e] > 0) e++
                raw += intArrayOf(y, e)
                y = e
            } else y++
        }
        val bandsRaw = ArrayList<IntArray>()
        for (b in raw) {
            val last = bandsRaw.lastOrNull()
            if (last != null && b[0] - last[1] < 0.2f * max(last[1] - last[0], b[1] - b[0])) last[1] = b[1] else bandsRaw += b
        }

        val out = IntArray(w * h) { -1 }          // putih
        val bands = ArrayList<Band>()
        var anyWide = false
        for (b in bandsRaw) {
            val y0 = b[0]; val y1 = b[1]; val bh = y1 - y0
            if (bh < 8) continue
            val col = BooleanArray(w)
            for (yy in y0 until y1) for (x in 0 until w) if (ink[yy * w + x]) col[x] = true
            val runs = ArrayList<IntArray>()
            var x = 0
            while (x < w) {
                if (col[x]) { var e = x; while (e < w && col[e]) e++; runs += intArrayOf(x, e); x = e } else x++
            }
            if (runs.size < 4) continue
            val gaps = IntArray(runs.size - 1) { runs[it + 1][0] - runs[it][1] }
            val sorted = gaps.sorted()
            val med = sorted[sorted.size / 2].toFloat()
            val small = sorted.filter { it <= med * 1.4f }
            val lg = if (small.isEmpty()) med else small[small.size / 2].toFloat()
            val wide = lg >= 0.22f * bh
            val xmap = IntArray(w + 1) { it }
            var nx = runs[0][0]
            if (!wide) {
                for (yy in y0 until y1) for (xx in 0 until w) if (ink[yy * w + xx]) out[yy * w + xx] = 0xFF000000.toInt()
                bands += Band(y0, y1, xmap)
                continue
            }
            anyWide = true
            val letterNew = max(2, (0.12f * bh).roundToInt())
            val wordNew = (0.5f * bh).roundToInt()
            for ((i, r) in runs.withIndex()) {
                val rw = r[1] - r[0]
                if (nx + rw >= w) break
                for (yy in y0 until y1) for (dx in 0 until rw) if (ink[yy * w + r[0] + dx]) out[yy * w + nx + dx] = 0xFF000000.toInt()
                for (dx in 0..rw) if (nx + dx <= w) xmap[nx + dx] = r[0] + dx
                nx += rw
                if (i < gaps.size) {
                    val g = gaps[i]
                    val isWord = g >= 2.6f * lg && g >= 0.5f * bh
                    val ng = if (isWord) wordNew else letterNew + max(0f, (g - lg) * 0.3f).roundToInt()
                    // gap baru: petakan linear ke gap lama
                    for (dx in 0 until ng) {
                        val p = nx + dx
                        if (p <= w) xmap[p] = r[1] + (g * dx.toFloat() / ng).roundToInt()
                    }
                    nx += ng
                }
            }
            val lastOld = runs.last()[1]
            for (p in nx..w) xmap[p] = min(w, lastOld + (p - nx))
            bands += Band(y0, y1, xmap)
        }
        if (!anyWide) return null
        return Result(Bitmap.createBitmap(out, w, h, Bitmap.Config.ARGB_8888), bands)
    }
}
