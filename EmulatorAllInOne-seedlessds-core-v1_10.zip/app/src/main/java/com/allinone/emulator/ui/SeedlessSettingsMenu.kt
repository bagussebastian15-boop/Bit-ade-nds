package com.allinone.emulator.ui

import android.content.Context
import android.view.KeyEvent
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import com.allinone.emulator.data.SeedlessSettings

/**
 * Menu pengaturan KHUSUS NDS. Memakai [SeedlessSettings] (penyimpanan sendiri), jadi tidak ada satu pun
 * nilai di sini yang dibagi dengan emulator lain. Dipanggil dari Library (Atur > NDS) dan dari menu
 * jeda saat bermain NDS dengan NDS.
 *
 * [onChange] dipanggil setiap ada perubahan (saat bermain: untuk menerapkan langsung), [onClosed] sekali saat menu tertutup.
 */
object SeedlessSettingsMenu {

    private class Category(
        val title: String,
        val summary: () -> String,
        val rows: () -> List<Pair<String, () -> Unit>>
    )

    private val LAYOUTS = listOf(
        "Otomatis (potret atas-bawah, lanskap: layar sentuh besar di tengah + layar atas kecil di kanan)",
        "Selalu atas-bawah",
        "Selalu kiri-kanan",
        "Kustom (posisi & ukuran bebas, atur lewat editor)"
    )
    private val LAYOUT_SHORT = listOf("otomatis", "atas-bawah", "kiri-kanan", "kustom")
    private val BOOST = listOf(
        "Level 0 (paling pelan)", "Level 1 (bawaan)", "Level 2", "Level 3 (paling keras, bisa pecah)"
    )

    /** Ringkasan satu baris untuk daftar kategori di menu pengaturan Library. */
    fun summary(s: SeedlessSettings): String =
        "Filter ${SeedlessSettings.filterLabel(s.filter).substringBefore(" (")} · Layar ${LAYOUT_SHORT[s.layoutMode]} · Volume ${s.volume}%"

    private fun keyName(code: Int?) = code?.let { KeyEvent.keyCodeToString(it).removePrefix("KEYCODE_") } ?: "(kosong)"

    /** Tunggu satu tombol dari kontroler fisik, lalu panggil [onKey]. [onKosong] mengosongkan pasangan; [onBack] saat batal. */
    private fun captureKey(ctx: Context, what: String, onKey: (Int) -> Unit, onKosong: () -> Unit, onBack: () -> Unit) {
        var done = false
        AlertDialog.Builder(ctx)
            .setTitle("Pilih tombol kontroler")
            .setMessage("Tekan tombol di kontroler untuk:\n\n$what\n\nBila tombol itu sudah dipakai, pemakai lamanya dikosongkan.")
            .setPositiveButton("Kosongkan") { _, _ -> done = true; onKosong() }
            .setNegativeButton("Batal") { _, _ -> done = true; onBack() }
            .setOnCancelListener { if (!done) onBack() }
            .setOnKeyListener { d, keyCode, ev ->
                val isPadKey = KeyEvent.isGamepadButton(keyCode) ||
                    keyCode in KeyEvent.KEYCODE_DPAD_UP..KeyEvent.KEYCODE_DPAD_RIGHT
                if (isPadKey && ev.device?.isVirtual == false) {
                    if (ev.action == KeyEvent.ACTION_DOWN && ev.repeatCount == 0) { done = true; d.dismiss(); onKey(keyCode) }
                    true
                } else false
            }
            .show()
    }

    /** Daftar 12 tombol DS: ketuk satu lalu tekan tombol di kontroler untuk memasangnya. */
    private fun padMapping(ctx: Context, s: SeedlessSettings, onChange: () -> Unit) {
        val names = SeedlessSettings.PAD_BUTTONS
        val rows = names.indices.map { "${names[it]}  →  ${keyName(s.padKey(it))}" }.toTypedArray()
        AlertDialog.Builder(ctx).setTitle("Mapping tombol DS")
            .setItems(rows) { _, i ->
                val again = { padMapping(ctx, s, onChange) }
                captureKey(ctx, "Tombol DS ${names[i]}",
                    onKey = { k ->
                        val old = s.usedBy(k)
                        s.bindPad(i, k); onChange()
                        if (old != null && !old.endsWith(names[i])) Toast.makeText(ctx, "${keyName(k)} diambil dari $old", Toast.LENGTH_SHORT).show()
                        again()
                    },
                    onKosong = { s.unbindPad(i); onChange(); again() }, onBack = again)
            }
            .setNeutralButton("Bawaan") { _, _ ->
                s.resetController(); onChange(); padMapping(ctx, s, onChange)
            }
            .setNegativeButton("Tutup", null).show()
    }

    /** Daftar pintasan (fast forward, terjemahan, tukar layar, menu, save/load state). */
    private fun padShortcuts(ctx: Context, s: SeedlessSettings, onChange: () -> Unit) {
        val hk = SeedlessSettings.Companion.Hotkey.values()
        val rows = hk.map { "${it.label}  →  ${keyName(s.hotkeyKey(it))}" }.toTypedArray()
        AlertDialog.Builder(ctx).setTitle("Pintasan kontroler")
            .setItems(rows) { _, i ->
                val again = { padShortcuts(ctx, s, onChange) }
                captureKey(ctx, hk[i].label,
                    onKey = { k ->
                        val old = s.usedBy(k)
                        s.bindHotkey(hk[i], k); onChange()
                        if (old != null && !old.endsWith(hk[i].label)) Toast.makeText(ctx, "${keyName(k)} diambil dari $old", Toast.LENGTH_SHORT).show()
                        again()
                    },
                    onKosong = { s.unbindHotkey(hk[i]); onChange(); again() }, onBack = again)
            }
            .setNeutralButton("Bawaan") { _, _ -> s.resetController(); onChange(); padShortcuts(ctx, s, onChange) }
            .setNegativeButton("Tutup", null).show()
    }

    fun show(
        ctx: Context, s: SeedlessSettings, onChange: () -> Unit = {}, onClosed: () -> Unit = {},
        onEditLayout: (() -> Unit)? = null
    ): AlertDialog {
        var mainDialog: AlertDialog? = null
        var refresh: () -> Unit = {}
        var subRefresh: () -> Unit = {}
        var subDialog: AlertDialog? = null
        val changed: () -> Unit = { onChange(); refresh(); subRefresh() }
        val onOff = Menus::onOff

        val tampilan = Category(
            "Tampilan",
            { "Filter ${SeedlessSettings.filterLabel(s.filter).substringBefore(" (")} · Layar ${LAYOUT_SHORT[s.layoutMode]} · FPS ${onOff(s.showFps)}" }
        ) {
            listOf(
                "Filter gambar: ${SeedlessSettings.filterLabel(s.filter)}" to {
                    val keys = SeedlessSettings.FILTERS.map { it.first }
                    Menus.choose(ctx, "Filter gambar (langsung berlaku)", SeedlessSettings.FILTERS.map { it.second },
                        keys.indexOf(s.filter)) { s.filter = keys[it]; changed() }
                },
                "Susunan layar: ${LAYOUTS[s.layoutMode].substringBefore(" (")}" to {
                    Menus.choose(ctx, "Susunan dua layar", LAYOUTS, s.layoutMode) { s.layoutMode = it; changed() }
                },
                "Atur posisi & ukuran layar (kustom)…" to {
                    if (onEditLayout == null) {
                        Toast.makeText(ctx, "Buka dari menu jeda saat game berjalan untuk mengatur layar", Toast.LENGTH_LONG).show()
                    } else {
                        onEditLayout()                 // editor dibuka lebih dulu, lalu semua menu ditutup
                        subDialog?.dismiss()
                        mainDialog?.dismiss()
                    }
                },
                "Hapus susunan kustom tersimpan" to {
                    s.clearCustom(); changed()
                    Toast.makeText(ctx, "Susunan kustom dihapus", Toast.LENGTH_SHORT).show()
                },
                "Tukar layar atas/bawah (saat main: tombol \u21C4 atau L3/R3): ${onOff(s.swapScreens)}" to { s.swapScreens = !s.swapScreens; changed() },
                "Tombol tukar layar di atas game: ${onOff(s.showSwapButton)}" to { s.showSwapButton = !s.showSwapButton; changed() },
                "Kembalikan posisi tombol tukar layar" to {
                    s.resetSwapButtonPosition(); changed()
                    Toast.makeText(ctx, "Posisi tombol tukar layar dikembalikan", Toast.LENGTH_SHORT).show()
                },
                "Ukuran layar: ${if (s.stretch) "regang memenuhi area" else "jaga rasio 4:3"}" to {
                    s.stretch = !s.stretch; changed()
                },
                "Fullscreen otomatis saat gamepad terhubung: ${onOff(s.gamepadFullscreen)}" to { s.gamepadFullscreen = !s.gamepadFullscreen; changed() },
                "Kembalikan posisi layar kecil (mode gamepad)" to {
                    s.resetGamepadPip(); changed()
                    Toast.makeText(ctx, "Posisi layar kecil dikembalikan", Toast.LENGTH_SHORT).show()
                },
                "Penghitung FPS di layar: ${onOff(s.showFps)}" to { s.showFps = !s.showFps; changed() }
            )
        }

        val performa = Category(
            "Performa",
            { "Frame skip ${s.frameSkip} · Thread ${if (s.threads == 0) "otomatis" else s.threads.toString()} · FF ${SeedlessSettings.ffwdLabel(s.ffwdSpeed)}" }
        ) {
            listOf(
                "Kecepatan fast forward: ${SeedlessSettings.ffwdLabel(s.ffwdSpeed)} (langsung berlaku)" to {
                    val v = SeedlessSettings.FFWD_CHOICES
                    Menus.choose(ctx, "Kecepatan fast forward", v.map { it.second }, v.indexOfFirst { it.first == s.ffwdSpeed }) {
                        s.ffwdSpeed = v[it].first; changed()
                    }
                },
                "Tombol terjemahan & fast forward di atas game: ${onOff(s.showToolButtons)}" to { s.showToolButtons = !s.showToolButtons; changed() },
                "Frame skip: ${s.frameSkip} (saat game dimulai ulang)" to {
                    Menus.pickInt(ctx, "Frame skip (bawaan ${SeedlessSettings.DEFAULT_FRAMESKIP})",
                        (0..8).toList(), s.frameSkip, "") { s.frameSkip = it; changed() }
                },
                "Thread emulasi: ${if (s.threads == 0) "otomatis" else s.threads.toString()} (saat game dimulai ulang)" to {
                    val v = SeedlessSettings.THREAD_CHOICES
                    Menus.choose(ctx, "Thread emulasi", v.map { if (it == 0) "Otomatis (menurut jumlah inti CPU)" else "$it thread" },
                        v.indexOf(s.threads)) { s.threads = v[it]; changed() }
                }
            )
        }

        val audio = Category(
            "Audio",
            { "Volume ${s.volume}% · Penguatan level ${s.volumeBoost}" }
        ) {
            listOf(
                "Volume utama: ${s.volume}%" to {
                    Menus.pickInt(ctx, "Volume utama", listOf(0, 25, 50, 75, 100), s.volume, "%") { s.volume = it; changed() }
                },
                "Penguatan suara emulasi: level ${s.volumeBoost}" to {
                    Menus.choose(ctx, "Penguatan suara emulasi", BOOST, s.volumeBoost) { s.volumeBoost = it; changed() }
                }
            )
        }

        val kontrol = Category(
            "Kontrol & save state",
            { "Transparansi ${s.padOpacity}% · Getar ${onOff(s.haptics)} · Slot state ${s.stateSlot}" }
        ) {
            listOf(
                "Transparansi kontrol layar: ${s.padOpacity}%" to {
                    Menus.pickInt(ctx, "Transparansi", listOf(10, 20, 40, 60, 80, 100), s.padOpacity, "%") { s.padOpacity = it; changed() }
                },
                "Getar saat sentuh: ${onOff(s.haptics)}" to { s.haptics = !s.haptics; changed() },
                "Slot save state: ${s.stateSlot}" to {
                    Menus.pickInt(ctx, "Slot save state", (1..5).toList(), s.stateSlot, "") { s.stateSlot = it; changed() }
                }
            )
        }

        val kontroler = Category(
            "Kontroler",
            { "Mapping tombol DS · Pintasan (${SeedlessSettings.Companion.Hotkey.values().count { s.hotkeyKey(it) != null }} terpasang)" }
        ) {
            listOf(
                "Mapping tombol DS…" to { padMapping(ctx, s) { changed() } },
                "Pintasan kontroler (fast forward, terjemahan, dll.)…" to { padShortcuts(ctx, s) { changed() } },
                "Kembalikan mapping & pintasan ke bawaan" to {
                    s.resetController(); changed()
                    Toast.makeText(ctx, "Mapping dan pintasan kontroler dikembalikan", Toast.LENGTH_SHORT).show()
                }
            )
        }

        val firmware = Category(
            "Sistem NDS",
            { "${s.nickname} · ${SeedlessSettings.LANGUAGES[s.language]}" }
        ) {
            listOf(
                "Nama pengguna NDS: ${s.nickname} (saat game dimulai ulang)" to {
                    Menus.askText(ctx, "Nama pengguna NDS (maks. 10 karakter)", SeedlessSettings.DEFAULT_NICK, s.nickname) {
                        s.nickname = it; changed()
                    }
                },
                "Bahasa firmware NDS: ${SeedlessSettings.LANGUAGES[s.language]} (saat game dimulai ulang)" to {
                    Menus.choose(ctx, "Bahasa firmware (game yang mengikuti bahasa konsol akan memakainya)",
                        SeedlessSettings.LANGUAGES, s.language) { s.language = it; changed() }
                },
                "Kembalikan semua pengaturan NDS ke bawaan" to {
                    AlertDialog.Builder(ctx).setTitle("Kembalikan ke bawaan?")
                        .setMessage("Hanya pengaturan NDS yang direset. Pengaturan emulator lain tidak berubah.")
                        .setPositiveButton("Reset") { _, _ ->
                            s.resetAll(); changed()
                            Toast.makeText(ctx, "Pengaturan NDS dikembalikan ke bawaan", Toast.LENGTH_SHORT).show()
                        }
                        .setNegativeButton("Batal", null).show()
                }
            )
        }

        val categories = listOf(tampilan, performa, audio, kontrol, kontroler, firmware)

        fun openCategory(c: Category) {
            var rows = c.rows()
            val labels = ArrayList(rows.map { it.first })
            val adapter = ArrayAdapter(ctx, android.R.layout.simple_list_item_1, labels)
            val list = ListView(ctx).apply {
                this.adapter = adapter
                setOnItemClickListener { _, _, i, _ -> rows.getOrNull(i)?.second?.invoke(); subRefresh() }
            }
            subRefresh = {
                rows = c.rows()
                labels.clear(); labels.addAll(rows.map { it.first })
                adapter.notifyDataSetChanged()
            }
            subDialog = AlertDialog.Builder(ctx).setTitle("NDS · ${c.title}").setView(list)
                .setNegativeButton("Kembali", null)
                .setOnDismissListener { subDialog = null; subRefresh = {}; refresh() }
                .show()
        }

        val mainAdapter = object : ArrayAdapter<Category>(
            ctx, android.R.layout.simple_list_item_2, android.R.id.text1, categories
        ) {
            override fun getView(position: Int, convertView: android.view.View?, parent: android.view.ViewGroup): android.view.View {
                val v = super.getView(position, convertView, parent)
                val c = categories[position]
                v.findViewById<TextView>(android.R.id.text1).apply { text = c.title; textSize = 17f }
                v.findViewById<TextView>(android.R.id.text2).apply { text = c.summary(); textSize = 13f; alpha = 0.7f }
                return v
            }
        }
        val list = ListView(ctx).apply {
            adapter = mainAdapter
            setOnItemClickListener { _, _, i, _ -> categories.getOrNull(i)?.let { openCategory(it) } }
        }
        refresh = { mainAdapter.notifyDataSetChanged() }
        val dialog = AlertDialog.Builder(ctx).setTitle("Pengaturan NDS").setView(list)
            .setNegativeButton("Tutup", null)
            .setOnDismissListener { subDialog?.dismiss(); onClosed() }
            .show()
        mainDialog = dialog
        return dialog
    }
}
