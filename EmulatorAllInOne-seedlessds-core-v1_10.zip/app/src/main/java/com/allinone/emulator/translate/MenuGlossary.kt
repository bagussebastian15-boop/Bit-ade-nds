package com.allinone.emulator.translate

import java.io.File

/**
 * Kamus tulisan menu awal game (judul/menu utama/opsi). Tulisan menu biasanya satu-dua kata sehingga penerjemah
 * mesin sering salah ("スタート" -> "awal", "オプション" -> "pilihan"); kamus ini memberi padanan yang lazim di game.
 *
 * Pencocokan: hiragana dilipat ke katakana, hanya huruf/angka yang dibandingkan (spasi, kursor ▶, tanda baca dibuang,
 * huruf Latin dibesarkan), lalu dicocokkan persis; bila tidak ada, dicoba toleransi salah baca OCR 1-2 huruf.
 * Kamus pribadi: baris di glosarium_ja.txt (jepang=padanan) ikut dipakai untuk pencocokan persis.
 */
object MenuGlossary {

    private val RAW = """
        なまえにゅうりょく=Masukkan Nama
        名前入力=Masukkan Nama
        なまえ=Nama
        名前=Nama
        ランダム=Acak
        ランダムネーム=Nama Acak
        おわり=Selesai
        終わり=Selesai
        せんたく=Pilih
        選択=Pilih
        きめる=Tentukan
        はじめる=Mulai
        ロードする=Muat
        セーブする=Simpan
        ゲームをつづける=Lanjutkan Game
                スタート=Mulai
        ゲームスタート=Mulai Game
        ゲームをはじめる=Mulai Game
        ゲームかいし=Mulai Game
        ニューゲーム=Game Baru
        NEW GAME=Game Baru
        はじめから=Mulai dari Awal
        さいしょから=Mulai dari Awal
        最初から=Mulai dari Awal
        つづきから=Lanjutkan
        続きから=Lanjutkan
        つづける=Lanjutkan
        続ける=Lanjutkan
        コンティニュー=Lanjutkan
        CONTINUE=Lanjutkan
        ロード=Muat
        ロードゲーム=Muat Game
        LOAD=Muat
        LOAD GAME=Muat Game
        セーブ=Simpan
        SAVE=Simpan
        SAVE GAME=Simpan Game
        オートセーブ=Simpan Otomatis
        セーブデータ=Data Simpanan
        データ=Data
        データをけす=Hapus Data
        データをけします=Hapus Data
        オプション=Opsi
        OPTION=Opsi
        OPTIONS=Opsi
        せってい=Pengaturan
        設定=Pengaturan
        コンフィグ=Pengaturan
        CONFIG=Pengaturan
        SETTINGS=Pengaturan
        メニュー=Menu
        MENU=Menu
        もどる=Kembali
        戻る=Kembali
        BACK=Kembali
        やめる=Berhenti
        止める=Berhenti
        おわる=Selesai
        終わる=Selesai
        ゲームをおわる=Keluar dari Game
        EXIT=Keluar
        QUIT=Keluar
        はい=Ya
        いいえ=Tidak
        YES=Ya
        NO=Tidak
        OK=OK
        キャンセル=Batal
        CANCEL=Batal
        けってい=Pilih
        決定=Pilih
        ステータス=Status
        アイテム=Item
        どうぐ=Perlengkapan
        そうび=Perlengkapan
        マップ=Peta
        ヘルプ=Bantuan
        HELP=Bantuan
        ストーリー=Cerita
        ストーリーモード=Mode Cerita
        ミニゲーム=Minigame
        モード=Mode
        ひとりで=Sendirian
        ふたりで=Berdua
        1人用=1 Pemain
        2人用=2 Pemain
        たいせん=Pertarungan
        対戦=Pertarungan
        れんしゅう=Latihan
        練習=Latihan
        サウンド=Suara
        SOUND=Suara
        おんがく=Musik
        音楽=Musik
        ボリューム=Volume
        スピード=Kecepatan
        ステレオ=Stereo
        モノラル=Mono
        ON=Hidup
        OFF=Mati
        むずかしさ=Tingkat Kesulitan
        難易度=Tingkat Kesulitan
        かんたん=Mudah
        簡単=Mudah
        ふつう=Normal
        普通=Normal
        むずかしい=Sulit
        難しい=Sulit
        EASY=Mudah
        NORMAL=Normal
        HARD=Sulit
        ハイスコア=Skor Tertinggi
        ランキング=Peringkat
        スコア=Skor
        パスワード=Kata Sandi
        PASSWORD=Kata Sandi
        コピー=Salin
        けす=Hapus
        消す=Hapus
        ギャラリー=Galeri
        おまけ=Bonus
        クレジット=Kredit
        CREDITS=Kredit
        ずかん=Ensiklopedia
        図鑑=Ensiklopedia
        START=Mulai
        START GAME=Mulai Game
        GAME START=Mulai Game
        CONFIGURATION=Pengaturan
        PLAYER SELECT=Pilih Pemain
        1 PLAYER=1 Pemain
        2 PLAYERS=2 Pemain
        ONE PLAYER=1 Pemain
        TWO PLAYERS=2 Pemain
        VERSUS=Versus
        ARCADE=Arcade
        TRAINING=Latihan
        PRACTICE=Latihan
        STORY MODE=Mode Cerita
        SOUND TEST=Uji Suara
        MUSIC=Musik
        CONTROLS=Kontrol
        CONTROLLER=Kontroler
        LANGUAGE=Bahasa
        DIFFICULTY=Tingkat Kesulitan
        RESUME=Lanjutkan
        RESTART=Mulai Ulang
        RETRY=Coba Lagi
        PAUSE=Jeda
        EXTRAS=Ekstra
        GAME OVER=Permainan Berakhir
        HIGH SCORE=Skor Tertinggi
        HIGH SCORES=Skor Tertinggi
        PASSWORD ENTRY=Masukkan Kata Sandi
        LICENSED BY NINTENDO=Berlisensi oleh Nintendo
        PRESS START=Tekan Start
        PUSH START=Tekan Start
        PUSH START BUTTON=Tekan Tombol Start
        PRESS START BUTTON=Tekan Tombol Start
        スタートボタンをおしてください=Tekan Tombol Start
        スタートボタンをおしてね=Tekan Tombol Start
        これでよろしいですか=Apakah ini sudah benar?
        これでいいですか=Apakah ini sudah benar?
        これでよろしいでしょうか=Apakah ini sudah benar?
        これできまりですか=Apakah ini sudah benar?
        このなまえでよろしいですか=Apakah nama ini sudah benar?
        このなまえでいいですか=Apakah nama ini sudah benar?
        この名前でよろしいですか=Apakah nama ini sudah benar?
        この名前でいいですか=Apakah nama ini sudah benar?
        よろしいですか=Apakah sudah benar?
        いいですか=Sudah benar?
        よろしいですね=Sudah benar, ya?
        ほんとうにいいですか=Apakah Anda yakin?
        ほんとうによろしいですか=Apakah Anda yakin?
        本当にいいですか=Apakah Anda yakin?
        本当によろしいですか=Apakah Anda yakin?
        なまえをいれてください=Masukkan nama
        なまえをにゅうりょくしてください=Masukkan nama
        なまえをきめてください=Tentukan nama
        おなまえは=Siapa namamu?
        おなまえをどうぞ=Silakan masukkan nama
        セーブしますか=Simpan game?
        セーブしました=Game tersimpan
        セーブしてもよろしいですか=Boleh simpan game?
        ロードしますか=Muat game?
        ロードしました=Game dimuat
        データをけしますか=Hapus data?
        データをけしてもよろしいですか=Boleh hapus data?
        ゲームをおわりますか=Keluar dari game?
        ゲームをやめますか=Keluar dari game?
        つづけますか=Lanjutkan?
        やりなおしますか=Ulangi dari awal?
        はじめからやりなおしますか=Mulai ulang dari awal?
        ひらがな=Hiragana
        カタカナ=Katakana
        アルファベット=Alfabet
        かな=Kana
        ぜんぶけす=Hapus Semua
        ひとつけす=Hapus Satu
        ひとつもどる=Mundur Satu
        デフォルト=Bawaan
        ためす=Coba
        おなまえ=Nama
        ニックネーム=Nama Panggilan
        しょくぎょう=Pekerjaan
        レベル=Level
        たいりょく=HP
        まりょく=MP
    """.trimIndent()

    private fun fold(s: String): String {
        val sb = StringBuilder(s.length)
        for (ch in s) {
            val c = if (ch in '\u3041'..'\u3096') (ch.code + 0x60).toChar() else ch      // hiragana -> katakana
            if (c.isLetterOrDigit()) sb.append(c.uppercaseChar())
        }
        return sb.toString()
    }

    /** Pasangan huruf yang sering tertukar OCR font piksel (sesudah hiragana dilipat ke katakana, tanpa spasi/tanda baca). */
    private val CONFUSABLE: Set<String> = (
        "シツ ソン ヌス ムン ワク ウワ ワウ クケ ヲラ メヌ ネレ スヌ マミ ナメ ノメ ヘヘ " +
        "タダ カガ キギ クグ ケゲ コゴ サザ シジ スズ セゼ ソゾ チヂ ツヅ テデ トド ハバ ヒビ フブ ヘベ ホボ ハパ ヒピ フプ ヘペ ホポ"
    ).split(' ').flatMap { listOf(it, it.reversed()) }.toSet()

    private fun confusableDiff(a: String, b: String): Boolean {
        if (a.length != b.length) return false
        var diff = 0
        for (i in a.indices) if (a[i] != b[i]) {
            if (("" + a[i] + b[i]) !in CONFUSABLE) return false
            diff++
        }
        return diff in 1..1
    }

    private val table: Map<String, String> by lazy {
        val m = LinkedHashMap<String, String>()
        for (line in RAW.lines()) {
            val i = line.indexOf('=')
            if (i <= 0) continue
            val k = fold(line.substring(0, i))
            if (k.isNotEmpty() && k !in m) m[k] = line.substring(i + 1).trim()
        }
        m
    }

    /** Padanan menu untuk teks ini, atau null bila bukan tulisan menu yang dikenal. */
    fun lookup(text: String, userFile: File?): String? {
        val key = fold(text)
        if (key.isEmpty()) return null
        // kamus pribadi dulu (persis)
        for ((k, v) in JaPrep.userRules(userFile)) if (fold(k) == key) return v
        table[key]?.let { return it }
        // toleransi salah baca OCR: 1 huruf untuk kata >= 5 huruf, 2 huruf untuk >= 9 huruf
        val tol = when { key.length >= 9 -> 2; key.length >= 5 -> 1; else -> 0 }
        if (tol == 0) {
            // Kata pendek (3-4 huruf, mis. "ランダム" terbaca "ランダン"): hanya boleh salah SATU huruf yang memang sering tertukar.
            if (key.length < 3) return null
            var hit: String? = null
            for ((k, v) in table) if (k.length == key.length && confusableDiff(k, key)) {
                if (hit != null && hit != v) return null     // ambigu: jangan menebak
                hit = v
            }
            return hit
        }
        var best: String? = null
        var bestD = tol + 1
        for ((k, v) in table) {
            if (kotlin.math.abs(k.length - key.length) > tol) continue
            val d = distance(k, key, tol)
            if (d < bestD) { bestD = d; best = v }
        }
        return best
    }

    private const val SEP = "=＝-−‐–—―_・:："
    private const val SLOT_JUNK = "ロ口□◻▯○〇◯"

    private fun hamming(a: String, b: String): Int {
        if (a.length != b.length) return 99
        var d = 0
        for (i in a.indices) if (a[i] != b[i]) d++
        return d
    }

    /**
     * Baris nama pada layar input nama: "クレス□□□ =アルベイン" (nama pemain + kotak kosong + "=" + nama keluarga).
     * Kotak kosong sering terbaca "ロ"/"口", "=" terbaca "-"/"ー". Nama keluarga/tokoh yang dikenal diberi nama Latin resmi
     * (クレス -> Cless, アルベイン -> Alvein); nama ketikan pemain dibaca ke huruf Latin. Null bila bukan pola ini.
     */
    private fun nameLine(text: String, userFile: File?): String? {
        val s = text.replace(Regex("\\s+"), "")
        if (s.length < 4 || s.none { it.code in 0x30A0..0x30FF }) return null
        val casts = JaPrep.castKeys(userFile).sortedByDescending { it.length }
        var right: String? = null
        var cut = s.length
        for (k in casts) {
            if (s.length <= k.length) continue
            val tail = s.takeLast(k.length)
            if (tail == k || (k.length >= 4 && hamming(tail, k) <= 1)) { right = k; cut = s.length - k.length; break }
        }
        if (right == null) return null
        var left = s.substring(0, cut)
        // harus ada pemisah di antara nama pemain dan nama keluarga; tanpa pemisah ini bukan baris "A=B"
        val hasSep = left.lastOrNull()?.let { it in SEP || it == 'ー' || it in SLOT_JUNK } == true
        if (!hasSep) return null
        left = left.trimEnd { it in SEP || it == 'ー' || it in SLOT_JUNK }
        val rightLatin = JaPrep.nameLatin(right, userFile) ?: JaPrep.romanizeKana(right)
        if (left.isEmpty()) return rightLatin
        var leftLatin: String? = null
        for (k in casts) {
            if (left == k || (k.length in 3..5 && left.length == k.length && hamming(left, k) <= 1)) {
                leftLatin = JaPrep.nameLatin(k, userFile); break
            }
        }
        if (leftLatin == null) leftLatin = JaPrep.romanizeKana(left)
        return "$leftLatin=$rightLatin"
    }

    /** Padanan lengkap untuk satu tulisan menu: kamus -> baris nama "A=B". Null bila tidak dikenal. */
    fun resolve(text: String, userFile: File?): String? =
        lookup(text, userFile) ?: nameLine(text, userFile) ?: castOnly(text, userFile)

    /** Nama tokoh sendirian (mis. potongan "アルベイン" atau "クレスロロ=" di layar nama), tanpa/dengan kotak kosong & pemisah. */
    private fun castOnly(text: String, userFile: File?): String? {
        val s = text.replace(Regex("\\s+"), "").trim { it in SEP || it == 'ー' || it in SLOT_JUNK }
        if (s.length < 3 || s.any { it.code !in 0x30A0..0x30FF }) return null
        for (k in JaPrep.castKeys(userFile).sortedByDescending { it.length }) {
            if (s == k || (k.length >= 4 && hamming(s, k) <= 1)) return JaPrep.nameLatin(k, userFile)
        }
        return null
    }

    /** Potongan tulisan menu hasil pemecahan: [from, to) adalah pecahan lebar (0..1) dari teks asal. */
    class Part(val text: String, val from: Float, val to: Float)

    /**
     * Dua tulisan menu sebaris yang terbaca menyatu ("けってい"+"ランダム" -> "けっていランダム") dipecah menurut kamus
     * bila SELURUH teks bisa dibagi menjadi >= 2 entri kamus. Null bila teks itu sendiri entri kamus atau tidak bisa dibagi.
     */
    fun splitKnown(text: String): List<Part>? {
        val chars = text.filter { it.isLetterOrDigit() }
        val n = chars.length
        if (n < 4 || n > 24) return null
        val folded = fold(chars)
        if (folded.length != n || table.containsKey(folded)) return null
        val best = arrayOfNulls<List<Int>>(n + 1)       // best[i] = daftar titik potong untuk awalan sepanjang i
        best[0] = emptyList()
        for (i in 1..n) {
            for (j in 0 until i) {
                val prev = best[j] ?: continue
                if (i - j < 2) continue
                if (table.containsKey(folded.substring(j, i))) {
                    val cand = prev + i
                    val cur = best[i]
                    if (cur == null || cand.size < cur.size) best[i] = cand
                }
            }
        }
        val cuts = best[n] ?: return null
        if (cuts.size < 2) return null
        val out = ArrayList<Part>()
        var a = 0
        for (c in cuts) { out += Part(chars.substring(a, c), a.toFloat() / n, c.toFloat() / n); a = c }
        return out
    }

    private fun distance(a: String, b: String, limit: Int): Int {
        val prev = IntArray(b.length + 1) { it }
        val cur = IntArray(b.length + 1)
        for (i in 1..a.length) {
            cur[0] = i
            var rowMin = cur[0]
            for (j in 1..b.length) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                cur[j] = minOf(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + cost)
                if (cur[j] < rowMin) rowMin = cur[j]
            }
            if (rowMin > limit) return limit + 1
            System.arraycopy(cur, 0, prev, 0, cur.size)
        }
        return prev[b.length]
    }
}
