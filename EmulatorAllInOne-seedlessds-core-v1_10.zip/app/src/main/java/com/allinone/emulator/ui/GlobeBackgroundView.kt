package com.allinone.emulator.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.os.SystemClock
import android.view.Choreographer
import android.view.View
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin
import kotlin.random.Random

/**
 * Latar "gambar hidup" bertema alam (globe kaca di atas lumut): zoom pelan, lumut bergoyang tertiup angin,
 * bokeh hijau melayang, berkas sinar matahari berdenyut, kilap yang menyapu globe, dan serbuk cahaya naik pelan.
 * Semua gerak dihitung dari waktu (bukan hitungan frame), jadi mulus di 60/90/120 Hz. Berhenti otomatis saat tidak terlihat.
 */
class GlobeBackgroundView(context: Context, resId: Int) : View(context) {

    private val bmp: Bitmap = BitmapFactory.decodeResource(
        resources, resId, BitmapFactory.Options().apply { inScaled = false }
    )
    private val IW = bmp.width.toFloat()
    private val IH = bmp.height.toFloat()

    private val add = PorterDuffXfermode(PorterDuff.Mode.ADD)
    private val basePaint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
    private val spritePaint = Paint(Paint.FILTER_BITMAP_FLAG).apply { xfermode = add }
    private val rayPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { xfermode = add }
    private val sweepPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { xfermode = add }

    // mesh: bagian bawah (lumut) bergoyang, bagian atas hampir diam
    private val mw = 24
    private val mh = 30
    private val verts = FloatArray((mw + 1) * (mh + 1) * 2)

    private val rayShader = LinearGradient(
        -1f, 0f, 1f, 0f, intArrayOf(0x00FFFFC8, 0xFFFFFFCD.toInt(), 0x00FFFFC8), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
    )
    private val sweepShader = LinearGradient(
        -1f, 0f, 1f, 0f, intArrayOf(0x00FFFFFF, 0xFFFFFFFF.toInt(), 0x00FFFFFF), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
    )

    private class Bokeh(val x: Float, val y: Float, val r: Float, val vx: Float, val p: Float, val f: Float)
    private class Pollen(val x: Float, val y: Float, val v: Float, val p: Float, val z: Float, val f: Float)
    private val bokeh = ArrayList<Bokeh>()
    private val pollen = ArrayList<Pollen>()
    private val bokehSprite: Bitmap
    private val pollenSprite: Bitmap
    private val glowSprite: Bitmap

    private val dst = RectF()
    private val circle = Path()
    private val t0 = SystemClock.uptimeMillis()
    private var running = false
    private val frame = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            if (!running) return
            invalidate()
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    init {
        fun sprite(rgb: Int, mid: Int, midAt: Float, core: Boolean): Bitmap {
            val s = Bitmap.createBitmap(64, 64, Bitmap.Config.ARGB_8888)
            val p = Paint(Paint.ANTI_ALIAS_FLAG)
            val c = rgb and 0xFFFFFF
            p.shader = RadialGradient(
                32f, 32f, 32f,
                intArrayOf(if (core) 0xFFFFFFFF.toInt() else (mid shl 24) or c, (mid shl 24) or c, c),
                floatArrayOf(0f, midAt, 1f), Shader.TileMode.CLAMP
            )
            Canvas(s).drawCircle(32f, 32f, 32f, p)
            return s
        }
        bokehSprite = sprite(0xE6FFAA, 0xB0, 0.8f, false)
        pollenSprite = sprite(0xEBFF96, 0x70, 0.4f, true)
        glowSprite = sprite(0xFFFFFF, 0x66, 0.45f, true)
        val rnd = Random(5)
        repeat(16) { bokeh += Bokeh(rnd.nextFloat(), rnd.nextFloat() * 0.8f, 0.03f + rnd.nextFloat() * 0.07f, (rnd.nextFloat() - 0.5f) * 0.01f, rnd.nextFloat() * 6.28f, 0.3f + rnd.nextFloat() * 0.5f) }
        repeat(46) { pollen += Pollen(rnd.nextFloat(), rnd.nextFloat(), 0.012f + rnd.nextFloat() * 0.03f, rnd.nextFloat() * 6.28f, 1f + rnd.nextFloat() * 2.2f, 1f + rnd.nextFloat() * 2f) }
    }

    fun start() {
        if (running) return
        running = true
        Choreographer.getInstance().postFrameCallback(frame)
    }

    fun stop() {
        running = false
        Choreographer.getInstance().removeFrameCallback(frame)
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); if (visibility == VISIBLE) start() }
    override fun onDetachedFromWindow() { stop(); super.onDetachedFromWindow() }
    override fun onVisibilityChanged(changedView: View, visibility: Int) {
        super.onVisibilityChanged(changedView, visibility)
        if (visibility == VISIBLE && isAttachedToWindow) start() else stop()
    }

    private fun smooth(a: Float, b: Float, x: Float): Float {
        val t = ((x - a) / (b - a)).coerceIn(0f, 1f); return t * t * (3 - 2 * t)
    }

    private fun glow(canvas: Canvas, sprite: Bitmap, x: Float, y: Float, r: Float, alpha: Float) {
        spritePaint.alpha = (alpha * 255).toInt().coerceIn(0, 255)
        dst.set(x - r, y - r, x + r, y + r)
        canvas.drawBitmap(sprite, null, dst, spritePaint)
    }

    override fun onDraw(canvas: Canvas) {
        val vw = width.toFloat(); val vh = height.toFloat()
        if (vw <= 0f || vh <= 0f) return
        val t = (SystemClock.uptimeMillis() - t0) / 1000f
        val tau = 2f * PI.toFloat()

        // zoom pelan + geser tipis (skala minimum 1.07 supaya tepi tidak terbuka saat lumut bergoyang)
        val z = 1.07f + 0.04f * (0.5f - 0.5f * cos(t * tau / 30f))
        val cover = max(vw / IW, vh / IH) * z
        val dw = IW * cover; val dh = IH * cover
        val dl = (vw - dw) / 2f + sin(t * tau / 37f) * vw * 0.012f
        val dt = (vh - dh) * 0.6f + cos(t * tau / 43f) * vh * 0.006f

        // ---- gambar dasar dengan mesh: makin ke bawah (lumut) makin bergoyang
        var k = 0
        for (j in 0..mh) {
            val fy = j.toFloat() / mh
            val w = smooth(0.68f, 1f, fy)
            for (i in 0..mw) {
                val fx = i.toFloat() / mw
                val ox = w * dw * 0.0045f * (sin(t * 1.1f + fy * 14f + fx * 2f) + 0.4f * sin(t * 2.3f + fy * 22f))
                val oy = w * dh * 0.0015f * sin(t * 1.7f + fx * 9f)
                verts[k] = dl + fx * dw + ox; verts[k + 1] = dt + fy * dh + oy
                k += 2
            }
        }
        canvas.drawBitmapMesh(bmp, mw, mh, verts, 0, null, 0, basePaint)

        fun mx(x: Float) = dl + x * dw
        fun my(y: Float) = dt + y * dh

        // ---- bokeh melayang & berdenyut
        for (b in bokeh) {
            val x = (((b.x + b.vx * t) % 1.2f) + 1.2f) % 1.2f - 0.1f
            val y = b.y + 0.02f * sin(t * b.f + b.p)
            val a = 0.05f + 0.06f * (0.5f + 0.5f * sin(t * b.f * 1.3f + b.p))
            glow(canvas, bokehSprite, mx(x), my(y), b.r * dw, a * 1.6f)
        }

        // ---- berkas sinar matahari miring dari kanan atas, berdenyut
        val rays = arrayOf(floatArrayOf(0.78f, 0.14f, 0f, 0.5f), floatArrayOf(0.90f, 0.10f, 2.4f, 0.7f), floatArrayOf(0.64f, 0.09f, 4.1f, 0.4f))
        for (b in rays) {
            val pulse = 0.5f + 0.5f * sin(t * b[3] + b[2])
            rayPaint.shader = rayShader
            rayPaint.alpha = ((0.05f + 0.10f * pulse) * 255).toInt()
            canvas.save()
            canvas.translate(mx(b[0]), 0f)
            canvas.rotate(21.8f)
            canvas.scale(b[1] * dw, 1f)
            canvas.drawRect(-1f, -vh * 0.3f, 1f, vh * 1.5f, rayPaint)
            canvas.restore()
        }

        // ---- kilap menyapu globe kaca tiap 7 detik + titik pantul yang berdenyut
        val gx = mx(0.37f); val gy = my(0.72f); val gr = dw * 0.208f
        canvas.save()
        circle.rewind(); circle.addCircle(gx, gy, gr, Path.Direction.CW)
        canvas.clipPath(circle)
        val cyc = (t / 7f) % 1f
        canvas.save()
        canvas.translate(gx - gr * 1.6f + cyc * gr * 3.4f, gy)
        canvas.rotate(34f)
        canvas.scale(gr * 0.12f, 1f)
        sweepPaint.shader = sweepShader
        sweepPaint.alpha = 87
        canvas.drawRect(-1f, -gr * 2f, 1f, gr * 2f, sweepPaint)
        canvas.restore()
        glow(canvas, glowSprite, gx - gr * 0.45f, gy - gr * 0.55f, gr * 0.35f, 0.24f + 0.16f * sin(t * 1.4f))
        canvas.restore()

        // ---- serbuk cahaya naik pelan, berkelip
        for (p in pollen) {
            val y = 1.05f - ((p.y + t * p.v) % 1.1f)
            val x = p.x + 0.03f * sin(t * 0.6f * p.f + p.p)
            val s = sin(t * p.f + p.p)
            val a = (0.35f + 0.65f * s * s) * (if (y > 0.1f) 1f else y / 0.1f).coerceIn(0f, 1f)
            glow(canvas, pollenSprite, mx(x), my(y), p.z * dw * 0.012f, a)
        }
    }
}
