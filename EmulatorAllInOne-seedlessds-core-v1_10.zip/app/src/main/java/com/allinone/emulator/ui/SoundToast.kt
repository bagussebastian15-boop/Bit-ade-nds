package com.allinone.emulator.ui

import android.content.Context
import android.widget.Toast

/**
 * Pengganti Toast.makeText: tampilannya sama persis (Toast asli), tetapi bunyi pop up
 * ikut diputar setiap kali pop up dibuat (selalu langsung diikuti .show()).
 * Sengaja TIDAK mewarisi kelas Toast supaya aman dikompilasi di semua versi Android SDK.
 */
object SoundToast {
    @JvmStatic
    fun makeText(ctx: Context, text: CharSequence?, duration: Int): Toast {
        UiSound.playPopup()
        return Toast.makeText(ctx, text, duration)
    }

    @JvmStatic
    fun makeText(ctx: Context, resId: Int, duration: Int): Toast {
        UiSound.playPopup()
        return Toast.makeText(ctx, resId, duration)
    }
}
