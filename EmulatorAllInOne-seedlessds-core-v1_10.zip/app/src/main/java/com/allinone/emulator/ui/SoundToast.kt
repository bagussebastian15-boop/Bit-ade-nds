package com.allinone.emulator.ui

import android.content.Context
import android.widget.Toast

/**
 * Pengganti Toast.makeText: tampilannya sama persis (Toast asli), tetapi setiap kali pop up
 * ditampilkan, bunyi pop up ikut diputar.
 */
class SoundToast private constructor(ctx: Context, private val base: Toast) : Toast(ctx) {
    override fun show() {
        UiSound.playPopup()
        base.show()
    }

    override fun cancel() {
        base.cancel()
    }

    companion object {
        @JvmStatic
        fun makeText(ctx: Context, text: CharSequence?, duration: Int): Toast =
            SoundToast(ctx, Toast.makeText(ctx, text, duration))

        @JvmStatic
        fun makeText(ctx: Context, resId: Int, duration: Int): Toast =
            SoundToast(ctx, Toast.makeText(ctx, resId, duration))
    }
}
