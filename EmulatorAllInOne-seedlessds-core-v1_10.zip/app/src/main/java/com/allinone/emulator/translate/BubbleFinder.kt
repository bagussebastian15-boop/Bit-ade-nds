package com.allinone.emulator.translate

import android.graphics.Bitmap
import android.graphics.Rect
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Mencari KOTAK DIALOG pada game apa pun, apa pun warna dan bentuknya:
 *  - balon putih bergaya komik berisi teks gelap (mis. Comix Zone),
 *  - kotak dialog solid berwarna apa saja (hitam, biru ala RPG, putih, krem, dll.) berisi teks yang kontras,
 *    termasuk kotak lebar di bawah layar yang menempel ke tepi (gaya Pokemon / Dragon Quest / Final Fantasy),
 *  - kotak dialog dengan latar GRADASI (biru tua -> biru muda ala Tales of Phantasia / Final Fantasy SNES), yang tidak
 *    bisa ditemukan lewat satu warna: dicari lewat penelusuran piksel bertetangga yang warnanya berubah pelan.
 * Tiap kotak dibaca OCR sendiri-sendiri pada potongan kecil yang bersih (jauh lebih akurat daripada membaca seluruh
 * layar yang penuh gambar) dan diterjemahkan SEBAGAI SATU BLOK, sehingga satu kotak dialog = satu terjemahan.
 */
object BubbleFinder {

    /** crop = area yang dibaca OCR, cover = area yang ditimpa terjemahan. Keduanya dalam piksel layar game. */
    class Region(val crop: Rect, val cover: Rect)

    private const val SMALL_W = 480
    private const val MAX_COLORS = 6          // jumlah warna dominan yang diperiksa sebagai calon warna kotak
    private const val COLOR_TOLERANCE = 48    // selisih warna (jumlah selisih R+G+B) yang masih dianggap warna kotak yang sama
    private const val TEXT_CONTRAST = 150     // selisih warna minimal agar sebuah piksel dianggap bagian teks/garis
    private const val SMOOTH_STEP = 12        // selisih warna antar piksel bertetangga yang masih dianggap "satu latar gradasi"

    private class Comp(val id: Int, val minX: Int, val maxX: Int, val minY: Int, val maxY: Int, val count: Int)

    fun find(frame: Bitmap): List<Region> {
        val scale = if (frame.width > SMALL_W) SMALL_W.toFloat() / frame.width else 1f
        val w = max(8, (frame.width * scale).toInt())
        val h = max(8, (frame.height * scale).toInt())
        val small = if (scale == 1f) frame else Bitmap.createScaledBitmap(frame, w, h, true)
        val px = IntArray(w * h)
        small.getPixels(px, 0, w, 0, 0, w, h)
        if (small !== frame) small.recycle()

        val n = w * h
        val luma = IntArray(n)
        val bright = BooleanArray(n)
        val keyOf = IntArray(n)
        val keyCount = IntArray(512)
        for (i in 0 until n) {
            val c = px[i]
            val r = (c shr 16) and 0xFF
            val g = (c shr 8) and 0xFF
            val b = c and 0xFF
            luma[i] = (r * 299 + g * 587 + b * 114) / 1000
            bright[i] = luma[i] >= 205 && (max(r, max(g, b)) - min(r, min(g, b))) <= 40
            val k = ((r shr 5) shl 6) or ((g shr 5) shl 3) or (b shr 5)
            keyOf[i] = k
            keyCount[k]++
        }

        val found = ArrayList<Pair<Int, Region>>()

        // 1) Balon putih (komik): teks gelap di dalam area putih.
        found += scan(frame, scale, w, h, bright, { luma[it] < 90 }, 0.35f)

        // 2) Kotak solid berwarna apa saja: ambil beberapa warna paling dominan, lalu cari kotak berwarna itu yang
        //    berisi piksel kontras (teks) di dalamnya.
        val minCount = (n * 0.012f).toInt()
        val keys = (0 until 512).filter { keyCount[it] >= minCount }.sortedByDescending { keyCount[it] }.take(MAX_COLORS)
        for (k in keys) {
            var sr = 0L; var sg = 0L; var sb = 0L; var cnt = 0
            for (i in 0 until n) if (keyOf[i] == k) {
                val c = px[i]
                sr += (c shr 16) and 0xFF; sg += (c shr 8) and 0xFF; sb += c and 0xFF; cnt++
            }
            if (cnt == 0) continue
            val mr = (sr / cnt).toInt(); val mg = (sg / cnt).toInt(); val mb = (sb / cnt).toInt()
            val mask = BooleanArray(n)
            for (i in 0 until n) {
                val c = px[i]
                mask[i] = abs(((c shr 16) and 0xFF) - mr) + abs(((c shr 8) and 0xFF) - mg) + abs((c and 0xFF) - mb) <= COLOR_TOLERANCE
            }
            found += scan(frame, scale, w, h, mask, {
                val c = px[it]
                abs(((c shr 16) and 0xFF) - mr) + abs(((c shr 8) and 0xFF) - mg) + abs((c and 0xFF) - mb) > TEXT_CONTRAST
            }, 0.55f, true)
        }

        // 3) Kotak dengan latar gradasi (warna berubah pelan dari atas ke bawah): satu warna saja tidak cukup.
        found += scanSmooth(frame, scale, w, h, px)

        // Buang kotak ganda (satu kotak bisa terdeteksi dua kali lewat cara berbeda): simpan yang terbesar.
        val kept = ArrayList<Pair<Int, Region>>()
        for (f in found.sortedByDescending { it.first }) {
            val r = f.second.cover
            val dup = kept.any { k ->
                val o = k.second.cover
                val ix = min(r.right, o.right) - max(r.left, o.left)
                val iy = min(r.bottom, o.bottom) - max(r.top, o.top)
                if (ix <= 0 || iy <= 0) false
                else {
                    val inter = ix.toFloat() * iy
                    val smaller = min(r.width().toFloat() * r.height(), o.width().toFloat() * o.height())
                    inter >= 0.6f * smaller
                }
            }
            if (!dup) kept += f
        }
        val boxes = kept.take(4).map {
            reachBorders(frame, scale, w, h, luma, snapToFrame(frame, scale, w, h, luma, extendBox(frame, scale, w, h, px, luma, it.second)))
        }
        return mergeTouching(boxes).sortedBy { it.cover.top }
    }

    // ------------------------------------------------------------------ satu kotak dialog = satu region

    /**
     * Satu kotak dialog sering terdeteksi 2-3 kali dengan ukuran berbeda (mis. potongan atas dari penelusuran gradasi dan
     * potongan bawah dari penelusuran warna). Bila dibiarkan, tiap potongan dibaca dan diterjemahkan sendiri-sendiri sehingga
     * kalimat terbelah atau tampil dua kali. Kotak yang saling beririsan atau bersambung tegak lurus digabung jadi satu.
     */
    private fun mergeTouching(list: List<Region>): List<Region> {
        val out = ArrayList(list)
        var changed = true
        while (changed) {
            changed = false
            loop@ for (i in out.indices) {
                for (j in i + 1 until out.size) {
                    val a = out[i].crop
                    val b = out[j].crop
                    val ix = min(a.right, b.right) - max(a.left, b.left)
                    val iy = min(a.bottom, b.bottom) - max(a.top, b.top)
                    val gapY = max(a.top, b.top) - min(a.bottom, b.bottom)
                    val minW = min(a.width(), b.width())
                    val minH = min(a.height(), b.height())
                    val overlap = ix > 0 && iy > 0
                    val stacked = ix >= minW * 0.5f && gapY in 0..max(2, (minH * 0.12f).toInt())
                    if (!overlap && !stacked) continue
                    val c = Rect(out[i].crop).apply { union(out[j].crop) }
                    val v = Rect(out[i].cover).apply { union(out[j].cover) }
                    out[i] = Region(c, v)
                    out.removeAt(j)
                    changed = true
                    break@loop
                }
            }
        }
        return out
    }

    // ------------------------------------------------------------------ bingkai kotak dialog

    /**
     * Kotak dialog RPG berlatar gelap/gradasi hampir selalu punya bingkai terang tipis (krem/putih/emas). Penelusuran warna
     * sering berhenti sebelum bingkai (gradasi putus, baris terakhir pendek seperti "だ?"), sehingga baris terakhir tidak
     * terbaca dan huruf asli mengintip di tepi. Di sini kotak diperluas sampai TEPAT di dalam bingkai terdekat:
     * ke atas/bawah (maks. 1,5x tinggi kotak) dan ke kiri/kanan (maks. 10% lebar layar, supaya potret tokoh tidak tertutup).
     * Hanya untuk kotak gelap/berwarna; balon putih komik dilewati.
     */
    private fun snapToFrame(frame: Bitmap, scale: Float, w: Int, h: Int, luma: IntArray, r: Region): Region {
        val l = (r.crop.left * scale).toInt().coerceIn(0, w - 2)
        val rt = (r.crop.right * scale).toInt().coerceIn(l + 2, w)
        val inset = ((rt - l) * 0.08f).toInt()
        val xa = l + inset
        val xb = rt - inset
        if (xb - xa < 12) return r
        val top = (r.crop.top * scale).toInt().coerceIn(0, h - 1)
        val bottom = (r.crop.bottom * scale).toInt().coerceIn(top + 1, h)
        val bodyH = bottom - top
        if (bodyH < 4) return r

        var sum = 0L
        var cnt = 0
        for (y in top until bottom) { var x = xa; while (x < xb) { sum += luma[y * w + x]; cnt++; x += 4 } }
        val bgL = (sum / max(1, cnt)).toInt()
        if (bgL > 140) return r
        val bright = max(140, bgL + 70)

        fun isBorderRow(y: Int): Boolean {
            var hit = 0
            for (x in xa until xb) if (luma[y * w + x] >= bright) hit++
            return hit >= (xb - xa) * 0.6f
        }

        val vLimit = max(6, (bodyH * 1.5f).toInt())
        var newBottom = -1
        var y = bottom
        var steps = 0
        while (y < h && steps < vLimit) { if (isBorderRow(y)) { newBottom = y; break }; y++; steps++ }
        var newTop = -1
        y = top - 1
        steps = 0
        while (y >= 0 && steps < vLimit) { if (isBorderRow(y)) { newTop = y + 1; break }; y--; steps++ }

        // Bingkai yang berada DI DALAM kotak = kotak terlalu panjang sampai keluar bingkai (mis. ikut menelan gambar peta
        // di bawah dialog): dipotong tepat di bingkai itu supaya latar terjemahan tidak menutupi gambar game.
        var cutBottom = -1
        y = top + max(2, bodyH / 5)
        while (y < bottom) { if (isBorderRow(y)) { cutBottom = y; break }; y++ }
        var cutTop = -1
        y = bottom - 1 - max(2, bodyH / 5)
        while (y >= top) { if (isBorderRow(y)) { cutTop = y + 1; break }; y-- }
        if (newBottom < 0 && newTop < 0 && cutBottom < 0 && cutTop < 0) return r

        val crop = Rect(r.crop)
        val cover = Rect(r.cover)
        if (cutBottom >= 0) {
            val cb = (cutBottom / scale).toInt().coerceIn(crop.top + 2, frame.height)
            crop.bottom = min(crop.bottom, cb); cover.bottom = min(cover.bottom, cb)
        }
        if (cutTop >= 0) {
            val ct = (cutTop / scale).toInt().coerceIn(0, crop.bottom - 2)
            crop.top = max(crop.top, ct); cover.top = max(cover.top, ct)
        }
        if (newBottom >= 0 && cutBottom < 0) {
            val nb = (newBottom / scale).toInt().coerceIn(crop.top + 2, frame.height)
            crop.bottom = max(crop.bottom, nb); cover.bottom = max(cover.bottom, nb)
        }
        if (newTop >= 0 && cutTop < 0) {
            val nt = (newTop / scale).toInt().coerceIn(0, crop.bottom - 2)
            crop.top = min(crop.top, nt); cover.top = min(cover.top, nt)
        }

        // Kiri/kanan: cari kolom bingkai tegak yang dekat (selisih kecil), dihitung pada tinggi kotak yang sudah diperluas.
        val ya = (crop.top * scale).toInt().coerceIn(0, h - 2)
        val yb = (crop.bottom * scale).toInt().coerceIn(ya + 1, h)
        fun isBorderCol(x: Int): Boolean {
            var hit = 0
            for (yy in ya until yb) if (luma[yy * w + x] >= bright) hit++
            return hit >= (yb - ya) * 0.6f
        }
        val hLimit = max(4, (w * 0.10f).toInt())
        var x = l - 1
        steps = 0
        while (x >= 0 && steps < hLimit) {
            if (isBorderCol(x)) { val nl = ((x + 1) / scale).toInt().coerceIn(0, crop.right - 2); crop.left = min(crop.left, nl); cover.left = min(cover.left, nl); break }
            x--; steps++
        }
        x = rt
        steps = 0
        while (x < w && steps < hLimit) {
            if (isBorderCol(x)) { val nr = (x / scale).toInt().coerceIn(crop.left + 2, frame.width); crop.right = max(crop.right, nr); cover.right = max(cover.right, nr); break }
            x++; steps++
        }
        return Region(crop, cover)
    }

    // ------------------------------------------------------------------ kotak yang terdeteksi separuh (kiri/kanan)

    /**
     * Kotak dialog kadang terdeteksi hanya separuh LEBAR (mis. tepi kiri melompat ke tengah karena huruf di salah satu baris
     * memutus latar). Akibatnya OCR hanya membaca separuh kalimat dan terjemahan menutupi separuh kotak saja, sedangkan huruf
     * Jepang di separuh lainnya tetap terlihat. Di sini kotak gelap diperluas ke kiri/kanan SELAMA kolom di sebelahnya masih
     * berupa latar kotak yang sama (rata atau berisi huruf terang) dan berhenti tepat di bingkai terang kotak. Bila ketemu
     * gambar lain (potret tokoh, peta) sebelum bingkai, kotak dibiarkan apa adanya.
     */
    private fun reachBorders(frame: Bitmap, scale: Float, w: Int, h: Int, luma: IntArray, r: Region): Region {
        val l = (r.crop.left * scale).toInt().coerceIn(0, w - 2)
        val rt = (r.crop.right * scale).toInt().coerceIn(l + 2, w)
        val ya = (r.crop.top * scale).toInt().coerceIn(0, h - 2)
        val yb = (r.crop.bottom * scale).toInt().coerceIn(ya + 1, h)
        val bodyH = yb - ya
        if (bodyH < 8 || rt - l < 12) return r
        val y0 = ya + bodyH / 8
        val y1 = yb - bodyH / 8
        val rows = y1 - y0
        if (rows < 4) return r
        val bandA = l + (rt - l) / 8
        val bandB = rt - (rt - l) / 8
        if (bandB - bandA < 6) return r
        val rowBg = IntArray(rows)
        var sum = 0L
        for (y in y0 until y1) {
            val vals = IntArray(bandB - bandA) { luma[y * w + bandA + it] }
            vals.sort()
            rowBg[y - y0] = vals[vals.size / 2]
            sum += rowBg[y - y0]
        }
        val bgL = (sum / rows).toInt()
        if (bgL > 140) return r                       // balon putih komik / kotak terang: tidak dipakai
        val bright = max(140, bgL + 70)
        fun borderCol(x: Int): Boolean {
            var c = 0
            for (y in y0 until y1) if (luma[y * w + x] >= bright) c++
            return c >= rows * 0.7f
        }
        fun boxCol(x: Int): Boolean {
            var c = 0
            for (y in y0 until y1) { val v = luma[y * w + x]; if (v >= bright || abs(v - rowBg[y - y0]) <= 30) c++ }
            return c >= rows * 0.75f
        }
        val reach = (w * 0.7f).toInt()
        var nl = -1
        var x = l - 1
        var steps = 0
        while (x >= 0 && steps < reach) {
            if (borderCol(x)) { nl = x + 1; break }
            if (!boxCol(x)) break
            x--; steps++
        }
        var nr = -1
        x = rt
        steps = 0
        while (x < w && steps < reach) {
            if (borderCol(x)) { nr = x; break }
            if (!boxCol(x)) break
            x++; steps++
        }
        if ((nl < 0 || nl >= l - 2) && (nr < 0 || nr <= rt + 2)) return r
        val crop = Rect(r.crop)
        val cover = Rect(r.cover)
        if (nl in 0 until l - 2) {
            val v = (nl / scale).toInt().coerceIn(0, crop.right - 2)
            crop.left = min(crop.left, v); cover.left = min(cover.left, v)
        }
        if (nr > rt + 2) {
            val v = (nr / scale).toInt().coerceIn(crop.left + 2, frame.width)
            crop.right = max(crop.right, v); cover.right = max(cover.right, v)
        }
        return Region(crop, cover)
    }

    // ------------------------------------------------------------------ perluasan kotak (kotak dua warna / terpotong)

    private const val EXT_FLAT = 28        // selisih terang yang masih dianggap "latar yang sama" dalam satu baris
    private const val EXT_INK = 70         // selisih terang minimal agar piksel dianggap huruf
    private const val EXT_LUMA_STEP = 60   // beda terang latar baris lanjutan vs kotak asli yang masih dianggap satu kotak
    private const val EXT_COLOR_STEP = 150 // beda warna (R+G+B) latar baris lanjutan vs kotak asli

    private class RowStat(val ok: Boolean, val medL: Int, val r: Int, val g: Int, val b: Int, val ink: Int)

    /** Statistik satu baris pada jalur tengah kotak: latar rata + huruf = baris kotak; gambar ramai = bukan. */
    private fun rowStat(px: IntArray, luma: IntArray, w: Int, y: Int, xa: Int, xb: Int): RowStat {
        val n = xb - xa
        val ls = IntArray(n) { luma[y * w + xa + it] }
        // Latar = terang yang paling sering muncul (bukan median): pada baris yang penuh huruf tebal, median bergeser ke
        // warna huruf. Dua kotak histogram bersebelahan digabung supaya latar yang bergradasi tipis tetap satu puncak.
        val hist = IntArray(17)
        for (v in ls) hist[v shr 4]++
        var bestBin = 0; var bestSum = -1
        for (i in 0 until 16) if (hist[i] + hist[i + 1] > bestSum) { bestSum = hist[i] + hist[i + 1]; bestBin = i }
        val inBin = ls.filter { (it shr 4) == bestBin || (it shr 4) == bestBin + 1 }.sorted()
        val medL = if (inBin.isEmpty()) ls.sortedArray()[n / 2] else inBin[inBin.size / 2]
        var flat = 0; var ink = 0
        var sr = 0L; var sg = 0L; var sb = 0L
        for (i in 0 until n) {
            val d = abs(ls[i] - medL)
            if (d <= EXT_FLAT) {
                flat++
                val c = px[y * w + xa + i]
                sr += (c shr 16) and 0xFF; sg += (c shr 8) and 0xFF; sb += c and 0xFF
            } else if (d > EXT_INK) ink++
        }
        if (flat == 0) return RowStat(false, medL, 0, 0, 0, ink)
        return RowStat((flat + ink) >= n * 0.85f, medL, (sr / flat).toInt(), (sg / flat).toInt(), (sb / flat).toInt(), ink)
    }

    /**
     * Kotak dialog kadang terdeteksi SEPARUH: latarnya berganti warna di tengah (mis. biru muda di atas, abu-abu di bawah,
     * atau satu baris teks jatuh di atas bagian layar yang berbeda), sehingga baris di luar bagian yang terdeteksi tidak
     * terbaca OCR dan teks aslinya tidak tertimpa. Di sini kotak diperluas ke atas/bawah selama baris berikutnya masih
     * "baris kotak": latar rata (boleh beda warna/terang sedikit) berisi huruf, di jalur tengah kotak. Gambar ramai,
     * langit berwarna, dan baris tanpa huruf tidak ikut. Perluasan dibatasi setinggi kotak semula.
     */
    private fun extendBox(frame: Bitmap, scale: Float, w: Int, h: Int, px: IntArray, luma: IntArray, r: Region): Region {
        val l = (r.crop.left * scale).toInt().coerceIn(0, w - 2)
        val rt = (r.crop.right * scale).toInt().coerceIn(l + 2, w)
        val inset = ((rt - l) * 0.08f).toInt()
        val xa = l + inset
        val xb = rt - inset
        if (xb - xa < 12) return r
        val top = (r.crop.top * scale).toInt().coerceIn(0, h - 1)
        val bottom = (r.crop.bottom * scale).toInt().coerceIn(top + 1, h)
        val bodyH = bottom - top
        if (bodyH < 4) return r

        // Warna/terang acuan = rata-rata latar baris-baris kotak asli.
        var cnt = 0; var aL = 0L; var aR = 0L; var aG = 0L; var aB = 0L
        for (y in top until bottom) {
            val st = rowStat(px, luma, w, y, xa, xb)
            if (!st.ok) continue
            cnt++; aL += st.medL; aR += st.r; aG += st.g; aB += st.b
        }
        if (cnt < 2) return r
        val refL = (aL / cnt).toInt(); val refR = (aR / cnt).toInt(); val refG = (aG / cnt).toInt(); val refB = (aB / cnt).toInt()
        val refSat = max(refR, max(refG, refB)) - min(refR, min(refG, refB))

        fun isBoxRow(st: RowStat): Boolean {
            if (!st.ok) return false
            if (abs(st.medL - refL) > EXT_LUMA_STEP) return false
            if (abs(st.r - refR) + abs(st.g - refG) + abs(st.b - refB) > EXT_COLOR_STEP) return false
            val sat = max(st.r, max(st.g, st.b)) - min(st.r, min(st.g, st.b))
            return sat <= refSat + 40
        }

        /** Arah dir = +1 (bawah) / -1 (atas). Mengembalikan baris terakhir yang masih bagian kotak, atau null. */
        fun grow(from: Int, dir: Int): Int? {
            val limit = max(4, bodyH)
            var y = from
            var last = -1
            var misses = 0
            var rows = 0
            var inkSum = 0L
            var keptRows = 0
            var keptInk = 0L
            while (y in 0 until h && rows < limit) {
                val st = rowStat(px, luma, w, y, xa, xb)
                if (isBoxRow(st)) { last = y; misses = 0; keptRows = rows + 1; inkSum += st.ink; keptInk = inkSum }
                else { misses++; if (misses > 3) break }
                rows++
                y += dir
            }
            if (last < 0 || keptRows < 3) return null
            // Bagian tambahan harus berisi huruf; kalau hanya latar polos/gambar, jangan diperluas.
            if (keptInk.toFloat() / ((xb - xa).toFloat() * keptRows) < 0.005f) return null
            return last
        }

        val down = grow(bottom, 1)
        val up = grow(top - 1, -1)
        if (down == null && up == null) return r

        val crop = Rect(r.crop)
        val cover = Rect(r.cover)
        if (down != null) {
            // Sisa beberapa piksel sampai tepi layar = ujung kotak yang memudar/melengkung: sekalian ditutup.
            val nb = if (h - 1 - down <= max(4, (h * 0.03f).toInt())) frame.height
                     else ((down + 1) / scale).toInt().coerceIn(crop.top + 2, frame.height)
            crop.bottom = max(crop.bottom, nb)
            cover.bottom = max(cover.bottom, nb)
        }
        if (up != null) {
            val nt = if (up <= max(4, (h * 0.03f).toInt())) 0 else (up / scale).toInt().coerceIn(0, crop.bottom - 2)
            crop.top = min(crop.top, nt)
            cover.top = min(cover.top, nt)
        }
        return Region(crop, cover)
    }

    /**
     * Cari kotak (komponen terhubung dari [mask]) yang berbentuk dialog: cukup besar, hampir persegi penuh,
     * dan berisi piksel kontras ([isText]) dalam jumlah wajar.
     */
    private fun scan(
        frame: Bitmap, scale: Float, w: Int, h: Int,
        mask: BooleanArray, isText: (Int) -> Boolean, minFill: Float, trim: Boolean = false
    ): List<Pair<Int, Region>> {
        val label = IntArray(w * h)
        val queue = IntArray(w * h)
        val comps = ArrayList<Comp>()
        var next = 0
        for (start in 0 until w * h) {
            if (!mask[start] || label[start] != 0) continue
            next++
            var head = 0
            var tail = 0
            queue[tail++] = start
            label[start] = next
            var minX = w
            var maxX = 0
            var minY = h
            var maxY = 0
            var count = 0
            while (head < tail) {
                val p = queue[head++]
                val x = p % w
                val y = p / w
                count++
                if (x < minX) minX = x
                if (x > maxX) maxX = x
                if (y < minY) minY = y
                if (y > maxY) maxY = y
                if (x > 0 && mask[p - 1] && label[p - 1] == 0) { label[p - 1] = next; queue[tail++] = p - 1 }
                if (x < w - 1 && mask[p + 1] && label[p + 1] == 0) { label[p + 1] = next; queue[tail++] = p + 1 }
                if (y > 0 && mask[p - w] && label[p - w] == 0) { label[p - w] = next; queue[tail++] = p - w }
                if (y < h - 1 && mask[p + w] && label[p + w] == 0) { label[p + w] = next; queue[tail++] = p + w }
            }
            if (count >= 200) comps += Comp(next, minX, maxX, minY, maxY, count)
        }

        val out = ArrayList<Pair<Int, Region>>()
        for (c in comps) {
            val bw = c.maxX - c.minX + 1
            val bh = c.maxY - c.minY + 1
            val area = bw * bh
            if (area < w * h * 0.012f || area > w * h * 0.40f) continue
            if (bw < w * 0.08f || bh < h * 0.04f) continue
            // Kotak dialog di bawah/atas layar boleh menempel ke tepi dan lebar penuh; yang ditolak hanya area tinggi
            // yang menempel ke tepi (margin/halaman komik, langit, latar).
            val touches = c.minX == 0 || c.minY == 0 || c.maxX == w - 1 || c.maxY == h - 1
            if (touches && bh > h * 0.5f) continue
            if (c.count.toFloat() / area < minFill) continue                 // bingkai berlubang, bukan kotak

            var ink = 0
            for (y in c.minY..c.maxY) {
                val row = y * w
                for (x in c.minX..c.maxX) if (isText(row + x)) ink++
            }
            val inkRatio = ink.toFloat() / area
            if (inkRatio < 0.04f || inkRatio > 0.45f) continue               // harus ada teks (kontras) di dalamnya

            makeRegion(frame, scale, w, label, c, trim = trim)?.let { out += area to it }
        }
        return out
    }

    /**
     * Badan kotak = baris-baris yang lebarnya mendekati maksimum (ekor balon dibuang), lalu diubah ke koordinat layar game.
     * [label] berisi nomor komponen tiap piksel; [c] komponen yang sudah lolos pemeriksaan bentuk.
     */
    private fun makeRegion(
        frame: Bitmap, scale: Float, w: Int, label: IntArray, c: Comp,
        cropInsetX: Float = 0.02f, cropInsetY: Float = 0.03f, trim: Boolean = false
    ): Region? {
        val bh = c.maxY - c.minY + 1
        val rowCount = IntArray(bh)
        for (y in c.minY..c.maxY) {
            val row = y * w
            for (x in c.minX..c.maxX) if (label[row + x] == c.id) rowCount[y - c.minY]++
        }
        val maxRow = rowCount.max()
        var y0 = -1
        var y1 = -1
        for (i in 0 until bh) if (rowCount[i] >= maxRow * 0.6f) { if (y0 < 0) y0 = i; y1 = i }
        if (y0 < 0) return null
        var x0 = w
        var x1 = 0
        for (y in (c.minY + y0)..(c.minY + y1)) {
            val row = y * w
            for (x in c.minX..c.maxX) if (label[row + x] == c.id) { if (x < x0) x0 = x; if (x > x1) x1 = x }
        }
        // Kotak persegi yang sebagian tertutup potret tokoh (RPG/novel visual): tepi kiri/kanan kotak tidak rata karena
        // potret menjorok ke dalam. Pakai tepi paling dalam di semua baris supaya potret tidak ikut terbaca OCR dan
        // tidak tertimpa latar terjemahan. Tidak dipakai untuk balon komik (bentuk elips, tepinya memang melengkung).
        if (trim && y1 - y0 >= 6) {
            val skip = max(1, (y1 - y0 + 1) / 10)
            var lMax = x0
            var rMin = x1
            for (y in (c.minY + y0 + skip)..(c.minY + y1 - skip)) {
                val row = y * w
                var l = -1
                for (x in c.minX..c.maxX) if (label[row + x] == c.id) { l = x; break }
                var r = -1
                for (x in c.maxX downTo c.minX) if (label[row + x] == c.id) { r = x; break }
                if (l > lMax) lMax = l
                if (r in 0 until rMin) rMin = r
            }
            if (rMin - lMax + 1 >= (x1 - x0 + 1) * 0.5f) { x0 = lMax; x1 = rMin }
        }
        val bodyW = x1 - x0 + 1
        val bodyH = y1 - y0 + 1
        if (bodyW < 8 || bodyH < 5) return null
        val top = c.minY + y0

        fun rect(insetX: Float, insetY: Float): Rect {
            val l = (x0 + bodyW * insetX) / scale
            val t = (top + bodyH * insetY) / scale
            val r = (x1 + 1 - bodyW * insetX) / scale
            val b = (top + bodyH - bodyH * insetY) / scale
            val left = l.toInt().coerceIn(0, frame.width - 2)
            val tp = t.toInt().coerceIn(0, frame.height - 2)
            return Rect(
                left, tp,
                r.toInt().coerceIn(left + 1, frame.width),
                b.toInt().coerceIn(tp + 1, frame.height)
            )
        }
        return Region(rect(cropInsetX, cropInsetY), rect(maxOf(cropInsetX, 0.07f * cropInsetX / 0.02f), maxOf(cropInsetY, 0.09f * cropInsetY / 0.03f)))
    }

    private fun near(a: Int, b: Int): Boolean =
        abs(((a shr 16) and 0xFF) - ((b shr 16) and 0xFF)) + abs(((a shr 8) and 0xFF) - ((b shr 8) and 0xFF)) +
            abs((a and 0xFF) - (b and 0xFF)) <= SMOOTH_STEP

    /**
     * Kotak dialog dengan latar GRADASI. Piksel bertetangga yang warnanya hampir sama dihubungkan, jadi latar yang
     * berubah pelan (biru tua -> biru muda) tetap satu komponen, sedangkan huruf, bingkai kotak, dan gambar peta
     * yang ramai memutus/memecahnya. Teks = piksel yang jauh berbeda dari warna latar BARIS yang sama.
     */
    private fun scanSmooth(frame: Bitmap, scale: Float, w: Int, h: Int, px: IntArray): List<Pair<Int, Region>> {
        val n = w * h
        val label = IntArray(n)
        val queue = IntArray(n)
        val out = ArrayList<Pair<Int, Region>>()
        var next = 0
        for (start in 0 until n) {
            if (label[start] != 0) continue
            next++
            var head = 0
            var tail = 0
            queue[tail++] = start
            label[start] = next
            var minX = w
            var maxX = 0
            var minY = h
            var maxY = 0
            while (head < tail) {
                val p = queue[head++]
                val x = p % w
                val y = p / w
                if (x < minX) minX = x
                if (x > maxX) maxX = x
                if (y < minY) minY = y
                if (y > maxY) maxY = y
                val cp = px[p]
                if (x > 0 && label[p - 1] == 0 && near(cp, px[p - 1])) { label[p - 1] = next; queue[tail++] = p - 1 }
                if (x < w - 1 && label[p + 1] == 0 && near(cp, px[p + 1])) { label[p + 1] = next; queue[tail++] = p + 1 }
                if (y > 0 && label[p - w] == 0 && near(cp, px[p - w])) { label[p - w] = next; queue[tail++] = p - w }
                if (y < h - 1 && label[p + w] == 0 && near(cp, px[p + w])) { label[p + w] = next; queue[tail++] = p + w }
            }
            val count = tail
            if (count < 400) continue
            val bw = maxX - minX + 1
            val bh = maxY - minY + 1
            val area = bw * bh
            if (area < w * h * 0.012f || area > w * h * 0.40f) continue
            if (bw < w * 0.25f || bh < h * 0.10f) continue             // kotak dialog gradasi: lebar dan tinggi layar yang wajar
            val touches = minX == 0 || minY == 0 || maxX == w - 1 || maxY == h - 1
            if (touches && bh > h * 0.5f) continue
            if (count.toFloat() / area < 0.6f) continue

            // Warna latar rata-rata tiap baris (hanya piksel komponen ini), lalu hitung piksel teks = jauh dari warna itu.
            val rr = IntArray(bh); val rg = IntArray(bh); val rb = IntArray(bh); val rn = IntArray(bh)
            for (y in minY..maxY) {
                val row = y * w
                for (x in minX..maxX) if (label[row + x] == next) {
                    val c = px[row + x]
                    rr[y - minY] += (c shr 16) and 0xFF; rg[y - minY] += (c shr 8) and 0xFF; rb[y - minY] += c and 0xFF; rn[y - minY]++
                }
            }
            var ink = 0
            for (y in minY..maxY) {
                val i = y - minY
                if (rn[i] == 0) continue
                val mr = rr[i] / rn[i]; val mg = rg[i] / rn[i]; val mb = rb[i] / rn[i]
                val row = y * w
                for (x in minX..maxX) {
                    val c = px[row + x]
                    if (abs(((c shr 16) and 0xFF) - mr) + abs(((c shr 8) and 0xFF) - mg) + abs((c and 0xFF) - mb) > TEXT_CONTRAST) ink++
                }
            }
            val inkRatio = ink.toFloat() / area
            if (inkRatio < 0.03f || inkRatio > 0.45f) continue              // harus ada teks (kontras) di dalamnya

            // Tepi komponen = bagian dalam bingkai kotak, jadi tidak perlu disisakan margin besar (huruf pertama sering menempel ke tepi).
            makeRegion(frame, scale, w, label, Comp(next, minX, maxX, minY, maxY, count), 0.004f, 0.01f, true)?.let { out += area to it }
        }
        return out
    }
}
