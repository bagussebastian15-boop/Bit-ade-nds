package com.allinone.emulator.net

import android.os.Handler
import android.os.Looper
import java.io.InputStream
import java.io.OutputStream
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket

/**
 * Chat teks antar dua pemain multiplayer. Jalur terpisah dari netplay rollback (yang hanya membawa input dan stiker):
 * satu koneksi TCP kecil di port netplay + 1. Host membuka port, tamu menyambung ke IP host yang sama dengan netplay.
 *
 * Protokol: baris teks UTF-8 berakhir "\n". Baris pertama dari tamu "SDSCHAT1", dibalas host dengan baris yang sama;
 * sesudahnya setiap baris adalah satu pesan (maks [MAX_LEN] karakter).
 *
 * Keamanan dasar: host hanya menerima sambungan ketika netplay sudah menyambung ke lawan ([allowAccept]) dan hanya satu
 * sambungan aktif; baris dibatasi panjangnya; karakter kontrol dibuang; pesan masuk dibatasi lajunya.
 * Semua callback dipanggil di thread utama.
 */
class NetplayChat(
    private val allowAccept: () -> Boolean,
    private val onMessage: (String) -> Unit,
    private val onConnected: (Boolean) -> Unit
) {
    private val main = Handler(Looper.getMainLooper())

    @Volatile private var running = false
    @Volatile private var generation = 0          // dinaikkan tiap start/stop supaya thread lama berhenti sendiri
    @Volatile private var server: ServerSocket? = null
    @Volatile private var sock: Socket? = null
    @Volatile private var out: OutputStream? = null
    private val sendLock = Any()

    val connected: Boolean get() = out != null

    /** Host: buka port chat dan terima satu lawan. */
    fun startHost(port: Int) {
        stop()
        running = true
        val gen = ++generation
        Thread {
            val ss = try {
                ServerSocket().apply { reuseAddress = true; bind(InetSocketAddress(port)) }
            } catch (_: Exception) { return@Thread }   // port chat gagal dibuka: game tetap jalan tanpa chat
            server = ss
            while (running && gen == generation) {
                val s = try { ss.accept() } catch (_: Exception) { break }
                if (!allowAccept() || sock != null) { closeQuietly(s); continue }
                try {
                    s.tcpNoDelay = true
                    s.soTimeout = 5000
                    val inp = s.getInputStream()
                    if (readLine(inp) != HELLO) { closeQuietly(s); continue }
                    s.getOutputStream().apply { write((HELLO + "\n").toByteArray()); flush() }
                    serve(s, gen)       // blokir sampai sambungan putus, lalu lanjut menerima lagi
                } catch (_: Exception) { closeQuietly(s) }
            }
        }.also { it.isDaemon = true; it.name = "ChatHost" }.start()
    }

    /** Tamu: sambung ke host; coba lagi tiap beberapa detik sampai berhasil atau [stop]. */
    fun startClient(ip: String, port: Int) {
        stop()
        running = true
        val gen = ++generation
        Thread {
            while (running && gen == generation) {
                val s = Socket()
                try {
                    s.connect(InetSocketAddress(ip, port), 3000)
                    s.tcpNoDelay = true
                    s.soTimeout = 5000
                    s.getOutputStream().apply { write((HELLO + "\n").toByteArray()); flush() }
                    if (readLine(s.getInputStream()) != HELLO) { closeQuietly(s) }
                    else serve(s, gen)
                } catch (_: Exception) { closeQuietly(s) }
                if (!(running && gen == generation)) break
                try { Thread.sleep(2000) } catch (_: InterruptedException) { break }
            }
        }.also { it.isDaemon = true; it.name = "ChatClient" }.start()
    }

    /** Kirim satu pesan. Mengembalikan false bila belum tersambung atau pesan kosong. */
    fun send(text: String): Boolean {
        val clean = sanitize(text) ?: return false
        val o = out ?: return false
        Thread {
            try {
                synchronized(sendLock) { o.write((clean + "\n").toByteArray(Charsets.UTF_8)); o.flush() }
            } catch (_: Exception) { closeQuietly(sock) }
        }.also { it.isDaemon = true }.start()
        return true
    }

    fun stop() {
        running = false
        generation++
        closeQuietly(server); server = null
        closeQuietly(sock)
        sock = null; out = null
    }

    /** Baca pesan dari satu sambungan sampai putus. */
    private fun serve(s: Socket, gen: Int) {
        sock = s
        out = s.getOutputStream()
        s.soTimeout = 0                       // pesan bisa jarang datang; putus terdeteksi lewat EOF/RST
        main.post { onConnected(true) }
        var lastIn = 0L
        try {
            val inp = s.getInputStream()
            while (running && gen == generation) {
                val line = readLine(inp) ?: break
                val msg = sanitize(line) ?: continue
                val now = System.currentTimeMillis()
                if (now - lastIn < MIN_INTERVAL_MS) continue   // banjir pesan: buang
                lastIn = now
                main.post { onMessage(msg) }
            }
        } catch (_: Exception) {
        } finally {
            closeQuietly(s)
            if (sock === s) { sock = null; out = null }
            main.post { onConnected(false) }
        }
    }

    /** Baca satu baris dengan batas panjang (tanpa BufferedReader.readLine yang tidak dibatasi). null = EOF/terlalu panjang. */
    private fun readLine(inp: InputStream): String? {
        val buf = java.io.ByteArrayOutputStream()
        while (true) {
            val b = inp.read()
            if (b < 0) return null
            if (b == '\n'.code) break
            if (b != '\r'.code) buf.write(b)
            if (buf.size() > MAX_LINE_BYTES) return null
        }
        return String(buf.toByteArray(), Charsets.UTF_8)
    }

    private fun closeQuietly(c: java.io.Closeable?) { try { c?.close() } catch (_: Exception) {} }

    companion object {
        private const val HELLO = "SDSCHAT1"
        const val MAX_LEN = 200
        private const val MAX_LINE_BYTES = 1024
        private const val MIN_INTERVAL_MS = 150L

        /** Buang karakter kontrol, rapikan spasi, batasi panjang. null bila hasilnya kosong. */
        fun sanitize(raw: String): String? {
            val t = raw.filter { !it.isISOControl() }.trim().take(MAX_LEN)
            return t.ifEmpty { null }
        }
    }
}
