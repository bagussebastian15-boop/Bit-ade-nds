package com.allinone.emulator.ui

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.webkit.CookieManager
import android.webkit.URLUtil
import android.widget.Toast
import com.allinone.emulator.R
import com.allinone.emulator.data.Console
import com.allinone.emulator.data.Paths
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import android.view.Gravity
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

/** Membuka situs game online di dalam aplikasi (WebView). */
class WebActivity : AppCompatActivity() {

    private lateinit var web: WebView
    private lateinit var loadBar: ProgressBar
    private lateinit var natureBg: NatureBackgroundView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val url = intent.getStringExtra(EXTRA_URL) ?: DEFAULT_URL
        val query = intent.getStringExtra(EXTRA_QUERY).orEmpty().trim()
        val queryConsole = intent.getStringExtra(EXTRA_QUERY_CONSOLE).orEmpty()
        queryTag = intent.getStringExtra(EXTRA_QUERY_TAG).orEmpty()

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(4), dp(8), dp(4))
        }
        bar.addView(TextView(this).apply {
            text = "ROMS Library. Emulator ini hanya menjalankan game dari konsol SNES, GBA, Genesis, Nintendo DS, dan MAME. Jadi download ROM game dari konsol-konsol itu."
            textSize = 14f
            setTextColor(android.graphics.Color.WHITE); shade()
            background = glass(6); setPadding(dp(12), dp(7), dp(12), dp(7))
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { rightMargin = dp(6) })
        bar.addView(Button(this).apply {
            text = "Muat ulang"; aeroButton()
            setOnClickListener { web.reload() }
        })
        bar.addView(Button(this).apply {
            text = "Tutup"; aeroButton()
            setOnClickListener { finish() }
        })

        var queryLine: TextView? = null
        if (query.isNotEmpty()) {
            // Cadangan bila kolom pencarian situs tidak bisa diisi otomatis: nama game sudah ada di clipboard, tinggal tempel.
            try {
                val cm = getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                cm.setPrimaryClip(android.content.ClipData.newPlainText("game", query))
            } catch (_: Exception) {}
            queryLine = TextView(this).apply {
                text = "Game room: $query" + if (queryConsole.isNotEmpty()) " ($queryConsole)" else ""
                textSize = 12f
                setTextColor(android.graphics.Color.WHITE); shade()
                background = glass(6); setPadding(dp(12), dp(3), dp(12), dp(3))
            }
        }

        loadBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
        }

        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            settings.loadWithOverviewMode = true
            settings.useWideViewPort = true
            webViewClient = object : WebViewClient() {
                // Tautan tetap dibuka di dalam aplikasi
                override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest) = false
                override fun onPageStarted(view: WebView, url: String?, favicon: Bitmap?) {
                    loadBar.visibility = android.view.View.VISIBLE
                }
                override fun onPageFinished(view: WebView, url: String?) {
                    loadBar.visibility = android.view.View.GONE
                    if (query.isNotEmpty() && !queryFilled) { searchQuery = query; fillSearch(query) }
                }
            }
            webChromeClient = object : WebChromeClient() {
                override fun onProgressChanged(view: WebView, newProgress: Int) {
                    loadBar.progress = newProgress
                }
            }
        }

        // Unduhan dari situs langsung disimpan ke penyimpanan aplikasi (tanpa DownloadManager / izin tambahan)
        web.setDownloadListener { dlUrl, userAgent, contentDisposition, mimeType, _ ->
            startDownload(dlUrl, userAgent, contentDisposition, mimeType)
        }

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(bar)
        queryLine?.let { root.addView(it, LinearLayout.LayoutParams(-2, -2).apply { setMargins(dp(16), dp(2), dp(16), dp(4)) }) }
        root.addView(loadBar, LinearLayout.LayoutParams(-1, dp(3)))
        root.addView(web, LinearLayout.LayoutParams(-1, 0, 1f))
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val i = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            v.setPadding(i.left, i.top, i.right, i.bottom)
            WindowInsetsCompat.CONSUMED
        }
        // Latar hidup (globe kaca di atas lumut) di balik bilah atas; WebView menutupi sisanya
        natureBg = NatureBackgroundView(this, R.drawable.bg_nature)
        setContentView(FrameLayout(this).apply {
            setBackgroundColor(android.graphics.Color.BLACK)
            addView(natureBg, FrameLayout.LayoutParams(-1, -1))
            addView(root, FrameLayout.LayoutParams(-1, -1))
        })

        // Tombol Kembali: mundur di riwayat web dulu, baru keluar
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (web.canGoBack()) web.goBack() else finish()
            }
        })

        if (savedInstanceState == null) web.loadUrl(url) else web.restoreState(savedInstanceState)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        web.saveState(outState)
    }

    override fun onPause() { natureBg.stop(); super.onPause(); web.onPause() }
    override fun onResume() { super.onResume(); natureBg.start(); web.onResume() }

    override fun onDestroy() {
        (web.parent as? ViewGroup)?.removeView(web)
        web.destroy()
        super.onDestroy()
    }

    private val main = Handler(Looper.getMainLooper())
    private var queryFilled = false

    /**
     * Isi kolom pencarian situs dengan nama game dari room (situs berupa aplikasi web yang memuat belakangan,
     * jadi dicoba beberapa kali sampai kolomnya ada). Nama game juga sudah disalin ke clipboard sebagai cadangan.
     */
    private fun fillSearch(q: String, attempt: Int = 0) {
        if (queryFilled || attempt > 12) {
            if (!queryFilled) toast("Kolom pencarian tidak ditemukan. Nama game sudah disalin, tempel di kolom pencarian.")
            return
        }
        val js = """
            (function(q){
              var els=[].slice.call(document.querySelectorAll('input[type=search],input[type=text],input:not([type]),textarea'));
              var el=null;
              for (var i=0;i<els.length;i++){ if (els[i].offsetParent!==null && !els[i].disabled && !els[i].readOnly){ el=els[i]; break; } }
              if(!el) return 'none';
              el.focus();
              var proto=Object.getPrototypeOf(el);
              var d=Object.getOwnPropertyDescriptor(proto,'value');
              if(d&&d.set){ d.set.call(el,q); } else { el.value=q; }
              el.dispatchEvent(new Event('input',{bubbles:true}));
              el.dispatchEvent(new Event('change',{bubbles:true}));
              ['keydown','keypress','keyup'].forEach(function(t){
                el.dispatchEvent(new KeyboardEvent(t,{key:'Enter',code:'Enter',keyCode:13,which:13,bubbles:true}));
              });
              return 'ok';
            })(${org.json.JSONObject.quote(q)})
        """.trimIndent()
        web.evaluateJavascript(js) { res ->
            if (res != null && res.contains("ok")) {
                queryFilled = true
                // Beri waktu hasil pencarian muncul, lalu buka halaman detail game otomatis
                main.postDelayed({ if (!isDestroyed) openResult(searchQuery, 0) }, 1500)
            } else {
                main.postDelayed({ if (!isDestroyed) fillSearch(q, attempt + 1) }, 1000)
            }
        }
    }

    private var searchQuery = ""
    private var queryTag = ""
    private var resultOpened = false

    /**
     * Setelah pencarian terisi, cari kartu hasil yang judulnya sama persis dengan game room (utamakan yang
     * mencantumkan konsol yang sama, mis. "SNES") lalu ketuk otomatis, sehingga langsung masuk halaman detail
     * game dan pemain tinggal menekan tombol Download. Dicoba berulang karena hasil dimuat belakangan.
     * Bila tidak ketemu, halaman tetap di hasil pencarian (perilaku lama).
     */
    private fun openResult(q: String, attempt: Int) {
        if (resultOpened || attempt > 15) return
        val js = """
            (function(q,tag){
              function norm(x){return (x||'').toLowerCase().replace(/[^a-z0-9]+/g,'');}
              var nq=norm(q), nt=norm(tag);
              if(!nq) return 'none';
              var all=[].slice.call(document.body.querySelectorAll('*'));
              var best=null, bestScore=-1;
              for (var i=0;i<all.length;i++){
                var el=all[i], tg=el.tagName;
                if(tg==='SCRIPT'||tg==='STYLE'||tg==='INPUT'||tg==='TEXTAREA'||tg==='NOSCRIPT') continue;
                if(el.offsetParent===null && getComputedStyle(el).position!=='fixed') continue;
                if(norm(el.textContent)!==nq) continue;
                // naik ke elemen yang bisa diketuk (kartu / tautan / tombol)
                var c=el, hit=null;
                for (var d=0; d<8 && c && c!==document.body; d++, c=c.parentElement){
                  var cs=getComputedStyle(c);
                  if(c.tagName==='A'||c.tagName==='BUTTON'||c.getAttribute('role')==='button'||c.hasAttribute('onclick')||cs.cursor==='pointer'){ hit=c; break; }
                }
                if(!hit) continue;
                var score=1;
                var area=hit, txt='';
                for (var k=0;k<4 && area;k++, area=area.parentElement){ txt+=' '+norm(area.textContent); }
                if(nt && txt.indexOf(nt)>=0) score+=2;
                if(hit.tagName==='A') score+=1;
                if(score>bestScore){ bestScore=score; best=hit; }
              }
              if(!best) return 'none';
              best.scrollIntoView({block:'center'});
              ['pointerdown','mousedown','pointerup','mouseup','click'].forEach(function(t){
                best.dispatchEvent(new MouseEvent(t,{bubbles:true,cancelable:true,view:window}));
              });
              return 'clicked';
            })(${org.json.JSONObject.quote(q)}, ${org.json.JSONObject.quote(queryTag)})
        """.trimIndent()
        web.evaluateJavascript(js) { res ->
            if (res != null && res.contains("clicked")) {
                resultOpened = true
            } else {
                main.postDelayed({ if (!isDestroyed) openResult(q, attempt + 1) }, 1000)
            }
        }
    }

    private fun toast(msg: String) {
        val app = applicationContext
        main.post { Toast.makeText(app, msg, Toast.LENGTH_LONG).show() }
    }

    /**
     * Ekstensi ROM yang dikenal (.gba .sfc .smc .md .gen .zip ...) masuk ke folder ROM konsolnya,
     * jadi langsung muncul di Library. File lain disimpan di folder "downloads" milik aplikasi.
     */
    private fun targetDir(ctx: android.content.Context, name: String): File {
        val console = Console.fromExtension(name.substringAfterLast('.', "").lowercase())
        if (console != null) return Paths.roms(ctx, console)
        val base = ctx.getExternalFilesDir(null) ?: ctx.filesDir
        return File(base, "downloads").apply { mkdirs() }
    }

    private fun startDownload(url: String, userAgent: String?, disposition: String?, mime: String?) {
        if (!url.startsWith("http://") && !url.startsWith("https://")) {
            toast("Jenis tautan unduhan ini belum didukung")
            return
        }
        val app = applicationContext
        val name = File(URLUtil.guessFileName(url, disposition, mime)).name
        toast("Mengunduh $name…")
        Thread {
            var part: File? = null
            try {
                val dir = targetDir(app, name)
                val dest = File(dir, name)
                part = File(dir, "$name.part")   // .part tidak ditampilkan di Library sampai selesai
                val conn = (URL(url).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 20000; readTimeout = 30000
                    instanceFollowRedirects = true
                    userAgent?.let { setRequestProperty("User-Agent", it) }
                    CookieManager.getInstance().getCookie(url)?.let { setRequestProperty("Cookie", it) }
                    setRequestProperty("Referer", DEFAULT_URL)
                }
                if (conn.responseCode !in 200..299) throw java.io.IOException("HTTP ${conn.responseCode}")
                conn.inputStream.use { input -> part.outputStream().use { out -> input.copyTo(out) } }
                if (dest.exists()) dest.delete()
                if (!part.renameTo(dest)) throw java.io.IOException("gagal menyimpan")
                if (dir.path.contains("/roms/")) {
                    // Arsip (zip/7z/rar) dibaca isinya: ROM konsol dipindah ke konsol yang sesuai
                    val ex = if (com.allinone.emulator.data.RomLibrary.isArchive(name)) com.allinone.emulator.data.RomLibrary.normalizeArchive(app, dest) else emptyList()
                    val c = (ex.firstOrNull() ?: dest).let { com.allinone.emulator.data.RomLibrary.consoleOf(it) }
                    toast("Tersimpan di Library: ${ex.firstOrNull()?.name ?: name}" + (c?.let { " [${it.label}]" } ?: ""))
                } else toast("Tersimpan: $name (folder downloads)")
            } catch (e: Exception) {
                part?.delete()
                toast("Unduhan gagal: ${e.message ?: "kesalahan jaringan"}")
            }
        }.start()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    /** Bayangan tipis supaya teks putih tetap terbaca di atas latar hijau yang terang. */
    private fun android.widget.TextView.shade() = setShadowLayer(dp(3).toFloat(), 0f, dp(1).toFloat(), 0xE6062A12.toInt())

    /** Kotak kaca (sama seperti layar ZeroTier dan Library): tint biru tipis, kilap putih dari atas, tepi putih halus. */
    private fun glass(radiusDp: Int = 0): android.graphics.drawable.Drawable {
        val r = dp(radiusDp).toFloat()
        val base = android.graphics.drawable.GradientDrawable().apply {
            setColor(0x2E102848); cornerRadius = r; setStroke(dp(1), 0x8CFFFFFF.toInt())
        }
        val gloss = android.graphics.drawable.GradientDrawable(
            android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(0x73FFFFFF, 0x2EFFFFFF, 0x0DFFFFFF)
        ).apply { cornerRadius = r }
        return android.graphics.drawable.LayerDrawable(arrayOf(base, gloss))
    }

    /** Tombol kaca biru muda ala Frutiger Aero. */
    private fun Button.aeroButton() {
        val r = dp(5).toFloat()
        val base = android.graphics.drawable.GradientDrawable(
            android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0x6B8AD0F8, 0x6648AAEB)
        ).apply { cornerRadius = r; setStroke(dp(1), 0xBFFFFFFF.toInt()) }
        val gloss = android.graphics.drawable.GradientDrawable(
            android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0xA6FFFFFF.toInt(), 0x40FFFFFF, 0x0DFFFFFF)
        ).apply { cornerRadius = r }
        background = android.graphics.drawable.RippleDrawable(
            android.content.res.ColorStateList.valueOf(0x66FFFFFF), android.graphics.drawable.LayerDrawable(arrayOf(base, gloss)), null
        )
        stateListAnimator = null
        setTextColor(android.graphics.Color.WHITE)
        setShadowLayer(dp(3).toFloat(), 0f, dp(1).toFloat(), 0xE606203A.toInt())
    }

    companion object {
        const val EXTRA_URL = "url"
        const val EXTRA_QUERY = "query"                  // nama game yang dicari otomatis di situs ROM
        const val EXTRA_QUERY_CONSOLE = "query_console"  // nama emulator/konsol (hanya tampilan)
        const val EXTRA_QUERY_TAG = "query_tag"          // label konsol di situs (mis. SNES), dipakai memilih hasil yang tepat
        const val DEFAULT_URL = "https://videogame.actduck.com/"
    }
}
