package com.allinone.emulator.ui

import android.app.Activity
import android.graphics.Color
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.animation.ObjectAnimator
import android.graphics.Outline
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import com.allinone.emulator.data.LobbyApi
import com.allinone.emulator.net.ZtDiscovery
import com.allinone.emulator.net.ZtState
import com.swordfish.libretrodroid.GLRetroView
import com.swordfish.libretrodroid.NetplayStatus
import java.io.File
import java.net.Inet4Address
import java.net.InetAddress
import java.net.NetworkInterface
import java.util.zip.CRC32

/**
 * Multiplayer online/LAN dengan rollback (gaya GGPO), 2 pemain.
 * Host = pemain 1, tamu = pemain 2. Kedua HP harus memakai ROM + core yang sama.
 */
class NetplayUi(
    private val act: Activity,
    private val retro: GLRetroView,
    private val rom: File,
    private val coreId: String,
    private val root: FrameLayout
) {
    private val main = Handler(Looper.getMainLooper())
    private var polling = false
    private var lastState = NetplayStatus.State.OFF

    private val overlay = TextView(act).apply {
        setTextColor(Color.WHITE)
        setBackgroundColor(0x99000000.toInt())
        textSize = 11f
        setPadding(14, 6, 14, 6)
        visibility = android.view.View.GONE
    }

    // ---------------------------------------------------------------- stiker antar pemain

    private val dp = act.resources.displayMetrics.density
    private fun px(v: Int) = (v * dp).toInt()
    private val stickerIds: List<Int> by lazy {
        (1..STICKER_COUNT).map { act.resources.getIdentifier("sticker_%02d".format(it), "drawable", act.packageName) }
    }
    private var lastStickerSent = 0L
    private var lastStickerIn = 0
    private var stickerSeen = false
    private var stickerHide: Runnable? = null

    private fun roundOutline(r: Float) = object : ViewOutlineProvider() {
        override fun getOutline(v: View, o: Outline) { o.setRoundRect(0, 0, v.width, v.height, r) }
    }

    /** Tombol kecil di tepi kanan layar; hanya tampil saat game benar-benar berjalan dalam multiplayer. */
    private val stickerButton = TextView(act).apply {
        text = "\uD83D\uDE02"
        textSize = 20f
        gravity = Gravity.CENTER
        setBackgroundColor(0x99000000.toInt())
        outlineProvider = roundOutline(px(20).toFloat()); clipToOutline = true
        alpha = 0.85f
        visibility = View.GONE
        setOnClickListener { stickerPanel.visibility = if (stickerPanel.visibility == View.VISIBLE) View.GONE else View.VISIBLE }
    }

    /** Baris stiker yang bisa digeser; ketuk satu untuk mengirim. */
    private val stickerPanel = HorizontalScrollView(act).apply {
        setBackgroundColor(0xCC000000.toInt())
        isHorizontalScrollBarEnabled = false
        visibility = View.GONE
    }

    /** Stiker dari lawan: muncul di atas layar, membesar sebentar lalu menghilang. */
    private val stickerPopup = ImageView(act).apply {
        scaleType = ImageView.ScaleType.FIT_CENTER
        setBackgroundColor(Color.WHITE)
        outlineProvider = roundOutline(px(16).toFloat()); clipToOutline = true
        elevation = px(6).toFloat()
        visibility = View.GONE
    }

    // ---- favorit: tekan lama stiker untuk memberi bintang (maks 5), favorit tampil paling depan
    private val stickerPrefs by lazy { act.getSharedPreferences("netplay_stickers", android.content.Context.MODE_PRIVATE) }
    private val favorites: MutableList<Int> by lazy {
        (stickerPrefs.getString("fav", "") ?: "").split(",")
            .mapNotNull { it.trim().toIntOrNull() }
            .filter { it in 0 until STICKER_COUNT }
            .distinct().take(MAX_FAV).toMutableList()
    }
    private val stickerRow by lazy {
        LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL; setPadding(px(6), px(6), px(6), px(6)) }
    }

    private fun saveFavorites() {
        try { stickerPrefs.edit().putString("fav", favorites.joinToString(",")).apply() } catch (_: Exception) {}
    }

    private fun toggleFavorite(index: Int) {
        if (favorites.remove(index)) {
            SoundToast.makeText(act, "Dihapus dari favorit", Toast.LENGTH_SHORT).show()
        } else if (favorites.size >= MAX_FAV) {
            SoundToast.makeText(act, "Slot favorit penuh (maks $MAX_FAV). Tekan lama stiker berbintang untuk melepas.", Toast.LENGTH_SHORT).show()
            return
        } else {
            favorites.add(index)
            SoundToast.makeText(act, "\u2B50 Disimpan sebagai favorit (${favorites.size}/$MAX_FAV)", Toast.LENGTH_SHORT).show()
        }
        saveFavorites()
        val keep = stickerPanel.scrollX
        fillStickerRow()
        stickerPanel.post { stickerPanel.scrollTo(keep, 0) }
    }

    /** Isi ulang baris stiker: favorit (berbintang) dulu, lalu sisanya sesuai nomor. */
    private fun fillStickerRow() {
        stickerRow.removeAllViews()
        val order = favorites + (0 until STICKER_COUNT).filter { it !in favorites }
        for (i in order) {
            val res = stickerIds.getOrNull(i)?.takeIf { it != 0 } ?: continue
            val cell = FrameLayout(act)
            cell.addView(ImageView(act).apply {
                setImageResource(res)
                setBackgroundColor(Color.WHITE)
                outlineProvider = roundOutline(px(10).toFloat()); clipToOutline = true
                setOnClickListener { sendSticker(i) }
                setOnLongClickListener {
                    performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS)
                    toggleFavorite(i); true
                }
            }, FrameLayout.LayoutParams(px(64), px(64)))
            if (i in favorites) {
                cell.addView(TextView(act).apply {
                    text = "\u2B50"; textSize = 14f; gravity = Gravity.CENTER
                    setShadowLayer(4f, 0f, 0f, Color.BLACK)
                }, FrameLayout.LayoutParams(px(22), px(22), Gravity.TOP or Gravity.END))
            }
            stickerRow.addView(cell, LinearLayout.LayoutParams(px(64), px(64)).apply { setMargins(px(4), 0, px(4), 0) })
        }
    }

    // ---- kipas favorit: tekan & seret tombol stiker -> favorit tampil setengah lingkaran, lepas di atas salah satunya untuk kirim
    private class FanItem(val index: Int, val view: ImageView, val cx: Float, val cy: Float)

    private val fanLayer = FrameLayout(act).apply {
        setBackgroundColor(0x44000000)
        visibility = View.GONE
        isClickable = false
    }
    private val fanItems = mutableListOf<FanItem>()
    private var fanHot = -1
    private var fanActive = false      // kipas sedang tampil dalam gestur ini
    private var fanRejected = false    // seret terdeteksi tapi belum ada favorit
    private var touchDownX = 0f
    private var touchDownY = 0f
    private val fanLoc = IntArray(2)

    private fun showFan(): Boolean {
        val favs = favorites.toList()
        if (favs.isEmpty()) {
            SoundToast.makeText(act, "Belum ada favorit. Tekan lama stiker di panel untuk memberi bintang \u2B50", Toast.LENGTH_SHORT).show()
            return false
        }
        stickerPanel.visibility = View.GONE
        fanLayer.removeAllViews(); fanItems.clear(); fanHot = -1
        fanLayer.visibility = View.VISIBLE
        val size = px(56)
        val radius = px(110).toFloat()
        val cx = stickerButton.x + stickerButton.width / 2f
        val cy = stickerButton.y + stickerButton.height / 2f
        val n = favs.size
        favs.forEachIndexed { k, idx ->
            val res = stickerIds.getOrNull(idx)?.takeIf { it != 0 } ?: return@forEachIndexed
            // setengah lingkaran terbuka ke sisi yang lapang (kiri bila tombol di kanan layar, sebaliknya); jarak antar stiker 45 derajat
            val phi = Math.toRadians((k - (n - 1) / 2.0) * 45.0)
            val dir = if (cx > root.width / 2f) -1f else 1f
            val half = size / 2f
            val x = (cx + dir * (radius * Math.cos(phi)).toFloat()).coerceIn(half, (root.width - half).coerceAtLeast(half))
            val y = (cy + (radius * Math.sin(phi)).toFloat()).coerceIn(half, (root.height - half).coerceAtLeast(half))
            val iv = ImageView(act).apply {
                setImageResource(res)
                setBackgroundColor(Color.WHITE)
                outlineProvider = roundOutline(px(12).toFloat()); clipToOutline = true
                elevation = px(4).toFloat()
                scaleX = 0.2f; scaleY = 0.2f; alpha = 0f
            }
            fanLayer.addView(iv, FrameLayout.LayoutParams(size, size, Gravity.TOP or Gravity.START).apply {
                leftMargin = (x - size / 2f).toInt(); topMargin = (y - size / 2f).toInt()
            })
            iv.animate().scaleX(1f).scaleY(1f).alpha(1f).setStartDelay((k * 25).toLong()).setDuration(140).start()
            fanItems.add(FanItem(idx, iv, x, y))
        }
        return fanItems.isNotEmpty()
    }

    private fun updateFanHot(rawX: Float, rawY: Float) {
        root.getLocationOnScreen(fanLoc)
        val x = rawX - fanLoc[0]
        val y = rawY - fanLoc[1]
        var best = -1
        var bestD = px(42).toFloat()
        fanItems.forEachIndexed { i, it ->
            val d = Math.hypot((x - it.cx).toDouble(), (y - it.cy).toDouble()).toFloat()
            if (d < bestD) { bestD = d; best = i }
        }
        if (best == fanHot) return
        fanHot = best
        fanItems.forEachIndexed { i, it ->
            val on = i == fanHot
            it.view.animate().scaleX(if (on) 1.3f else 1f).scaleY(if (on) 1.3f else 1f).setStartDelay(0).setDuration(90).start()
            it.view.elevation = px(if (on) 10 else 4).toFloat()
        }
        if (best >= 0) stickerButton.performHapticFeedback(android.view.HapticFeedbackConstants.CLOCK_TICK)
    }

    private fun hideFan() {
        fanLayer.visibility = View.GONE
        fanLayer.removeAllViews()
        fanItems.clear()
        fanHot = -1
        fanActive = false
    }

    // ---- pindah tombol: tekan lama tombol stiker lalu geser ke mana pun; posisi disimpan (pecahan layar)
    private var moveMode = false
    private var buttonPlaced = false
    private var btnStartX = 0f
    private var btnStartY = 0f
    private val longPressRun = Runnable {
        moveMode = true
        stickerButton.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS)
        stickerButton.animate().scaleX(1.2f).scaleY(1.2f).alpha(1f).setDuration(100).start()
        stickerPanel.visibility = View.GONE
    }

    private fun clampButton(x: Float, y: Float) {
        val maxX = (root.width - stickerButton.width).coerceAtLeast(0).toFloat()
        val maxY = (root.height - stickerButton.height).coerceAtLeast(0).toFloat()
        stickerButton.x = x.coerceIn(0f, maxX)
        stickerButton.y = y.coerceIn(0f, maxY)
    }

    private fun saveButtonPos() {
        if (root.width <= 0 || root.height <= 0) return
        try {
            stickerPrefs.edit()
                .putFloat("btn_fx", stickerButton.x / root.width)
                .putFloat("btn_fy", stickerButton.y / root.height)
                .apply()
        } catch (_: Exception) {}
    }

    /** Pasang posisi tersimpan (atau posisi bawaan: tepi kanan, tengah vertikal). */
    private fun restoreButtonPos() {
        if (root.width <= 0 || root.height <= 0 || stickerButton.width <= 0) return
        val has = stickerPrefs.contains("btn_fx") && stickerPrefs.contains("btn_fy")
        val x = if (has) stickerPrefs.getFloat("btn_fx", 0f) * root.width
                else (root.width - stickerButton.width - px(6)).toFloat()
        val y = if (has) stickerPrefs.getFloat("btn_fy", 0f) * root.height
                else (root.height - stickerButton.height) / 2f
        clampButton(x, y)
    }

    private fun installFanGesture() {
        val slop = android.view.ViewConfiguration.get(act).scaledTouchSlop * 1.5f
        val lpTimeout = android.view.ViewConfiguration.getLongPressTimeout().toLong()
        stickerButton.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                android.view.MotionEvent.ACTION_DOWN -> {
                    touchDownX = e.rawX; touchDownY = e.rawY
                    btnStartX = v.x; btnStartY = v.y
                    fanActive = false; fanRejected = false; moveMode = false
                    v.parent?.requestDisallowInterceptTouchEvent(true)
                    main.postDelayed(longPressRun, lpTimeout)
                }
                android.view.MotionEvent.ACTION_MOVE -> {
                    if (moveMode) {
                        clampButton(btnStartX + (e.rawX - touchDownX), btnStartY + (e.rawY - touchDownY))
                    } else {
                        if (!fanActive && !fanRejected &&
                            Math.hypot((e.rawX - touchDownX).toDouble(), (e.rawY - touchDownY).toDouble()) > slop) {
                            main.removeCallbacks(longPressRun)
                            if (showFan()) fanActive = true else fanRejected = true
                        }
                        if (fanActive) updateFanHot(e.rawX, e.rawY)
                    }
                }
                android.view.MotionEvent.ACTION_UP -> {
                    main.removeCallbacks(longPressRun)
                    if (moveMode) {
                        moveMode = false
                        saveButtonPos()
                        v.animate().scaleX(1f).scaleY(1f).alpha(0.85f).setDuration(100).start()
                    } else if (fanActive) {
                        val pick = fanItems.getOrNull(fanHot)?.index
                        hideFan()
                        if (pick != null) sendSticker(pick)   // tampil di layar sendiri + terkirim ke lawan
                    } else if (!fanRejected) {
                        v.performClick()                      // ketukan biasa: buka/tutup panel
                    }
                    fanRejected = false
                }
                android.view.MotionEvent.ACTION_CANCEL -> {
                    main.removeCallbacks(longPressRun)
                    if (moveMode) {
                        moveMode = false
                        saveButtonPos()
                        v.animate().scaleX(1f).scaleY(1f).alpha(0.85f).setDuration(100).start()
                    }
                    hideFan(); fanRejected = false
                }
            }
            true
        }
    }

    private fun buildStickerViews() {
        if (stickerButton.parent != null) return
        fillStickerRow()
        stickerPanel.addView(stickerRow)
        root.addView(stickerPanel, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        root.addView(fanLayer, FrameLayout.LayoutParams(-1, -1))   // di bawah tombol supaya tombol tetap menerima gestur
        installFanGesture()
        root.addView(stickerButton, FrameLayout.LayoutParams(px(40), px(40), Gravity.TOP or Gravity.START))
        // pasang posisi tersimpan begitu tombol selesai diukur (pertama kali tampil)
        stickerButton.addOnLayoutChangeListener { _, l, t, r, b, _, _, _, _ ->
            if (!buttonPlaced && r - l > 0 && b - t > 0) { buttonPlaced = true; restoreButtonPos() }
        }
        root.addOnLayoutChangeListener { _, l, t, r, b, ol, ot, orr, ob ->
            // layar berubah (rotasi/ukuran): pasang ulang posisi supaya tombol tidak keluar layar
            if (!moveMode && (r - l != orr - ol || b - t != ob - ot)) restoreButtonPos()
        }
        root.addView(stickerPopup, FrameLayout.LayoutParams(px(120), px(120), Gravity.TOP or Gravity.START).apply { leftMargin = px(16); topMargin = px(36) })
    }

    private fun sendSticker(index: Int) {
        val now = System.currentTimeMillis()
        if (now - lastStickerSent < 1000) return   // jeda 1 detik agar tidak spam
        lastStickerSent = now
        try { retro.netplaySendSticker(index) } catch (_: Exception) {}
        stickerPanel.visibility = View.GONE
        showSticker(index)                         // tampilkan juga di layar sendiri sebagai konfirmasi
    }

    private fun showSticker(index: Int) {
        val res = stickerIds.getOrNull(index)?.takeIf { it != 0 } ?: return
        stickerPopup.setImageResource(res)
        stickerPopup.visibility = View.VISIBLE
        stickerPopup.bringToFront()
        stickerPopup.alpha = 1f
        ObjectAnimator.ofFloat(stickerPopup, View.SCALE_X, 0.3f, 1f).setDuration(180).start()
        ObjectAnimator.ofFloat(stickerPopup, View.SCALE_Y, 0.3f, 1f).setDuration(180).start()
        stickerHide?.let { main.removeCallbacks(it) }
        stickerHide = Runnable {
            stickerPopup.animate().alpha(0f).setDuration(300).withEndAction { stickerPopup.visibility = View.GONE }.start()
        }.also { main.postDelayed(it, 2500) }
    }

    private fun updateStickers(st: NetplayStatus) {
        val running = st.state == NetplayStatus.State.RUNNING
        if (running) buildStickerViews()
        if (stickerButton.parent == null) return
        stickerButton.visibility = if (running) View.VISIBLE else View.GONE
        if (!running) { stickerPanel.visibility = View.GONE; hideFan(); stickerSeen = false; return }
        // Stiker pertama dari lawan hanya dipakai sebagai acuan (abaikan sisa stiker sesi lama)
        if (!stickerSeen) { lastStickerIn = st.stickerInbox; stickerSeen = true; return }
        if (st.stickerInbox != lastStickerIn) {
            lastStickerIn = st.stickerInbox
            val id = (st.stickerInbox and 0xFF) - 1
            if (id >= 0) showSticker(id)
        }
    }

    /** True selama game dikendalikan sesi netplay: simpan/muat state, reset, cheat, fast forward dimatikan. */
    val active: Boolean
        get() = lastState == NetplayStatus.State.SYNCING || lastState == NetplayStatus.State.RUNNING

    /** True bila ada sesi (menunggu / menyambung / jalan). */
    val inSession: Boolean get() = lastState != NetplayStatus.State.OFF && lastState != NetplayStatus.State.ENDED

    fun showMenu(show: (AlertDialog.Builder) -> Unit) {
        val items = if (inSession || lastState == NetplayStatus.State.ENDED)
            arrayOf("Hentikan multiplayer")
        else arrayOf("Host (jadi pemain 1)", "Gabung (jadi pemain 2)")
        show(AlertDialog.Builder(act).setTitle("Multiplayer rollback").setItems(items) { _, i ->
            if (inSession || lastState == NetplayStatus.State.ENDED) stop()
            else if (i == 0) hostDialog(show) else joinDialog(show)
        })
    }

    // ---------------------------------------------------------------- multiplayer online (lobby)

    private var lobbyUrl = ""
    private var lobbyToken: String? = null
    private var lastBeat = 0L

    /** Dipanggil otomatis dari menu Multiplayer Online: jadi host, lalu tampilkan server di daftar lobby. */
    fun autoHost(
        delay: Int, lobbyUrl: String, room: String, publicIp: String,
        title: String, consoleName: String, owner: String, vpn: String = "", invite: String = ""
    ) {
        gameHash { hash ->
            val ok = host(hash, delay)
            afterStart(ok)
            if (!ok) return@gameHash
            // Umumkan lewat siaran jaringan ZeroTier (tanpa lobby): pemain lain di jaringan yang sama melihatnya otomatis
            ZtDiscovery.announce(room, title, consoleName, owner, PORT, 2, invite)
            if (ZtState.firstIp() != null) {
                SoundToast.makeText(act, "Server \"$room\" diumumkan otomatis di jaringan ZeroTier", Toast.LENGTH_LONG).show()
            }
            if (lobbyUrl.isBlank()) return@gameHash
            this.lobbyUrl = lobbyUrl
            val nr = LobbyApi.NewRoom(room, title, consoleName, PORT, delay, owner, publicIp, vpn)
            Thread {
                try {
                    val token = LobbyApi.register(lobbyUrl, nr)
                    lobbyToken = token
                    lastBeat = System.currentTimeMillis()
                    main.post { SoundToast.makeText(act, "Server \"$room\" tampil di daftar LOBBY", Toast.LENGTH_LONG).show() }
                } catch (e: LobbyApi.Rejected) {
                    main.post { SoundToast.makeText(act, "Tidak masuk daftar: ${e.message}\nPemain lain masih bisa gabung lewat IP.", Toast.LENGTH_LONG).show() }
                } catch (e: Exception) {
                    main.post { SoundToast.makeText(act, "Lobby tidak terjangkau: ${e.message ?: e.javaClass.simpleName}", Toast.LENGTH_LONG).show() }
                }
            }.start()
        }
    }

    /** Dipanggil otomatis dari menu Multiplayer Online: gabung ke server yang dipilih (alamat boleh berupa nama domain). */
    fun autoJoin(host: String, port: Int) {
        SoundToast.makeText(act, "Menyambung ke $host…", Toast.LENGTH_SHORT).show()
        Thread {
            // Native hanya menerima IPv4 angka, jadi nama domain di-resolve dulu di sini
            val ip = try {
                InetAddress.getAllByName(host).firstOrNull { it is Inet4Address }?.hostAddress
            } catch (_: Exception) { null }
            main.post {
                if (ip == null) {
                    SoundToast.makeText(act, "Alamat server tidak ditemukan: $host", Toast.LENGTH_LONG).show()
                } else {
                    gameHash { hash -> afterStart(join(ip, port, hash)) }
                }
            }
        }.start()
    }

    private fun lobbyBeat(st: NetplayStatus) {
        val token = lobbyToken ?: return
        val now = System.currentTimeMillis()
        if (now - lastBeat < 15_000) return
        lastBeat = now
        val players = if (st.state == NetplayStatus.State.SYNCING || st.state == NetplayStatus.State.RUNNING) 2 else 1
        val url = lobbyUrl
        Thread { try { LobbyApi.heartbeat(url, token, players) } catch (_: Exception) {} }.start()
    }

    private fun lobbyClose() {
        val token = lobbyToken ?: return
        lobbyToken = null
        val url = lobbyUrl
        Thread { try { LobbyApi.close(url, token) } catch (_: Exception) {} }.start()
    }

    private fun hostDialog(show: (AlertDialog.Builder) -> Unit) {
        val ips = localIps()
        val delays = listOf(1, 2, 3, 4, 5, 6, 7, 8)
        val labels = delays.map { d ->
            when (d) {
                1 -> "1 frame (paling responsif, koneksi harus bagus)"
                2 -> "2 frame (bawaan, cocok untuk Wi-Fi/LAN)"
                3 -> "3 frame (internet cukup stabil)"
                4 -> "4 frame (koneksi kurang stabil)"
                5 -> "5 frame (ZeroTier/VPN, disarankan)"
                6 -> "6 frame (ZeroTier lewat relay / ping tinggi)"
                7 -> "7 frame (ping sekitar 200 ms)"
                else -> "8 frame (ping 250 ms ke atas, paling mulus)"
            }
        }
        show(AlertDialog.Builder(act)
            // JANGAN pakai setMessage bersama setItems: Android menyembunyikan daftar pilihannya.
            .setTitle("Host: IP ${if (ips.isEmpty()) "(tidak terdeteksi)" else ips.joinToString(", ")} port $PORT\nPilih input delay (dipakai kedua pemain):")
            .setItems(labels.toTypedArray()) { _, i ->
                gameHash { hash ->
                    val ok = host(hash, delays[i])
                    afterStart(ok)
                }
            }
            .setNegativeButton("Batal", null))
    }

    private fun joinDialog(show: (AlertDialog.Builder) -> Unit) {
        val et = EditText(act).apply {
            hint = "IP host, mis. 192.168.1.5"
            setSingleLine(true)
            setText(lastIp)
        }
        val box = FrameLayout(act).apply {
            val m = (20 * act.resources.displayMetrics.density).toInt()
            setPadding(m, m / 2, m, 0)
            addView(et)
        }
        show(AlertDialog.Builder(act)
            .setTitle("Gabung ke host")
            .setMessage("Masukkan IP host (port $PORT dipakai otomatis; bisa juga ditulis ip:port).")
            .setView(box)
            .setPositiveButton("Gabung") { _, _ ->
                val txt = et.text.toString().trim()
                if (txt.isEmpty()) return@setPositiveButton
                lastIp = txt
                val ip = txt.substringBefore(':')
                val port = txt.substringAfter(':', "").toIntOrNull() ?: PORT
                gameHash { hash -> afterStart(join(ip, port, hash)) }
            }
            .setNegativeButton("Batal", null))
    }

    private fun host(hash: Int, delay: Int): Boolean = retro.netplayHost(PORT, hash, delay)

    private fun join(ip: String, port: Int, hash: Int): Boolean = retro.netplayJoin(ip, port, hash, 2)

    /** Sidik jari game: CRC32 ROM digabung nama core. Harus sama di kedua HP. */
    private fun gameHash(onReady: (Int) -> Unit) {
        SoundToast.makeText(act, "Menyiapkan multiplayer…", Toast.LENGTH_SHORT).show()
        Thread {
            val crc = CRC32()
            try {
                rom.inputStream().use { s ->
                    val buf = ByteArray(64 * 1024)
                    while (true) { val n = s.read(buf); if (n <= 0) break; crc.update(buf, 0, n) }
                }
            } catch (_: Exception) {}
            val coreName = File(coreId).name.substringAfterLast('/')
            val h = (crc.value.toInt()) xor coreName.hashCode()
            main.post { onReady(h) }
        }.start()
    }

    private fun afterStart(ok: Boolean) {
        if (!ok) {
            val e = retro.netplayStatus().error
            SoundToast.makeText(act, errorText(e), Toast.LENGTH_LONG).show()
            retro.netplayStop()
            return
        }
        if (overlay.parent == null) {
            root.addView(overlay, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL))
        }
        startPolling()
    }

    fun stop() {
        polling = false
        ZtDiscovery.stopAnnounce()
        lobbyClose()
        try { retro.netplayStop() } catch (_: Exception) {}
        lastState = NetplayStatus.State.OFF
        overlay.visibility = android.view.View.GONE
        stickerButton.visibility = View.GONE
        stickerPanel.visibility = View.GONE
        stickerPopup.visibility = View.GONE
        stickerSeen = false
        main.removeCallbacks(longPressRun); moveMode = false
    }

    private fun startPolling() {
        if (polling) return
        polling = true
        main.post(object : Runnable {
            override fun run() {
                if (!polling) return
                val st = try { retro.netplayStatus() } catch (_: Exception) { null }
                if (st != null) render(st)
                if (polling) main.postDelayed(this, 250)
            }
        })
    }

    private fun render(st: NetplayStatus) {
        val prev = lastState
        lastState = st.state
        lobbyBeat(st)
        ZtDiscovery.setPlayers(if (st.state == NetplayStatus.State.SYNCING || st.state == NetplayStatus.State.RUNNING) 2 else 1)
        updateStickers(st)
        overlay.visibility = android.view.View.VISIBLE
        overlay.text = when (st.state) {
            NetplayStatus.State.HOST_WAITING ->
                "Menunggu pemain 2… IP: ${localIps().joinToString(", ")}:$PORT" +
                    if (ZtDiscovery.sentCount() > 0) " · siaran ZeroTier terkirim ${ZtDiscovery.sentCount()}×" else ""
            NetplayStatus.State.CLIENT_CONNECTING -> "Menyambung ke host…"
            NetplayStatus.State.SYNCING -> "Sinkronisasi game…"
            NetplayStatus.State.RUNNING ->
                "P${st.localPlayer + 1} · ping ${st.pingMs} ms · rollback ${st.lastRollbackFrames}f" +
                    if (st.desync) " · DESYNC" + (if (st.desyncReason == 1) "(state lama)" else if (st.desyncReason == 2) "(hash)" else "") + "!" else ""
            else -> ""
        }
        if (st.state == NetplayStatus.State.ENDED && prev != NetplayStatus.State.ENDED) {
            SoundToast.makeText(act, errorText(st.error) + "\nGame dilanjutkan sendiri.", Toast.LENGTH_LONG).show()
            stop()
        }
    }

    private fun errorText(e: NetplayStatus.Error) = when (e) {
        NetplayStatus.Error.GAME_MISMATCH -> "Game/core berbeda: kedua HP harus memakai ROM dan core yang sama."
        NetplayStatus.Error.CONNECT -> "Tidak bisa tersambung ke host (cek IP, port $PORT, dan jaringan)."
        NetplayStatus.Error.TIMEOUT -> "Koneksi terputus (tidak ada balasan)."
        NetplayStatus.Error.VERSION -> "Versi multiplayer berbeda."
        NetplayStatus.Error.STATE_TOO_BIG -> "Core ini tidak cocok untuk rollback (state terlalu besar)."
        NetplayStatus.Error.SOCKET -> "Port $PORT tidak bisa dibuka (sedang dipakai?)."
        NetplayStatus.Error.PEER_LEFT -> "Lawan keluar dari multiplayer."
        NetplayStatus.Error.NONE -> "Multiplayer berhenti."
    }

    private fun localIps(): List<String> = try {
        NetworkInterface.getNetworkInterfaces().toList().flatMap { it.inetAddresses.toList() }
            .filter { it is Inet4Address && !it.isLoopbackAddress }.map { it.hostAddress ?: "" }
            .filter { it.isNotEmpty() }
    } catch (_: Exception) { emptyList() }

    companion object {
        const val PORT = 7755
        const val STICKER_COUNT = 48
        const val MAX_FAV = 5
        private var lastIp = ""
    }
}
