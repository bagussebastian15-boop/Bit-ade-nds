package com.allinone.emulator.ui

import android.app.Activity
import android.media.AudioAttributes
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import android.graphics.Color
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.animation.ObjectAnimator
import android.graphics.Outline
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.Button
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import com.allinone.emulator.data.LobbyApi
import com.allinone.emulator.net.NetplayChat
import com.allinone.emulator.net.ZtDiscovery
import com.allinone.emulator.net.ZtState
import com.swordfish.libretrodroid.GLRetroView
import com.swordfish.libretrodroid.NetplayStatus
import java.io.File
import java.net.Inet4Address
import java.net.InetAddress
import java.net.NetworkInterface
import java.util.Locale
import java.util.zip.CRC32

/**
 * Multiplayer online/LAN dengan rollback (gaya GGPO), 2 pemain.
 * Host = pemain 1, tamu = pemain 2. Kedua HP harus memakai ROM + core yang sama.
 */
class NetplayUi(
    private val act: Activity,
    private val retro: GLRetroView,
    private val rom: File,
    private val coreId: String,
    private val root: FrameLayout
) {
    private val main = Handler(Looper.getMainLooper())
    private var polling = false
    @Volatile private var lastState = NetplayStatus.State.OFF

    private val overlay = TextView(act).apply {
        setTextColor(Color.WHITE)
        setBackgroundColor(0x99000000.toInt())
        textSize = 11f
        setPadding(14, 6, 14, 6)
        visibility = android.view.View.GONE
    }

    // ---------------------------------------------------------------- stiker antar pemain

    private val dp = act.resources.displayMetrics.density
    private fun px(v: Int) = (v * dp).toInt()
    private val stickerIds: List<Int> by lazy {
        (1..STICKER_COUNT).map { act.resources.getIdentifier("sticker_%02d".format(it), "drawable", act.packageName) }
    }
    private var lastStickerSent = 0L
    private var lastStickerIn = 0
    private var stickerSeen = false
    private var stickerHide: Runnable? = null
    private var localPlayerIdx = 0   // 0 = P1 (host), 1 = P2 (tamu); diperbarui dari status netplay

    private fun roundOutline(r: Float) = object : ViewOutlineProvider() {
        override fun getOutline(v: View, o: Outline) { o.setRoundRect(0, 0, v.width, v.height, r) }
    }

    /** Tombol kecil di tepi kanan layar; hanya tampil saat game benar-benar berjalan dalam multiplayer. */
    private val stickerButton = TextView(act).apply {
        text = "\uD83D\uDE02"
        textSize = 20f
        gravity = Gravity.CENTER
        setBackgroundColor(0x99000000.toInt())
        outlineProvider = roundOutline(px(20).toFloat()); clipToOutline = true
        alpha = 0.85f
        visibility = View.GONE
        setOnClickListener { stickerPanel.visibility = if (stickerPanel.visibility == View.VISIBLE) View.GONE else View.VISIBLE }
    }

    /** Baris stiker yang bisa digeser; ketuk satu untuk mengirim. */
    private val stickerPanel = HorizontalScrollView(act).apply {
        setBackgroundColor(0xCC000000.toInt())
        isHorizontalScrollBarEnabled = false
        visibility = View.GONE
    }

    /** Stiker dari lawan: muncul di atas layar, membesar sebentar lalu menghilang. */
    private val stickerPopup = ImageView(act).apply {
        scaleType = ImageView.ScaleType.FIT_CENTER
        setBackgroundColor(Color.WHITE)
        outlineProvider = roundOutline(px(16).toFloat()); clipToOutline = true
        elevation = px(6).toFloat()
        visibility = View.GONE
    }

    // ---------------------------------------------------------------- chat teks antar pemain

    private var chatRunningUi = false      // UI chat sudah dibuat
    private var chatOpen = false
    private val chatLines = ArrayDeque<Pair<String, Long>>()   // (teks, waktu masuk)
    private var chatConnected = false

    private val chat = NetplayChat(
        allowAccept = { lastState == NetplayStatus.State.SYNCING || lastState == NetplayStatus.State.RUNNING },
        onMessage = { msg -> onChatIn(msg) },
        onConnected = { ok -> chatConnected = ok; updateChatHint() }
    )

    /** Tombol chat, tepat di bawah tombol stiker (ikut bergeser bersamanya). */
    private val chatButton = TextView(act).apply {
        text = "\uD83D\uDCAC"
        textSize = 20f
        gravity = Gravity.CENTER
        setBackgroundColor(0x99000000.toInt())
        outlineProvider = roundOutline(px(20).toFloat()); clipToOutline = true
        alpha = 0.85f
        visibility = View.GONE
        setOnClickListener { setChatOpen(!chatOpen) }
    }

    private val chatLog = TextView(act).apply {
        setTextColor(Color.WHITE)
        setBackgroundColor(0x99000000.toInt())
        setShadowLayer(3f, 0f, 0f, Color.BLACK)
        textSize = 13f
        setPadding(px(8), px(4), px(8), px(4))
        maxLines = 6
        visibility = View.GONE
    }

    private val chatInput = EditText(act).apply {
        hint = "Ketik pesan…"
        setHintTextColor(0x99FFFFFF.toInt())
        setTextColor(Color.WHITE)
        textSize = 14f
        setSingleLine(true)
        imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_SEND or android.view.inputmethod.EditorInfo.IME_FLAG_NO_EXTRACT_UI
        filters = arrayOf(android.text.InputFilter.LengthFilter(NetplayChat.MAX_LEN))
        setOnEditorActionListener { _, action, _ ->
            if (action == android.view.inputmethod.EditorInfo.IME_ACTION_SEND) { sendChat(); true } else false
        }
    }

    // ---- narator: pesan masuk dibacakan (Text-to-Speech) dan tidak ditampilkan di layar
    private val chatPrefs by lazy { act.getSharedPreferences("netplay_chat", android.content.Context.MODE_PRIVATE) }
    private var narratorOn = true
    private var narratorLoaded = false
    private var tts: TextToSpeech? = null
    @Volatile private var ttsReady = false
    private var ttsPending = 0
    private var ttsWarned = false
    private var ttsFailed = false                                  // mesin suara gagal dimuat / tidak ada suara
    private val ttsQueue = ArrayDeque<Pair<Int, String>>()         // pesan yang masuk sebelum mesin suara siap
    private var voiceP1: Voice? = null     // suara Pemain 1
    private var voiceP2: Voice? = null     // suara Pemain 2 (beda dari P1 bila HP punya >= 2 suara)
    private var pitchP2 = 1.0f             // bila hanya ada satu suara, P2 dibedakan lewat nada (lebih berat)

    private fun loadNarrator() {
        if (narratorLoaded) return
        narratorLoaded = true
        narratorOn = try { chatPrefs.getBoolean("narrator", true) } catch (_: Exception) { true }
    }

    /** Narator dipakai hanya bila dinyalakan DAN mesin suara siap; kalau tidak, pesan tampil di layar seperti biasa. */
    private fun narratorUsable() = narratorOn && ttsReady

    private val narratorBtn = TextView(act).apply {
        textSize = 18f
        gravity = Gravity.CENTER
        setPadding(px(4), 0, px(10), 0)
        contentDescription = "Narator chat"
        setOnClickListener { toggleNarrator() }
    }

    private fun updateNarratorIcon() {
        narratorBtn.text = if (narratorOn) "\uD83D\uDD0A" else "\uD83D\uDD07"
    }

    private fun toggleNarrator() {
        narratorOn = !narratorOn
        try { chatPrefs.edit().putBoolean("narrator", narratorOn).apply() } catch (_: Exception) {}
        updateNarratorIcon()
        if (narratorOn) {
            ttsFailed = false; ttsWarned = false
            ensureTts()
            chatLines.clear(); renderChatLog()
            demoVoices()
            SoundToast.makeText(act, "Narator hidup: chat dibacakan, tidak tampil di layar", Toast.LENGTH_SHORT).show()
        } else {
            tts?.stop(); ttsPending = 0
            SoundToast.makeText(act, "Narator mati: chat tampil di layar", Toast.LENGTH_SHORT).show()
        }
    }

    private fun ensureTts() {
        if (tts != null) return
        tts = TextToSpeech(act) { status ->
            val t = tts
            if (status != TextToSpeech.SUCCESS || t == null) { ttsFail(); return@TextToSpeech }
            var r = t.setLanguage(Locale.forLanguageTag("id-ID"))
            if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) r = t.setLanguage(Locale.getDefault())
            if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) { ttsFail(); return@TextToSpeech }
            pickVoices(t)
            t.setAudioAttributes(AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_GAME).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(id: String?) {}
                override fun onDone(id: String?) { main.post { if (ttsPending > 0) ttsPending-- } }
                @Deprecated("Deprecated in Java")
                override fun onError(id: String?) { main.post { if (ttsPending > 0) ttsPending-- } }
            })
            ttsReady = true
            while (ttsQueue.isNotEmpty()) ttsQueue.removeFirst().let { speakChat(it.first, it.second) }
        }
    }

    private fun ttsFail() {
        ttsReady = false; ttsFailed = true
        ttsQueue.clear()
        try { tts?.shutdown() } catch (_: Exception) {}
        tts = null
        warnNoTts()
    }

    /**
     * Pemain 1 = suara bawaan sistem (suara yang dipilih mesin TTS HP untuk bahasa ini, dibaca tepat setelah setLanguage).
     * Pemain 2 = suara lain yang terpasang untuk bahasa yang sama; bila HP hanya punya satu suara, suara bawaan yang sama
     * dengan nada lebih berat supaya tetap terdengar beda.
     */
    private fun pickVoices(t: TextToSpeech) {
        voiceP1 = null; voiceP2 = null; pitchP2 = 1.0f
        try {
            val def = t.voice                                   // suara bawaan sistem untuk bahasa yang sedang dipakai
            val lang = def?.locale?.language ?: t.language?.language
            val others = (t.voices ?: emptySet<Voice>()).filter { v ->
                v.locale.language == lang && v.name != def?.name &&
                    !v.isNetworkConnectionRequired && !v.features.contains("notInstalled")
            }.sortedBy { it.name }
            voiceP1 = def
            voiceP2 = others.firstOrNull()
        } catch (_: Exception) {}
        if (voiceP2 == null) { voiceP2 = voiceP1; pitchP2 = 0.75f }
    }

    /** Terapkan suara + nada untuk pemain tertentu tepat sebelum bicara (parameter disalin ke tiap antrean saat speak). */
    private fun applyVoice(t: TextToSpeech, player: Int) {
        try {
            (if (player == 1) voiceP2 else voiceP1)?.let { t.setVoice(it) }
            t.setPitch(if (player == 1) pitchP2 else 1.0f)
        } catch (_: Exception) {}
    }

    /** Contoh suara kedua pemain, diputar saat narator dinyalakan supaya perbedaannya terdengar. */
    private fun demoVoices() {
        val t = tts ?: return
        if (!ttsReady) return
        applyVoice(t, 0); t.speak("Halo, ini suara pertama", TextToSpeech.QUEUE_FLUSH, null, "demo1")
        applyVoice(t, 1); t.speak("Halo, ini suara kedua", TextToSpeech.QUEUE_ADD, null, "demo2")
    }

    private fun warnNoTts() {
        if (ttsWarned) return
        ttsWarned = true
        main.post { SoundToast.makeText(act, "Suara narator tidak tersedia di HP ini. Matikan narator (ikon speaker di kolom chat) untuk membaca chat di layar.", Toast.LENGTH_LONG).show() }
    }

    private fun releaseTts() {
        try { tts?.stop(); tts?.shutdown() } catch (_: Exception) {}
        tts = null; ttsReady = false; ttsPending = 0; ttsQueue.clear()
    }

    private fun speakChat(fromPlayer: Int, msg: String) {
        val t = tts ?: return
        // Tautan panjang tidak enak dibacakan huruf demi huruf
        val spoken = msg.replace(Regex("https?://\\S+"), "tautan")
        // Antrean menumpuk (lawan mengirim cepat): buang yang lama supaya tidak tertinggal jauh dari permainan
        val mode = if (ttsPending >= 3) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD
        if (mode == TextToSpeech.QUEUE_FLUSH) ttsPending = 0
        ttsPending++
        applyVoice(t, fromPlayer)
        t.speak(spoken, mode, null, "chat${System.nanoTime()}")
    }

    private fun onChatIn(msg: String) {
        val from = 1 - localPlayerIdx
        when {
            !narratorOn -> addChatLine("P${from + 1}: $msg")      // narator mati: tampil di layar
            ttsReady -> speakChat(from, msg)
            ttsFailed -> chatInput.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS)   // tak ada suara: hanya getar, teks tetap tidak tampil
            else -> { ttsQueue.addLast(from to msg); while (ttsQueue.size > 3) ttsQueue.removeFirst() }   // mesin suara masih disiapkan
        }
    }

    private val chatInputRow = LinearLayout(act).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setBackgroundColor(0xCC000000.toInt())
        setPadding(px(6), px(2), px(6), px(2))
        visibility = View.GONE
        addView(narratorBtn, LinearLayout.LayoutParams(-2, -2))
        addView(chatInput, LinearLayout.LayoutParams(0, -2, 1f))
        addView(Button(act).apply {
            text = "Kirim"; isAllCaps = false; textSize = 12f
            minWidth = 0; minimumWidth = 0
            setOnClickListener { sendChat() }
        }, LinearLayout.LayoutParams(-2, -2))
    }

    private val chatBox = LinearLayout(act).apply {
        orientation = LinearLayout.VERTICAL
        addView(chatLog, LinearLayout.LayoutParams(-1, -2))
        addView(chatInputRow, LinearLayout.LayoutParams(-1, -2))
    }

    private val chatFade = object : Runnable {
        override fun run() {
            val now = System.currentTimeMillis()
            while (chatLines.isNotEmpty() && now - chatLines.first().second > CHAT_SHOW_MS) chatLines.removeFirst()
            renderChatLog()
            if (chatLines.isNotEmpty()) main.postDelayed(this, 1000)
        }
    }

    private fun buildChatViews() {
        if (chatRunningUi || stickerButton.parent == null) return
        chatRunningUi = true
        loadNarrator(); updateNarratorIcon()
        if (narratorOn && !ttsFailed) ensureTts()
        root.addView(chatButton, FrameLayout.LayoutParams(px(40), px(40), Gravity.TOP or Gravity.START))
        chatButton.addOnLayoutChangeListener { _, l, t, r, b, _, _, _, _ -> if (r - l > 0 && b - t > 0) placeChatButton() }
        // Kotak chat di tengah atas, di bawah teks status; tidak lebih lebar dari 70% layar
        root.addView(chatBox, FrameLayout.LayoutParams(px(320), -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { topMargin = px(30) })
        root.addOnLayoutChangeListener { _, l, _, r, _, _, _, _, _ ->
            val w = minOf(px(320), ((r - l) * 0.7f).toInt())
            (chatBox.layoutParams as? FrameLayout.LayoutParams)?.let { if (it.width != w) { it.width = w; chatBox.layoutParams = it } }
        }
        placeChatButton()
    }

    /** Letakkan tombol chat di bawah tombol stiker; bila tak muat di bawah, di atasnya. */
    private fun placeChatButton() {
        if (!chatRunningUi || stickerButton.width <= 0 || root.height <= 0) return
        val gap = px(6)
        val below = stickerButton.y + stickerButton.height + gap
        val y = if (below + chatButton.height <= root.height) below else stickerButton.y - chatButton.height - gap
        chatButton.x = stickerButton.x
        chatButton.y = y.coerceIn(0f, (root.height - chatButton.height).coerceAtLeast(0).toFloat())
    }

    private fun setChatOpen(open: Boolean) {
        chatOpen = open
        chatInputRow.visibility = if (open) View.VISIBLE else View.GONE
        val imm = act.getSystemService(android.content.Context.INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager
        if (open) {
            stickerPanel.visibility = View.GONE
            chatBox.bringToFront()
            chatInput.requestFocus()
            imm.showSoftInput(chatInput, android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT)
            updateChatHint()
        } else {
            chatInput.clearFocus()
            imm.hideSoftInputFromWindow(chatInput.windowToken, 0)
        }
        renderChatLog()
    }

    private fun updateChatHint() {
        chatInput.hint = if (chatConnected) "Ketik pesan…" else "Chat menyambung… (butuh port ${chatPort} terbuka di host)"
    }

    private fun sendChat() {
        val text = chatInput.text.toString()
        val clean = NetplayChat.sanitize(text) ?: return
        if (!chat.send(clean)) {
            SoundToast.makeText(act, "Chat belum tersambung ke lawan", Toast.LENGTH_SHORT).show()
            return
        }
        chatInput.setText("")
        if (narratorOn) chatInput.performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY)   // tanda terkirim, tanpa teks di layar
        else addChatLine("P${localPlayerIdx + 1}: $clean")
    }

    private var chatPort = PORT + 1

    private fun addChatLine(line: String) {
        chatLines.addLast(line to System.currentTimeMillis())
        while (chatLines.size > CHAT_MAX_LINES) chatLines.removeFirst()
        renderChatLog()
        main.removeCallbacks(chatFade)
        main.postDelayed(chatFade, 1000)
    }

    private fun renderChatLog() {
        chatLog.text = chatLines.joinToString("\n") { it.first }
        chatLog.visibility = if (chatLines.isEmpty()) View.GONE else View.VISIBLE
        if (chatLines.isNotEmpty()) chatBox.bringToFront()
    }

    /** Tampilkan/sembunyikan tombol chat mengikuti status netplay (hanya saat game benar-benar berjalan). */
    private fun updateChat(running: Boolean) {
        if (running) buildChatViews()
        if (running && chatRunningUi && narratorOn && tts == null && !ttsFailed) ensureTts()   // sesi baru: mesin suara dibuat ulang
        if (!chatRunningUi) return
        chatButton.visibility = if (running) View.VISIBLE else View.GONE
        if (running) placeChatButton()
        else {
            if (chatOpen) setChatOpen(false)
            chatLines.clear(); renderChatLog()
        }
    }

    // ---- favorit: tekan lama stiker untuk memberi bintang (maks 5), favorit tampil paling depan
    private val stickerPrefs by lazy { act.getSharedPreferences("netplay_stickers", android.content.Context.MODE_PRIVATE) }
    private val favorites: MutableList<Int> by lazy {
        (stickerPrefs.getString("fav", "") ?: "").split(",")
            .mapNotNull { it.trim().toIntOrNull() }
            .filter { it in 0 until STICKER_COUNT }
            .distinct().take(MAX_FAV).toMutableList()
    }
    private val stickerRow by lazy {
        LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL; setPadding(px(6), px(6), px(6), px(6)) }
    }

    private fun saveFavorites() {
        try { stickerPrefs.edit().putString("fav", favorites.joinToString(",")).apply() } catch (_: Exception) {}
    }

    private fun toggleFavorite(index: Int) {
        if (favorites.remove(index)) {
            SoundToast.makeText(act, "Dihapus dari favorit", Toast.LENGTH_SHORT).show()
        } else if (favorites.size >= MAX_FAV) {
            SoundToast.makeText(act, "Slot favorit penuh (maks $MAX_FAV). Tekan lama stiker berbintang untuk melepas.", Toast.LENGTH_SHORT).show()
            return
        } else {
            favorites.add(index)
            SoundToast.makeText(act, "\u2B50 Disimpan sebagai favorit (${favorites.size}/$MAX_FAV)", Toast.LENGTH_SHORT).show()
        }
        saveFavorites()
        val keep = stickerPanel.scrollX
        fillStickerRow()
        stickerPanel.post { stickerPanel.scrollTo(keep, 0) }
    }

    /** Isi ulang baris stiker: favorit (berbintang) dulu, lalu sisanya sesuai nomor. */
    private fun fillStickerRow() {
        stickerRow.removeAllViews()
        val order = favorites + (0 until STICKER_COUNT).filter { it !in favorites }
        for (i in order) {
            val res = stickerIds.getOrNull(i)?.takeIf { it != 0 } ?: continue
            val cell = FrameLayout(act)
            cell.addView(ImageView(act).apply {
                setImageResource(res)
                setBackgroundColor(Color.WHITE)
                outlineProvider = roundOutline(px(10).toFloat()); clipToOutline = true
                setOnClickListener { sendSticker(i) }
                setOnLongClickListener {
                    performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS)
                    toggleFavorite(i); true
                }
            }, FrameLayout.LayoutParams(px(64), px(64)))
            if (i in favorites) {
                cell.addView(TextView(act).apply {
                    text = "\u2B50"; textSize = 14f; gravity = Gravity.CENTER
                    setShadowLayer(4f, 0f, 0f, Color.BLACK)
                }, FrameLayout.LayoutParams(px(22), px(22), Gravity.TOP or Gravity.END))
            }
            stickerRow.addView(cell, LinearLayout.LayoutParams(px(64), px(64)).apply { setMargins(px(4), 0, px(4), 0) })
        }
    }

    // ---- kipas favorit: tekan & seret tombol stiker -> favorit tampil setengah lingkaran, lepas di atas salah satunya untuk kirim
    private class FanItem(val index: Int, val view: ImageView, val cx: Float, val cy: Float)

    private val fanLayer = FrameLayout(act).apply {
        setBackgroundColor(0x44000000)
        visibility = View.GONE
        isClickable = false
    }
    private val fanItems = mutableListOf<FanItem>()
    private var fanHot = -1
    private var fanActive = false      // kipas sedang tampil dalam gestur ini
    private var fanRejected = false    // seret terdeteksi tapi belum ada favorit
    private var touchDownX = 0f
    private var touchDownY = 0f
    private val fanLoc = IntArray(2)

    private fun showFan(): Boolean {
        val favs = favorites.toList()
        if (favs.isEmpty()) {
            SoundToast.makeText(act, "Belum ada favorit. Tekan lama stiker di panel untuk memberi bintang \u2B50", Toast.LENGTH_SHORT).show()
            return false
        }
        stickerPanel.visibility = View.GONE
        fanLayer.removeAllViews(); fanItems.clear(); fanHot = -1
        fanLayer.visibility = View.VISIBLE
        val size = px(56)
        val radius = px(110).toFloat()
        val cx = stickerButton.x + stickerButton.width / 2f
        val cy = stickerButton.y + stickerButton.height / 2f
        val n = favs.size
        favs.forEachIndexed { k, idx ->
            val res = stickerIds.getOrNull(idx)?.takeIf { it != 0 } ?: return@forEachIndexed
            // setengah lingkaran terbuka ke sisi yang lapang (kiri bila tombol di kanan layar, sebaliknya); jarak antar stiker 45 derajat
            val phi = Math.toRadians((k - (n - 1) / 2.0) * 45.0)
            val dir = if (cx > root.width / 2f) -1f else 1f
            val half = size / 2f
            val x = (cx + dir * (radius * Math.cos(phi)).toFloat()).coerceIn(half, (root.width - half).coerceAtLeast(half))
            val y = (cy + (radius * Math.sin(phi)).toFloat()).coerceIn(half, (root.height - half).coerceAtLeast(half))
            val iv = ImageView(act).apply {
                setImageResource(res)
                setBackgroundColor(Color.WHITE)
                outlineProvider = roundOutline(px(12).toFloat()); clipToOutline = true
                elevation = px(4).toFloat()
                scaleX = 0.2f; scaleY = 0.2f; alpha = 0f
            }
            fanLayer.addView(iv, FrameLayout.LayoutParams(size, size, Gravity.TOP or Gravity.START).apply {
                leftMargin = (x - size / 2f).toInt(); topMargin = (y - size / 2f).toInt()
            })
            iv.animate().scaleX(1f).scaleY(1f).alpha(1f).setStartDelay((k * 25).toLong()).setDuration(140).start()
            fanItems.add(FanItem(idx, iv, x, y))
        }
        return fanItems.isNotEmpty()
    }

    private fun updateFanHot(rawX: Float, rawY: Float) {
        root.getLocationOnScreen(fanLoc)
        val x = rawX - fanLoc[0]
        val y = rawY - fanLoc[1]
        var best = -1
        var bestD = px(42).toFloat()
        fanItems.forEachIndexed { i, it ->
            val d = Math.hypot((x - it.cx).toDouble(), (y - it.cy).toDouble()).toFloat()
            if (d < bestD) { bestD = d; best = i }
        }
        if (best == fanHot) return
        fanHot = best
        fanItems.forEachIndexed { i, it ->
            val on = i == fanHot
            it.view.animate().scaleX(if (on) 1.3f else 1f).scaleY(if (on) 1.3f else 1f).setStartDelay(0).setDuration(90).start()
            it.view.elevation = px(if (on) 10 else 4).toFloat()
        }
        if (best >= 0) stickerButton.performHapticFeedback(android.view.HapticFeedbackConstants.CLOCK_TICK)
    }

    private fun hideFan() {
        fanLayer.visibility = View.GONE
        fanLayer.removeAllViews()
        fanItems.clear()
        fanHot = -1
        fanActive = false
    }

    // ---- pindah tombol: tekan lama tombol stiker lalu geser ke mana pun; posisi disimpan (pecahan layar)
    private var moveMode = false
    private var buttonPlaced = false
    private var btnStartX = 0f
    private var btnStartY = 0f
    private val longPressRun = Runnable {
        moveMode = true
        stickerButton.performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS)
        stickerButton.animate().scaleX(1.2f).scaleY(1.2f).alpha(1f).setDuration(100).start()
        stickerPanel.visibility = View.GONE
    }

    private fun clampButton(x: Float, y: Float) {
        val maxX = (root.width - stickerButton.width).coerceAtLeast(0).toFloat()
        val maxY = (root.height - stickerButton.height).coerceAtLeast(0).toFloat()
        stickerButton.x = x.coerceIn(0f, maxX)
        stickerButton.y = y.coerceIn(0f, maxY)
        placeChatButton()
    }

    private fun saveButtonPos() {
        if (root.width <= 0 || root.height <= 0) return
        try {
            stickerPrefs.edit()
                .putFloat("btn_fx", stickerButton.x / root.width)
                .putFloat("btn_fy", stickerButton.y / root.height)
                .apply()
        } catch (_: Exception) {}
    }

    /** Pasang posisi tersimpan (atau posisi bawaan: tepi kanan, tengah vertikal). */
    private fun restoreButtonPos() {
        if (root.width <= 0 || root.height <= 0 || stickerButton.width <= 0) return
        val has = stickerPrefs.contains("btn_fx") && stickerPrefs.contains("btn_fy")
        val x = if (has) stickerPrefs.getFloat("btn_fx", 0f) * root.width
                else (root.width - stickerButton.width - px(6)).toFloat()
        val y = if (has) stickerPrefs.getFloat("btn_fy", 0f) * root.height
                else (root.height - stickerButton.height) / 2f
        clampButton(x, y)
    }

    private fun installFanGesture() {
        val slop = android.view.ViewConfiguration.get(act).scaledTouchSlop * 1.5f
        val lpTimeout = android.view.ViewConfiguration.getLongPressTimeout().toLong()
        stickerButton.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                android.view.MotionEvent.ACTION_DOWN -> {
                    touchDownX = e.rawX; touchDownY = e.rawY
                    btnStartX = v.x; btnStartY = v.y
                    fanActive = false; fanRejected = false; moveMode = false
                    v.parent?.requestDisallowInterceptTouchEvent(true)
                    main.postDelayed(longPressRun, lpTimeout)
                }
                android.view.MotionEvent.ACTION_MOVE -> {
                    if (moveMode) {
                        clampButton(btnStartX + (e.rawX - touchDownX), btnStartY + (e.rawY - touchDownY))
                    } else {
                        if (!fanActive && !fanRejected &&
                            Math.hypot((e.rawX - touchDownX).toDouble(), (e.rawY - touchDownY).toDouble()) > slop) {
                            main.removeCallbacks(longPressRun)
                            if (showFan()) fanActive = true else fanRejected = true
                        }
                        if (fanActive) updateFanHot(e.rawX, e.rawY)
                    }
                }
                android.view.MotionEvent.ACTION_UP -> {
                    main.removeCallbacks(longPressRun)
                    if (moveMode) {
                        moveMode = false
                        saveButtonPos()
                        v.animate().scaleX(1f).scaleY(1f).alpha(0.85f).setDuration(100).start()
                    } else if (fanActive) {
                        val pick = fanItems.getOrNull(fanHot)?.index
                        hideFan()
                        if (pick != null) sendSticker(pick)   // tampil di layar sendiri + terkirim ke lawan
                    } else if (!fanRejected) {
                        v.performClick()                      // ketukan biasa: buka/tutup panel
                    }
                    fanRejected = false
                }
                android.view.MotionEvent.ACTION_CANCEL -> {
                    main.removeCallbacks(longPressRun)
                    if (moveMode) {
                        moveMode = false
                        saveButtonPos()
                        v.animate().scaleX(1f).scaleY(1f).alpha(0.85f).setDuration(100).start()
                    }
                    hideFan(); fanRejected = false
                }
            }
            true
        }
    }

    private fun buildStickerViews() {
        if (stickerButton.parent != null) return
        fillStickerRow()
        stickerPanel.addView(stickerRow)
        root.addView(stickerPanel, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        root.addView(fanLayer, FrameLayout.LayoutParams(-1, -1))   // di bawah tombol supaya tombol tetap menerima gestur
        installFanGesture()
        root.addView(stickerButton, FrameLayout.LayoutParams(px(40), px(40), Gravity.TOP or Gravity.START))
        // pasang posisi tersimpan begitu tombol selesai diukur (pertama kali tampil)
        stickerButton.addOnLayoutChangeListener { _, l, t, r, b, _, _, _, _ ->
            if (!buttonPlaced && r - l > 0 && b - t > 0) { buttonPlaced = true; restoreButtonPos() }
        }
        root.addOnLayoutChangeListener { _, l, t, r, b, ol, ot, orr, ob ->
            // layar berubah (rotasi/ukuran): pasang ulang posisi supaya tombol tidak keluar layar
            if (!moveMode && (r - l != orr - ol || b - t != ob - ot)) restoreButtonPos()
        }
        root.addView(stickerPopup, FrameLayout.LayoutParams(px(120), px(120), Gravity.TOP or Gravity.START).apply { leftMargin = px(16); topMargin = px(36) })
    }

    private fun sendSticker(index: Int) {
        val now = System.currentTimeMillis()
        if (now - lastStickerSent < 1000) return   // jeda 1 detik agar tidak spam
        lastStickerSent = now
        try { retro.netplaySendSticker(index) } catch (_: Exception) {}
        stickerPanel.visibility = View.GONE
        showSticker(index, localPlayerIdx)         // tampilkan juga di layar sendiri sebagai konfirmasi (sisi sesuai pemain sendiri)
    }

    /** Stiker P1 muncul di kiri, stiker P2 di kanan (sama di kedua layar). */
    private fun showSticker(index: Int, fromPlayer: Int) {
        val res = stickerIds.getOrNull(index)?.takeIf { it != 0 } ?: return
        (stickerPopup.layoutParams as? FrameLayout.LayoutParams)?.let { lp ->
            lp.gravity = Gravity.TOP or (if (fromPlayer == 1) Gravity.END else Gravity.START)
            lp.leftMargin = if (fromPlayer == 1) 0 else px(16)
            lp.rightMargin = if (fromPlayer == 1) px(16) else 0
            stickerPopup.layoutParams = lp
        }
        stickerPopup.setImageResource(res)
        stickerPopup.visibility = View.VISIBLE
        stickerPopup.bringToFront()
        stickerPopup.alpha = 1f
        ObjectAnimator.ofFloat(stickerPopup, View.SCALE_X, 0.3f, 1f).setDuration(180).start()
        ObjectAnimator.ofFloat(stickerPopup, View.SCALE_Y, 0.3f, 1f).setDuration(180).start()
        stickerHide?.let { main.removeCallbacks(it) }
        stickerHide = Runnable {
            stickerPopup.animate().alpha(0f).setDuration(300).withEndAction { stickerPopup.visibility = View.GONE }.start()
        }.also { main.postDelayed(it, 2500) }
    }

    private fun updateStickers(st: NetplayStatus) {
        val running = st.state == NetplayStatus.State.RUNNING
        localPlayerIdx = st.localPlayer
        if (running) buildStickerViews()
        if (stickerButton.parent == null) return
        stickerButton.visibility = if (running) View.VISIBLE else View.GONE
        if (!running) { stickerPanel.visibility = View.GONE; hideFan(); stickerSeen = false; return }
        // Stiker pertama dari lawan hanya dipakai sebagai acuan (abaikan sisa stiker sesi lama)
        if (!stickerSeen) { lastStickerIn = st.stickerInbox; stickerSeen = true; return }
        if (st.stickerInbox != lastStickerIn) {
            lastStickerIn = st.stickerInbox
            val id = (st.stickerInbox and 0xFF) - 1
            if (id >= 0) showSticker(id, 1 - localPlayerIdx)   // dari lawan = pemain lainnya
        }
    }

    /** True selama game dikendalikan sesi netplay: simpan/muat state, reset, cheat, fast forward dimatikan. */
    val active: Boolean
        get() = lastState == NetplayStatus.State.SYNCING || lastState == NetplayStatus.State.RUNNING

    /** True bila ada sesi (menunggu / menyambung / jalan). */
    val inSession: Boolean get() = lastState != NetplayStatus.State.OFF && lastState != NetplayStatus.State.ENDED

    fun showMenu(show: (AlertDialog.Builder) -> Unit) {
        val items = if (inSession || lastState == NetplayStatus.State.ENDED)
            arrayOf("Hentikan multiplayer")
        else arrayOf("Host (jadi pemain 1)", "Gabung (jadi pemain 2)")
        show(AlertDialog.Builder(act).setTitle("Multiplayer rollback").setItems(items) { _, i ->
            if (inSession || lastState == NetplayStatus.State.ENDED) stop()
            else if (i == 0) hostDialog(show) else joinDialog(show)
        })
    }

    // ---------------------------------------------------------------- multiplayer online (lobby)

    private var lobbyUrl = ""
    private var lobbyToken: String? = null
    private var lastBeat = 0L

    /** Dipanggil otomatis dari menu Multiplayer Online: jadi host, lalu tampilkan server di daftar lobby. */
    fun autoHost(
        delay: Int, lobbyUrl: String, room: String, publicIp: String,
        title: String, consoleName: String, owner: String, vpn: String = "", invite: String = ""
    ) {
        gameHash { hash ->
            val ok = host(hash, delay)
            afterStart(ok)
            if (!ok) return@gameHash
            // Umumkan lewat siaran jaringan ZeroTier (tanpa lobby): pemain lain di jaringan yang sama melihatnya otomatis
            ZtDiscovery.announce(room, title, consoleName, owner, PORT, 2, invite)
            if (ZtState.firstIp() != null) {
                SoundToast.makeText(act, "Server \"$room\" diumumkan otomatis di jaringan ZeroTier", Toast.LENGTH_LONG).show()
            }
            if (lobbyUrl.isBlank()) return@gameHash
            this.lobbyUrl = lobbyUrl
            val nr = LobbyApi.NewRoom(room, title, consoleName, PORT, delay, owner, publicIp, vpn)
            Thread {
                try {
                    val token = LobbyApi.register(lobbyUrl, nr)
                    lobbyToken = token
                    lastBeat = System.currentTimeMillis()
                    main.post { SoundToast.makeText(act, "Server \"$room\" tampil di daftar LOBBY", Toast.LENGTH_LONG).show() }
                } catch (e: LobbyApi.Rejected) {
                    main.post { SoundToast.makeText(act, "Tidak masuk daftar: ${e.message}\nPemain lain masih bisa gabung lewat IP.", Toast.LENGTH_LONG).show() }
                } catch (e: Exception) {
                    main.post { SoundToast.makeText(act, "Lobby tidak terjangkau: ${e.message ?: e.javaClass.simpleName}", Toast.LENGTH_LONG).show() }
                }
            }.start()
        }
    }

    /** Dipanggil otomatis dari menu Multiplayer Online: gabung ke server yang dipilih (alamat boleh berupa nama domain). */
    fun autoJoin(host: String, port: Int) {
        SoundToast.makeText(act, "Menyambung ke $host…", Toast.LENGTH_SHORT).show()
        Thread {
            // Native hanya menerima IPv4 angka, jadi nama domain di-resolve dulu di sini
            val ip = try {
                InetAddress.getAllByName(host).firstOrNull { it is Inet4Address }?.hostAddress
            } catch (_: Exception) { null }
            main.post {
                if (ip == null) {
                    SoundToast.makeText(act, "Alamat server tidak ditemukan: $host", Toast.LENGTH_LONG).show()
                } else {
                    gameHash { hash -> afterStart(join(ip, port, hash)) }
                }
            }
        }.start()
    }

    private fun lobbyBeat(st: NetplayStatus) {
        val token = lobbyToken ?: return
        val now = System.currentTimeMillis()
        if (now - lastBeat < 15_000) return
        lastBeat = now
        val players = if (st.state == NetplayStatus.State.SYNCING || st.state == NetplayStatus.State.RUNNING) 2 else 1
        val url = lobbyUrl
        Thread { try { LobbyApi.heartbeat(url, token, players) } catch (_: Exception) {} }.start()
    }

    private fun lobbyClose() {
        val token = lobbyToken ?: return
        lobbyToken = null
        val url = lobbyUrl
        Thread { try { LobbyApi.close(url, token) } catch (_: Exception) {} }.start()
    }

    private fun hostDialog(show: (AlertDialog.Builder) -> Unit) {
        val ips = localIps()
        val delays = listOf(1, 2, 3, 4, 5, 6, 7, 8)
        val labels = delays.map { d ->
            when (d) {
                1 -> "1 frame (paling responsif, koneksi harus bagus)"
                2 -> "2 frame (bawaan, cocok untuk Wi-Fi/LAN)"
                3 -> "3 frame (internet cukup stabil)"
                4 -> "4 frame (koneksi kurang stabil)"
                5 -> "5 frame (ZeroTier/VPN, disarankan)"
                6 -> "6 frame (ZeroTier lewat relay / ping tinggi)"
                7 -> "7 frame (ping sekitar 200 ms)"
                else -> "8 frame (ping 250 ms ke atas, paling mulus)"
            }
        }
        show(AlertDialog.Builder(act)
            // JANGAN pakai setMessage bersama setItems: Android menyembunyikan daftar pilihannya.
            .setTitle("Host: IP ${if (ips.isEmpty()) "(tidak terdeteksi)" else ips.joinToString(", ")} port $PORT\nPilih input delay (dipakai kedua pemain):")
            .setItems(labels.toTypedArray()) { _, i ->
                gameHash { hash ->
                    val ok = host(hash, delays[i])
                    afterStart(ok)
                }
            }
            .setNegativeButton("Batal", null))
    }

    private fun joinDialog(show: (AlertDialog.Builder) -> Unit) {
        val et = EditText(act).apply {
            hint = "IP host, mis. 192.168.1.5"
            setSingleLine(true)
            setText(lastIp)
        }
        val box = FrameLayout(act).apply {
            val m = (20 * act.resources.displayMetrics.density).toInt()
            setPadding(m, m / 2, m, 0)
            addView(et)
        }
        show(AlertDialog.Builder(act)
            .setTitle("Gabung ke host")
            .setMessage("Masukkan IP host (port $PORT dipakai otomatis; bisa juga ditulis ip:port).")
            .setView(box)
            .setPositiveButton("Gabung") { _, _ ->
                val txt = et.text.toString().trim()
                if (txt.isEmpty()) return@setPositiveButton
                lastIp = txt
                val ip = txt.substringBefore(':')
                val port = txt.substringAfter(':', "").toIntOrNull() ?: PORT
                gameHash { hash -> afterStart(join(ip, port, hash)) }
            }
            .setNegativeButton("Batal", null))
    }

    private fun host(hash: Int, delay: Int): Boolean {
        val ok = retro.netplayHost(PORT, hash, delay)
        if (ok) { chatPort = PORT + 1; chat.startHost(chatPort) }
        return ok
    }

    private fun join(ip: String, port: Int, hash: Int): Boolean {
        val ok = retro.netplayJoin(ip, port, hash, 2)
        if (ok) { chatPort = port + 1; chat.startClient(ip, chatPort) }
        return ok
    }

    /** Sidik jari game: CRC32 ROM digabung nama core. Harus sama di kedua HP. */
    private fun gameHash(onReady: (Int) -> Unit) {
        SoundToast.makeText(act, "Menyiapkan multiplayer…", Toast.LENGTH_SHORT).show()
        Thread {
            val crc = CRC32()
            try {
                rom.inputStream().use { s ->
                    val buf = ByteArray(64 * 1024)
                    while (true) { val n = s.read(buf); if (n <= 0) break; crc.update(buf, 0, n) }
                }
            } catch (_: Exception) {}
            val coreName = File(coreId).name.substringAfterLast('/')
            val h = (crc.value.toInt()) xor coreName.hashCode()
            main.post { onReady(h) }
        }.start()
    }

    private fun afterStart(ok: Boolean) {
        if (!ok) {
            val e = retro.netplayStatus().error
            SoundToast.makeText(act, errorText(e), Toast.LENGTH_LONG).show()
            retro.netplayStop()
            return
        }
        if (overlay.parent == null) {
            root.addView(overlay, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL))
        }
        startPolling()
    }

    fun stop() {
        polling = false
        ZtDiscovery.stopAnnounce()
        lobbyClose()
        try { retro.netplayStop() } catch (_: Exception) {}
        chat.stop(); chatConnected = false
        releaseTts()
        lastState = NetplayStatus.State.OFF
        if (chatRunningUi) { if (chatOpen) setChatOpen(false); chatButton.visibility = View.GONE; chatLines.clear(); renderChatLog() }
        overlay.visibility = android.view.View.GONE
        stickerButton.visibility = View.GONE
        stickerPanel.visibility = View.GONE
        stickerPopup.visibility = View.GONE
        stickerSeen = false
        main.removeCallbacks(longPressRun); moveMode = false
    }

    private fun startPolling() {
        if (polling) return
        polling = true
        main.post(object : Runnable {
            override fun run() {
                if (!polling) return
                val st = try { retro.netplayStatus() } catch (_: Exception) { null }
                if (st != null) render(st)
                if (polling) main.postDelayed(this, 250)
            }
        })
    }

    private fun render(st: NetplayStatus) {
        val prev = lastState
        lastState = st.state
        lobbyBeat(st)
        ZtDiscovery.setPlayers(if (st.state == NetplayStatus.State.SYNCING || st.state == NetplayStatus.State.RUNNING) 2 else 1)
        updateStickers(st)
        updateChat(st.state == NetplayStatus.State.RUNNING)
        overlay.visibility = android.view.View.VISIBLE
        overlay.text = when (st.state) {
            NetplayStatus.State.HOST_WAITING ->
                "Menunggu pemain 2… IP: ${localIps().joinToString(", ")}:$PORT" +
                    if (ZtDiscovery.sentCount() > 0) " · siaran ZeroTier terkirim ${ZtDiscovery.sentCount()}×" else ""
            NetplayStatus.State.CLIENT_CONNECTING -> "Menyambung ke host…"
            NetplayStatus.State.SYNCING -> "Sinkronisasi game…"
            NetplayStatus.State.RUNNING ->
                "P${st.localPlayer + 1} · ping ${st.pingMs} ms · rollback ${st.lastRollbackFrames}f" +
                    if (st.desync) " · DESYNC" + (if (st.desyncReason == 1) "(state lama)" else if (st.desyncReason == 2) "(hash)" else "") + "!" else ""
            else -> ""
        }
        if (st.state == NetplayStatus.State.ENDED && prev != NetplayStatus.State.ENDED) {
            SoundToast.makeText(act, errorText(st.error) + "\nGame dilanjutkan sendiri.", Toast.LENGTH_LONG).show()
            stop()
        }
    }

    private fun errorText(e: NetplayStatus.Error) = when (e) {
        NetplayStatus.Error.GAME_MISMATCH -> "Game/core berbeda: kedua HP harus memakai ROM dan core yang sama."
        NetplayStatus.Error.CONNECT -> "Tidak bisa tersambung ke host (cek IP, port $PORT, dan jaringan)."
        NetplayStatus.Error.TIMEOUT -> "Koneksi terputus (tidak ada balasan)."
        NetplayStatus.Error.VERSION -> "Versi multiplayer berbeda."
        NetplayStatus.Error.STATE_TOO_BIG -> "Core ini tidak cocok untuk rollback (state terlalu besar)."
        NetplayStatus.Error.SOCKET -> "Port $PORT tidak bisa dibuka (sedang dipakai?)."
        NetplayStatus.Error.PEER_LEFT -> "Lawan keluar dari multiplayer."
        NetplayStatus.Error.NONE -> "Multiplayer berhenti."
    }

    private fun localIps(): List<String> = try {
        NetworkInterface.getNetworkInterfaces().toList().flatMap { it.inetAddresses.toList() }
            .filter { it is Inet4Address && !it.isLoopbackAddress }.map { it.hostAddress ?: "" }
            .filter { it.isNotEmpty() }
    } catch (_: Exception) { emptyList() }

    companion object {
        const val PORT = 7755
        const val STICKER_COUNT = 48
        const val MAX_FAV = 5
        private const val CHAT_MAX_LINES = 6
        private const val CHAT_SHOW_MS = 8000L
        private var lastIp = ""
    }
}
