package com.allinone.emulator.ui

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.SoundPool
import android.os.Handler
import android.os.Looper
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.Window
import com.allinone.emulator.R
import com.allinone.emulator.input.VirtualPadView

/**
 * Bunyi klik untuk semua icon/tombol di menu (Library, Lobby, ROMS, ZeroTier, dan icon di dalam game).
 * - Dipasang otomatis ke setiap halaman lewat [App]; tombol gamepad virtual tidak ikut berbunyi.
 * - Suara klik diputar penuh (100%) dan lagu latar diturunkan sebentar supaya klik terdengar jelas.
 */
object UiSound {
    /** Volume lagu latar di semua halaman. */
    const val MUSIC_VOLUME = 0.8f
    /** Volume lagu latar sesaat ketika klik berbunyi. */
    private const val DUCKED_VOLUME = 0.25f
    private const val DUCK_MS = 1200L
    /** Saat game diketuk, lagu latar diturunkan lebih dalam dan lebih lama supaya bunyinya dominan. */
    private const val GAME_DUCKED_VOLUME = 0.12f
    private const val GAME_DUCK_MS = 2600L
    /** Lama bunyi ketuk game (ms) + sedikit jeda; game baru dibuka setelah bunyi selesai. */
    const val GAME_SOUND_MS = 2450L
    /** Lama bunyi ketuk LOBBY (ms) + sedikit jeda. */
    const val LOBBY_SOUND_MS = 1750L
    /** Lama bunyi ketuk ZEROTIER (ms) + sedikit jeda. */
    const val ZEROTIER_SOUND_MS = 2100L
    /** Lama bunyi tombol BATAL/TUTUP (ms) dipakai untuk lama penurunan volume musik. */
    const val CANCEL_SOUND_MS = 1650L
    /** Lama bunyi ketuk ROMS (ms), dipakai untuk lama penurunan volume musik. */
    const val ROMS_SOUND_MS = 2200L
    /** Lama bunyi pop up (Toast) dan jeda minimum antar bunyi pop up (ms). */
    private const val POPUP_SOUND_MS = 1500L
    private const val POPUP_MIN_GAP_MS = 700L
    /** Tag untuk tombol yang punya bunyi sendiri (bunyi klik umum dimatikan). */
    const val NO_CLICK_TAG = "ui_sound_none"
    /** Beri tag ini ke icon yang punya OnTouchListener sendiri supaya tetap berbunyi. */
    const val TAG = "ui_sound"

    /** Pemutar lagu latar halaman yang sedang terbuka (diisi tiap halaman). */
    @Volatile var music: MediaPlayer? = null
        set(value) {
            field = value
            // Lagu halaman baru yang mulai saat bunyi sedang diputar ikut diturunkan
            if (duckedUntil > android.os.SystemClock.uptimeMillis()) {
                legacyVolume(duckedVolume)
            }
        }
    private var duckedUntil = 0L
    private var duckedVolume = DUCKED_VOLUME

    private var pool: SoundPool? = null
    private var soundId = 0
    private var gameSoundId = 0
    private var lobbySoundId = 0
    private var zeroTierSoundId = 0
    private var cancelSoundId = 0
    private var romsSoundId = 0
    private var popupSoundId = 0
    private var lastPopupAt = 0L
    private var loaded = 0
    private val handler = Handler(Looper.getMainLooper())
    private val restore = Runnable {
        try { legacyVolume(MUSIC_VOLUME) } catch (_: Exception) {}
    }

    fun init(ctx: Context) {
        if (pool != null) return
        val sp = SoundPool.Builder()
            .setMaxStreams(3)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            ).build()
        sp.setOnLoadCompleteListener { _, _, status -> if (status == 0) loaded++ }
        soundId = sp.load(ctx.applicationContext, R.raw.confirm, 1)
        gameSoundId = sp.load(ctx.applicationContext, R.raw.game_start, 1)
        lobbySoundId = sp.load(ctx.applicationContext, R.raw.lobby_open, 1)
        zeroTierSoundId = sp.load(ctx.applicationContext, R.raw.zerotier_open, 1)
        cancelSoundId = sp.load(ctx.applicationContext, R.raw.cancel_sound, 1)
        romsSoundId = sp.load(ctx.applicationContext, R.raw.roms_open, 1)
        popupSoundId = sp.load(ctx.applicationContext, R.raw.popup, 1)
        pool = sp
    }

    fun play() {
        val sp = pool ?: return
        if (loaded < 7) return
        try {
            handler.removeCallbacks(restore)
            duckedVolume = DUCKED_VOLUME; duckedUntil = android.os.SystemClock.uptimeMillis() + DUCK_MS
            legacyVolume(DUCKED_VOLUME)
            sp.play(soundId, 1f, 1f, 1, 0, 1f)
            handler.postDelayed(restore, DUCK_MS)
        } catch (_: Exception) {}
    }

    // ------------------------------------------------------------------ lagu pudar (fade)

    /** Satu lagu latar yang volumenya diatur otomatis: pudar masuk, pudar keluar, dan pudar di ujung loop. */
    private class Voice(
        val p: MediaPlayer,
        val fadeInMs: Long,
        val fadeOutMs: Long,
        val loopEdgeMs: Long
    ) {
        var t0 = 0L
        var out = false
        var outT0 = 0L
        var outFrom = 1f
        var level = 0f
        var releaseAfter = false
    }

    private val voices = ArrayList<Voice>()
    private val ticker = object : Runnable {
        override fun run() {
            tick()
            if (voices.isNotEmpty()) handler.postDelayed(this, 40)
        }
    }

    /** Volume untuk lagu yang TIDAK memakai fade (ZeroTier, ROMS); lagu ber-fade diatur oleh [tick]. */
    private fun legacyVolume(v: Float) {
        val m = music ?: return
        if (voices.any { it.p === m }) return
        try { m.setVolume(v, v) } catch (_: Exception) {}
    }

    /**
     * Mulai/lanjutkan lagu dengan pudar masuk. Setelah itu lagu terus diputar berulang, dan tiap
     * ujung loop (akhir dan awal lagu) juga dipudarkan supaya sambungannya halus.
     */
    fun fadeStart(p: MediaPlayer, fadeInMs: Long = 1500L, fadeOutMs: Long = 900L, loopEdgeMs: Long = 2500L) {
        val now = android.os.SystemClock.uptimeMillis()
        var v = voices.firstOrNull { it.p === p }
        if (v == null) {
            v = Voice(p, fadeInMs, fadeOutMs, loopEdgeMs)
            v.t0 = now
            voices.add(v)
        } else {
            // dipanggil lagi saat sedang pudar keluar: pudar masuk dilanjutkan dari level sekarang
            v.t0 = now - (v.level * v.fadeInMs).toLong()
            v.out = false
            v.releaseAfter = false
        }
        try {
            p.setVolume(v.level * MUSIC_VOLUME, v.level * MUSIC_VOLUME)
            if (!p.isPlaying) p.start()
        } catch (_: Exception) {}
        music = p
        handler.removeCallbacks(ticker)
        handler.post(ticker)
    }

    /** Pudarkan lagu sampai senyap lalu jeda (atau lepas bila [release]). Aman dipanggil dari onPause/onDestroy. */
    fun fadeStop(p: MediaPlayer, release: Boolean) {
        val v = voices.firstOrNull { it.p === p }
        if (v == null) {
            try { if (release) p.release() else if (p.isPlaying) p.pause() } catch (_: Exception) {}
            return
        }
        if (v.out) { v.releaseAfter = v.releaseAfter || release; return }
        v.out = true
        v.outT0 = android.os.SystemClock.uptimeMillis()
        v.outFrom = v.level
        v.releaseAfter = release
        handler.removeCallbacks(ticker)
        handler.post(ticker)
    }

    private fun tick() {
        val now = android.os.SystemClock.uptimeMillis()
        val duck = if (now < duckedUntil) duckedVolume / MUSIC_VOLUME else 1f
        val it = voices.iterator()
        while (it.hasNext()) {
            val v = it.next()
            val page: Float = if (v.out) {
                v.outFrom * (1f - (now - v.outT0).toFloat() / v.fadeOutMs)
            } else {
                minOf(1f, (now - v.t0).toFloat() / v.fadeInMs)
            }
            if (page <= 0f && v.out) {
                try { if (v.releaseAfter) v.p.release() else if (v.p.isPlaying) v.p.pause() } catch (_: Exception) {}
                it.remove()
                continue
            }
            v.level = page
            var loop = 1f
            try {
                if (v.p.isPlaying) {
                    val dur = v.p.duration
                    val pos = v.p.currentPosition
                    if (dur > v.loopEdgeMs * 2) {
                        loop = minOf(1f, pos.toFloat() / v.loopEdgeMs, (dur - pos).toFloat() / v.loopEdgeMs)
                    }
                }
                val vol = (MUSIC_VOLUME * page * loop * duck).coerceIn(0f, 1f)
                v.p.setVolume(vol, vol)
            } catch (_: Exception) {}
        }
    }

    /** Bunyi saat sebuah game diketuk di Library. Mengembalikan berapa lama (ms) game perlu ditunda agar bunyinya terdengar penuh. */
    fun playGame(): Long {
        val sp = pool ?: return 0L
        if (loaded < 7) return 0L
        return try {
            handler.removeCallbacks(restore)
            duckedVolume = GAME_DUCKED_VOLUME; duckedUntil = android.os.SystemClock.uptimeMillis() + GAME_DUCK_MS
            legacyVolume(GAME_DUCKED_VOLUME)
            sp.play(gameSoundId, 1f, 1f, 1, 0, 1f)
            handler.postDelayed(restore, GAME_DUCK_MS)
            GAME_SOUND_MS
        } catch (_: Exception) { 0L }
    }

    /** Bunyi saat tombol LOBBY diketuk. Mengembalikan lama (ms) halaman perlu ditunda agar bunyinya terdengar penuh. */
    fun playLobby(): Long = playLong(lobbySoundId, LOBBY_SOUND_MS)

    /** Bunyi saat tombol ZEROTIER diketuk di Lobby. Mengembalikan lama (ms) halaman perlu ditunda. */
    fun playZeroTier(): Long = playLong(zeroTierSoundId, ZEROTIER_SOUND_MS)

    /** Bunyi saat tombol BATAL atau TUTUP diketuk (dialog maupun halaman). */
    /** Bunyi setiap pop up (Toast) muncul. Pop up beruntun dalam waktu sangat singkat tidak diulang bunyinya. */
    fun playPopup() {
        val now = android.os.SystemClock.uptimeMillis()
        if (now - lastPopupAt < POPUP_MIN_GAP_MS) return
        lastPopupAt = now
        playLong(popupSoundId, POPUP_SOUND_MS)
    }

    /** Bunyi saat tombol ROMS diketuk di Library. */
    fun playRoms(): Long = playLong(romsSoundId, ROMS_SOUND_MS)

    fun playCancel(): Long = playLong(cancelSoundId, CANCEL_SOUND_MS)

    private fun playLong(id: Int, ms: Long): Long {
        val sp = pool ?: return 0L
        if (loaded < 7) return 0L
        return try {
            handler.removeCallbacks(restore)
            duckedVolume = GAME_DUCKED_VOLUME; duckedUntil = android.os.SystemClock.uptimeMillis() + ms + 700
            legacyVolume(GAME_DUCKED_VOLUME)
            sp.play(id, 1f, 1f, 1, 0, 1f)
            handler.postDelayed(restore, ms + 700)
            ms
        } catch (_: Exception) { 0L }
    }

    /** Pasang pendeteksi sentuhan ke jendela halaman: berbunyi bila jari menekan icon/tombol yang bisa diklik. */
    fun hook(window: Window) {
        val orig = window.callback ?: return
        if (orig is HookedCallback) return
        window.callback = HookedCallback(window, orig)
    }

    private class HookedCallback(
        private val window: Window,
        private val orig: Window.Callback
    ) : Window.Callback by orig {
        override fun dispatchTouchEvent(event: MotionEvent): Boolean {
            if (event.actionMasked == MotionEvent.ACTION_DOWN) {
                try { pressedIcon(window.decorView, event.rawX, event.rawY)?.let { if (isCancelLabel(it)) playCancel() else play() } } catch (_: Exception) {}
            }
            return orig.dispatchTouchEvent(event)
        }
    }

    /** Ketukan di dalam dialog: BATAL/TUTUP/KEMBALI berbunyi "cancel", tombol/pilihan/kotak centang lain berbunyi "confirm". */
    fun dialogTouch(root: View, ev: MotionEvent) {
        if (ev.actionMasked != MotionEvent.ACTION_DOWN) return
        try {
            val v = dialogPressed(root, ev.rawX, ev.rawY) ?: return
            if (isCancelLabel(v)) playCancel() else play()
        } catch (_: Exception) {}
    }

    private fun dialogPressed(root: View, x: Float, y: Float): View? {
        var v: View? = deepest(root, x, y)
        while (v != null) {
            if (v.isClickable || v.tag == TAG) return v                  // tombol, kotak centang, baris yang bisa diklik
            if (v.parent is android.widget.AdapterView<*>) return v      // baris pilihan di daftar
            if (v === root) break
            v = v.parent as? View
        }
        return null
    }

    /** Tombol dengan tulisan BATAL, TUTUP, atau KEMBALI memakai bunyi tersendiri. */
    fun isCancelLabel(v: View): Boolean {
        val t = (v as? android.widget.TextView)?.text?.toString()?.trim()?.lowercase() ?: return false
        return t == "batal" || t == "tutup" || t == "kembali"
    }

    private fun pressedIcon(root: View, x: Float, y: Float): View? {
        var v: View? = deepest(root, x, y)
        val loc = IntArray(2)
        while (v != null) {
            if (v is VirtualPadView) return null
            if (v.tag == NO_CLICK_TAG) return null
            if (v.isClickable || v.tag == TAG) {
                // Abaikan penutup layar penuh yang kebetulan bisa diklik; yang dihitung hanyalah icon/tombol.
                v.getLocationOnScreen(loc)
                return if (v.width < root.width * 0.7f && v.height < root.height * 0.5f) v else null
            }
            v = v.parent as? View
        }
        return null
    }

    private fun deepest(v: View, x: Float, y: Float): View? {
        if (v.visibility != View.VISIBLE) return null
        val loc = IntArray(2)
        v.getLocationOnScreen(loc)
        if (x < loc[0] || x > loc[0] + v.width || y < loc[1] || y > loc[1] + v.height) return null
        if (v is ViewGroup) {
            for (i in v.childCount - 1 downTo 0) {
                deepest(v.getChildAt(i), x, y)?.let { return it }
            }
        }
        return v
    }
}
