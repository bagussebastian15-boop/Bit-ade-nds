package com.allinone.emulator.translate

import java.io.File

/**
 * Gaya dialog JRPG untuk hasil terjemahan Indonesia (berlaku untuk semua mesin terjemahan):
 *  - label pembicara berpola "XのY" (mis. "クレスの父ミゲール") dibalik jadi "Miguel (Ayah Cless)", bukan "Ayah Miguel Cless";
 *  - kutipan pembungkus dibuang (kotak dialog sudah menampilkan nama pembicara, dan kutipan memakan tempat);
 *  - sapaan keluarga dipendekkan seperti di terjemahan penggemar: "kakak" -> "Kak";
 *  - tanda baca disamakan dengan font piksel (tanpa "…" atau tanda baca Jepang yang tidak ada glyph-nya).
 * Mesin Groq mendapat panduan gaya yang sama lewat [GUIDE] supaya nada bicaranya (aku/kamu, partikel akhir kalimat) ikut JRPG.
 */
object JrpgStyle {

    private val RELATION = mapOf(
        "祖父" to "Kakek", "祖母" to "Nenek", "叔父" to "Paman", "叔母" to "Bibi",
        "息子" to "Putra", "娘" to "Putri", "友人" to "Teman", "友達" to "Teman",
        "師匠" to "Guru", "先生" to "Guru",
        "父" to "Ayah", "母" to "Ibu", "兄" to "Kakak", "姉" to "Kakak", "弟" to "Adik", "妹" to "Adik"
    )
    private val OF_PATTERN = Regex("^(.{1,12}?)の(祖父|祖母|叔父|叔母|息子|友人|友達|師匠|先生|父|母|兄|姉|弟|妹|娘)(.{1,14})$")

    /** Panduan gaya untuk penerjemah berbasis LLM (Groq). */
    const val GUIDE =
        "Style: polished JRPG fan-translation quality (SNES/PS1 era script). Casual, warm, spoken Indonesian. " +
        "Use aku/kamu between family, friends and peers; use saya/Anda only for clearly formal speakers (nobles, officials, " +
        "strangers). Family terms: 母さん/お母さん = Ibu, 父さん/お父さん = Ayah, お兄ちゃん/お兄さん/お姉ちゃん = Kak, " +
        "おじいちゃん = Kakek, おばあちゃん = Nenek. Do not translate honorific suffixes (-san, -kun, -chan) literally. " +
        "Convey sentence-final particles naturally and sparingly (ね = ya, よ = kok/lho/tahu, か/だ? = question, だろう = kan). " +
        "Never drop or summarize a clause, especially a trailing question. Keep character names exactly as written. " +
        "Keep the punctuation mood (..., !, ?) but do not wrap the line in quotation marks. " +
        "Keep it compact for a small dialog box: at most about 1.4x the length of the source."

    /**
     * "クレスの父ミゲール" -> "Miguel (Ayah Cless)". Null bila bukan pola itu atau ada bagian yang belum jadi huruf Latin
     * (nama tidak dikenal di glosarium): biarkan penerjemah yang menangani.
     */
    fun speaker(jaName: String, glossary: File?): String? {
        val n = JaPrep.normalize(jaName, glossary)
        val m = OF_PATTERN.matchEntire(n) ?: return null
        val owner = m.groupValues[1].trim()
        val who = m.groupValues[3].trim()
        val rel = RELATION[m.groupValues[2]] ?: return null
        if (owner.isEmpty() || who.isEmpty()) return null
        if (owner.any { it.code > 0x2E80 } || who.any { it.code > 0x2E80 }) return null
        return "$who ($rel $owner)"
    }

    private val WRAP_OPEN = Regex("^[\\s“”\"‘’「」『』]+")
    private val WRAP_CLOSE = Regex("[\\s“”\"‘’「」『』]+$")

    /** Perapian hasil terjemahan Indonesia ke gaya dialog JRPG. Aman dipanggil berulang. */
    fun polish(text: String): String {
        var s = text.replace("\r", "").trim()
        if (s.isEmpty()) return s
        // Kutipan pembungkus dibuang; kutipan di tengah kalimat dibiarkan (bisa jadi kutipan sungguhan).
        s = WRAP_OPEN.replace(s, "")
        s = WRAP_CLOSE.replace(s, "")
        // Tanda baca Jepang/lebar penuh yang lolos dari penerjemah -> ASCII; font piksel tidak punya glyph "…".
        s = s.replace('。', '.').replace('、', ',').replace('！', '!').replace('？', '?')
            .replace('・', '.').replace("…", "...").replace('—', '-').replace('–', '-')
        s = s.replace(Regex("\\.{4,}"), "...")
        // Font piksel tidak punya glyph panah, dan "~" tampil seperti "→" ("Ah→ah"): buang/ganti jadi tanda yang ada glyph-nya.
        s = s.replace(Regex("(?<=\\p{L})[~〜～→]+(?=\\p{L})"), "-").replace(Regex("[~〜～→]+"), "")
        // Sisa garis tegak/huruf l-I yang menempel setelah tanda baca akhir kalimat (sampah OCR): "berbahaya.lKita" -> "berbahaya. Kita"
        s = s.replace(Regex("(?<=[.!?])[|lI]+(?=\\p{Lu}|\\s+\\p{Lu}|\\s*$)"), " ").replace("|", " ")
        // Sapaan: "Hati-hati ya, kakak." -> "Hati-hati ya, Kak."; "Kakak, ..." di awal -> "Kak, ..."
        s = s.replace(Regex("(?<=[,!?] )[Kk]akak(?=[.!?…]*$)"), "Kak")
        s = s.replace(Regex("(?<=,)\\s*[Kk]akak(?=[.!?]*$)"), " Kak")
        s = s.replace(Regex("^[Kk]akak(?=\\s*,)"), "Kak")
        // Anda -> kamu hanya pada sapaan ke saudara/teman yang sudah jelas dari kata sapaannya.
        if (Regex("\\b(Kak|Ayah|Ibu|Kakek|Nenek)\\b").containsMatchIn(s)) s = s.replace(Regex("\\bAnda\\b"), "kamu")
        s = s.replace(Regex("[ \\t]{2,}"), " ").replace(Regex("\\s+([,.!?;:])"), "$1").trim()
        // Huruf pertama kapital (kalimat dialog), kecuali diawali elipsis.
        val i = s.indexOfFirst { it.isLetter() }
        if (i == 0) s = s.replaceFirstChar { it.uppercase() }
        return s
    }

    /** Rekam singkat percakapan terakhir sebagai konteks untuk LLM: tiap kotak dialog tidak berdiri sendiri. */
    class Recent(private val max: Int = 4) {
        private val lines = ArrayList<String>()
        @Synchronized fun add(s: String) {
            val t = s.trim()
            if (t.isEmpty() || lines.lastOrNull() == t) return
            lines += t
            while (lines.size > max) lines.removeAt(0)
        }
        @Synchronized fun text(): String = lines.joinToString(" | ")
        @Synchronized fun clear() = lines.clear()
    }
}
