package com.allinone.emulator.translate

import java.io.File

/**
 * Gaya dialog JRPG untuk hasil terjemahan Indonesia (berlaku untuk semua mesin terjemahan):
 *  - label pembicara berpola "XのY" (mis. "クレスの父ミゲール") dibalik jadi "Miguel (Ayah Cless)", bukan "Ayah Miguel Cless";
 *  - kutipan pembungkus dibuang (kotak dialog sudah menampilkan nama pembicara, dan kutipan memakan tempat);
 *  - sapaan keluarga dipendekkan seperti di terjemahan penggemar: "kakak" -> "Kak";
 *  - tanda baca disamakan dengan font piksel (tanpa "…" atau tanda baca Jepang yang tidak ada glyph-nya).
 * Mesin Groq mendapat panduan gaya yang sama lewat [GUIDE] supaya nada bicaranya (aku/kamu, partikel akhir kalimat) ikut JRPG.
 */
object JrpgStyle {

    private val RELATION = mapOf(
        "祖父" to "Kakek", "祖母" to "Nenek", "叔父" to "Paman", "叔母" to "Bibi",
        "息子" to "Putra", "娘" to "Putri", "友人" to "Teman", "友達" to "Teman",
        "師匠" to "Guru", "先生" to "Guru",
        "父" to "Ayah", "母" to "Ibu", "兄" to "Kakak", "姉" to "Kakak", "弟" to "Adik", "妹" to "Adik"
    )
    private val OF_PATTERN = Regex("^(.{1,12}?)の(祖父|祖母|叔父|叔母|息子|友人|友達|師匠|先生|父|母|兄|姉|弟|妹|娘)(.{1,14})$")

    /** Panduan gaya untuk penerjemah berbasis LLM (Groq). */
    const val GUIDE =
        "Style: polished JRPG fan-translation quality (SNES/PS1 era script). Casual, warm, spoken Indonesian. " +
        "Use aku/kamu between family, friends and peers; use saya/Anda only for clearly formal speakers (nobles, officials, " +
        "strangers). Family terms: 母さん/お母さん = Ibu, 父さん/お父さん = Ayah, お兄ちゃん/お兄さん/お姉ちゃん = Kak, " +
        "おじいちゃん = Kakek, おばあちゃん = Nenek. Do not translate honorific suffixes (-san, -kun, -chan) literally. " +
        "Convey sentence-final particles naturally and sparingly (ね = ya, よ = kok/lho/tahu, か/だ? = question, だろう = kan). " +
        "Never drop or summarize a clause, especially a trailing question. Keep character names exactly as written. " +
        "Shouts, screams, laughs and sound effects (おおお, うわああ, ぐっ, はあ, ははは) must be written as Indonesian-style " +
        "interjections (Ooooh!, Uwaaah!, Ugh!, Haah..., Hahaha!), never left in Japanese and never skipped. " +
        "Each input string is ONE sentence: return exactly one translation for it and never repeat, merge or add sentences. " +
        "Keep the punctuation mood (..., !, ?) but do not wrap the line in quotation marks. " +
        "Keep it compact for a small dialog box: at most about 1.4x the length of the source."

    /**
     * "クレスの父ミゲール" -> "Miguel (Ayah Cless)". Null bila bukan pola itu atau ada bagian yang belum jadi huruf Latin
     * (nama tidak dikenal di glosarium): biarkan penerjemah yang menangani.
     */
    fun speaker(jaName: String, glossary: File?): String? {
        val n = JaPrep.normalize(jaName, glossary)
        val m = OF_PATTERN.matchEntire(n) ?: return null
        val owner = m.groupValues[1].trim()
        val who = m.groupValues[3].trim()
        val rel = RELATION[m.groupValues[2]] ?: return null
        if (owner.isEmpty() || who.isEmpty()) return null
        if (owner.any { it.code > 0x2E80 } || who.any { it.code > 0x2E80 }) return null
        return "$who ($rel $owner)"
    }

    private val WRAP_OPEN = Regex("^[\\s“”\"‘’「」『』]+")
    private val WRAP_CLOSE = Regex("[\\s“”\"‘’「」『』]+$")

    /** Perapian hasil terjemahan Indonesia ke gaya dialog JRPG. Aman dipanggil berulang. */
    fun polish(text: String, fromJa: Boolean = false): String {
        var s = text.replace("\r", "").trim()
        if (s.isEmpty()) return s
        // Kutipan pembungkus dibuang; kutipan di tengah kalimat dibiarkan (bisa jadi kutipan sungguhan).
        s = WRAP_OPEN.replace(s, "")
        s = WRAP_CLOSE.replace(s, "")
        // Tanda baca Jepang/lebar penuh yang lolos dari penerjemah -> ASCII; font piksel tidak punya glyph "…".
        s = s.replace('。', '.').replace('、', ',').replace('！', '!').replace('？', '?')
            .replace('・', '.').replace("…", "...").replace('—', '-').replace('–', '-')
        s = s.replace(Regex("\\.{4,}"), "...")
        // Font piksel tidak punya glyph panah, dan "~" tampil seperti "→" ("Ah→ah"): buang/ganti jadi tanda yang ada glyph-nya.
        if (fromJa) s = s.replace(Regex("(?<=\\p{L})[~〜～→]+(?=\\p{L})"), "-").replace(Regex("[~〜～→]+"), "")
        // Sisa garis tegak/huruf l-I yang menempel setelah tanda baca akhir kalimat (sampah OCR): "berbahaya.lKita" -> "berbahaya. Kita"
        if (fromJa) s = s.replace(Regex("(?<=[.!?])[|lI]+(?=\\p{Lu}|\\s+\\p{Lu}|\\s*$)"), " ").replace("|", " ")
        // Sapaan: "Hati-hati ya, kakak." -> "Hati-hati ya, Kak."; "Kakak, ..." di awal -> "Kak, ..."
        s = s.replace(Regex("(?<=[,!?] )[Kk]akak(?=[.!?…]*$)"), "Kak")
        s = s.replace(Regex("(?<=,)\\s*[Kk]akak(?=[.!?]*$)"), " Kak")
        s = s.replace(Regex("^[Kk]akak(?=\\s*,)"), "Kak")
        // Anda -> kamu hanya pada sapaan ke saudara/teman yang sudah jelas dari kata sapaannya.
        if (Regex("\\b(Kak|Ayah|Ibu|Kakek|Nenek)\\b").containsMatchIn(s)) s = s.replace(Regex("\\bAnda\\b"), "kamu")
        s = s.replace(Regex("[ \\t]{2,}"), " ").replace(Regex("\\s+([,.!?;:])"), "$1").trim()
        // Huruf pertama kapital (kalimat dialog), kecuali diawali elipsis.
        val i = s.indexOfFirst { it.isLetter() }
        if (i == 0) s = s.replaceFirstChar { it.uppercase() }
        return dedupeSentences(s)
    }

    /** Kalimat panjang hasil terjemahan yang persis sama dengan kalimat sebelumnya (mesin mengulang) dibuang. */
    fun dedupeSentences(text: String): String {
        val parts = text.split(Regex("(?<=[.!?])\\s+"))
        if (parts.size < 2) return text
        val seen = HashSet<String>()
        val kept = ArrayList<String>()
        for (p in parts) {
            val key = p.lowercase().filter { it.isLetter() }
            if (key.length >= 12 && !seen.add(key)) continue
            kept += p
        }
        return kept.joinToString(" ")
    }

    /** Padanan kata yang sering keliru pada mesin terjemahan: (kata Jepang di sumber, pola salah, pengganti). */
    private val FIX_JA = listOf(
        Triple("獲物", Regex("\\b(mangsa|hasil tangkapan|tangkapan|permainan|piala)\\b", RegexOption.IGNORE_CASE), "buruan"),
        Triple("師匠", Regex("\\b(master|tuan guru|mahaguru)\\b", RegexOption.IGNORE_CASE), "guruku"),
        Triple("風邪", Regex("\\b(angin jahat|angin dingin|jahat)\\b", RegexOption.IGNORE_CASE), "masuk angin"),
        Triple("山ほど", Regex("\\b(sebanyak gunung|seperti gunung|sebesar gunung)\\b", RegexOption.IGNORE_CASE), "setumpuk"),
        Triple("心配しない", Regex("\\b(jangan khawatirkan|tak usah cemas)\\b", RegexOption.IGNORE_CASE), "jangan khawatir")
    )

    /** Koreksi istilah berdasarkan kata di teks Jepang asli (hanya bila kata itu memang ada di sumber). */
    fun fixJa(source: String, out: String): String {
        var s = out
        for ((key, wrong, right) in FIX_JA) if (source.contains(key)) s = wrong.replace(s, right)
        return s
    }

    /** Terjemahan mesin sering menghilangkan tanda baca akhir: samakan dengan sumber (。→. ！→! ？→?). */
    fun matchEnding(source: String, out: String): String {
        val src = source.trimEnd(' ', '”', '"', '」', '』', '）', ')')
        val o = out.trimEnd()
        if (src.isEmpty() || o.isEmpty()) return out
        val last = o.last()
        if (last in ".!?…," ) return if (last == ',') o.dropLast(1) + (if (src.last() in "！!") "!" else if (src.last() in "？?") "?" else ".") else out
        return when (src.last()) {
            '。', '.' -> "$o."
            '！', '!' -> "$o!"
            '？', '?' -> "$o?"
            else -> out
        }
    }

    /** Rekam singkat percakapan terakhir sebagai konteks untuk LLM: tiap kotak dialog tidak berdiri sendiri. */
    class Recent(private val max: Int = 4) {
        private val lines = ArrayList<String>()
        @Synchronized fun add(s: String) {
            val t = s.trim()
            if (t.isEmpty() || lines.lastOrNull() == t) return
            lines += t
            while (lines.size > max) lines.removeAt(0)
        }
        @Synchronized fun text(): String = lines.joinToString(" | ")
        @Synchronized fun clear() = lines.clear()
    }
}
