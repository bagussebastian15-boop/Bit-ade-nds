package com.allinone.emulator.translate

import android.graphics.Bitmap
import android.graphics.RectF
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL

/**
 * Bantuan OCR online: model gambar (vision LLM) memeriksa hasil baca OCR bawaan (ML Kit).
 *
 * OCR bawaan tetap yang PERTAMA membaca dan menentukan letak teks. Setelah itu seluruh layar game + bacaan OCR tiap
 * kotak teks dikirim ke model vision, yang mengembalikan teks yang sebenarnya tampil di tiap kotak (memperbaiki
 * salah baca kana/huruf pada font piksel). Hasilnya HANYA mengganti teks; kotak/posisi tetap dari OCR bawaan.
 * Bila gagal (tanpa internet, kunci salah, jawaban rusak) hasil OCR bawaan dipakai apa adanya.
 */
object VisionOcr {
    const val PROVIDER_GEMINI = 0
    const val PROVIDER_GROQ = 1

    const val GEMINI_DEFAULT_MODEL = "gemini-flash-latest"
    const val GROQ_DEFAULT_MODEL = "qwen/qwen3.8-27b"

    fun defaultModel(provider: Int) = if (provider == PROVIDER_GROQ) GROQ_DEFAULT_MODEL else GEMINI_DEFAULT_MODEL
    fun providerName(provider: Int) = if (provider == PROVIDER_GROQ) "Groq" else "Gemini"

    private const val GROQ_URL = "https://api.groq.com/openai/v1/chat/completions"
    private const val GEMINI_URL = "https://generativelanguage.googleapis.com/v1beta/models/"
    private const val MAX_SIDE = 1280
    private const val MAX_ITEMS = 40

    class Item(val text: String, val box: RectF)

    /** Hasil: [texts] sama banyak dan urutannya dengan masukan; [status] ringkasan untuk diagnosis. */
    class Outcome(val texts: List<String>?, val status: String)

    /**
     * Mengembalikan teks yang sudah dikoreksi, atau null di [Outcome.texts] bila gagal / tidak dipakai.
     * Harus dipanggil dari thread IO (jaringan).
     */
    fun refine(
        frame: Bitmap, items: List<Item>, provider: Int, key: String, model: String, scriptHint: String
    ): Outcome {
        if (items.isEmpty()) return Outcome(null, "tidak ada kotak teks")
        if (items.size > MAX_ITEMS) return Outcome(null, "terlalu banyak kotak (${items.size})")
        if (key.isBlank()) return Outcome(null, "API key ${providerName(provider)} kosong")
        val mdl = model.trim().ifEmpty { defaultModel(provider) }
        return try {
            val jpeg = encode(frame)
            val prompt = buildPrompt(frame, items, scriptHint)
            val raw = if (provider == PROVIDER_GROQ) callGroq(key.trim(), mdl, prompt, jpeg) else callGemini(key.trim(), mdl, prompt, jpeg)
            val arr = parse(raw, items.size) ?: return Outcome(null, "jawaban model tidak valid")
            var changed = 0
            val out = items.mapIndexed { i, it ->
                val v = sanitize(arr[i], it.text)
                if (v != it.text) changed++
                v
            }
            Outcome(out, "${providerName(provider)} $mdl: ${items.size} kotak, $changed dikoreksi")
        } catch (e: Exception) {
            Outcome(null, (e.message ?: e.javaClass.simpleName).take(160))
        }
    }

    private fun encode(src: Bitmap): ByteArray {
        val scale = minOf(1f, MAX_SIDE.toFloat() / maxOf(src.width, src.height))
        val bmp = if (scale < 1f) Bitmap.createScaledBitmap(src, (src.width * scale).toInt().coerceAtLeast(1), (src.height * scale).toInt().coerceAtLeast(1), true) else src
        try {
            val bo = ByteArrayOutputStream()
            bmp.compress(Bitmap.CompressFormat.JPEG, 92, bo)
            return bo.toByteArray()
        } finally {
            if (bmp !== src) bmp.recycle()
        }
    }

    private fun buildPrompt(frame: Bitmap, items: List<Item>, scriptHint: String): String {
        val w = frame.width.toFloat().coerceAtLeast(1f)
        val h = frame.height.toFloat().coerceAtLeast(1f)
        val regions = JSONArray()
        for ((i, it) in items.withIndex()) {
            fun n(v: Float, d: Float) = (v / d * 1000f).toInt().coerceIn(0, 1000)
            regions.put(JSONObject()
                .put("id", i)
                .put("box", JSONArray(listOf(n(it.box.left, w), n(it.box.top, h), n(it.box.right, w), n(it.box.bottom, h))))
                .put("ocr", it.text))
        }
        val lang = when (scriptHint) {
            "ja" -> "Japanese"; "zh" -> "Chinese"; "ko" -> "Korean"; else -> "the game's language (Latin script)"
        }
        return "The image is a screenshot of a retro video game. A basic OCR engine already read ${items.size} text " +
            "region(s), often with mistakes on pixel fonts (wrong kana/letters, missed small marks like ! ? ... or dakuten). " +
            "Each region has a box [left, top, right, bottom] in 0-1000 coordinates (fractions of image width/height) and the OCR reading. " +
            "Expected language: $lang.\n" +
            "For every region, look at that box in the image and return the text exactly as it is displayed there, in the original " +
            "language. Rules: do NOT translate; do NOT add text that is not shown; do NOT drop text that is shown; keep the reading order; " +
            "join wrapped lines of one box with a single space (no spaces between Japanese/Chinese characters); keep punctuation. " +
            "If the OCR reading is already correct, return it unchanged. If you cannot see real text in a box, return the OCR reading unchanged.\n" +
            "Reply ONLY with a JSON object {\"t\": [...]} containing exactly ${items.size} strings in the same order as the regions.\n" +
            "Regions: $regions"
    }

    /** Jawaban yang jauh melenceng dari bacaan OCR (halusinasi, terjemahan, kosong) diabaikan: pakai OCR. */
    private fun sanitize(v: String?, ocr: String): String {
        val t = v?.replace(Regex("\\s*\\n+\\s*"), " ")?.trim().orEmpty()
        if (t.isEmpty()) return ocr
        val a = ocr.count { !it.isWhitespace() }
        val b = t.count { !it.isWhitespace() }
        if (a >= 3 && (b > a * 2.5f + 4 || b < a * 0.4f)) return ocr
        return t
    }

    private fun parse(raw: String, n: Int): List<String>? {
        var s = raw.replace(Regex("(?s)<think>.*?</think>"), "").trim()
        val a = s.indexOf('{'); val b = s.lastIndexOf('}')
        if (a < 0 || b <= a) return null
        s = s.substring(a, b + 1)
        val arr = try { JSONObject(s).getJSONArray("t") } catch (_: Exception) { return null }
        if (arr.length() != n) return null
        return List(n) { arr.optString(it, "") }
    }

    private fun post(url: String, headers: Map<String, String>, body: JSONObject, provider: Int): String {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 8000
            c.readTimeout = 30000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            for ((k, v) in headers) c.setRequestProperty(k, v)
            c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            if (code != 200) {
                val err = try { c.errorStream?.bufferedReader()?.use { it.readText() } } catch (_: Exception) { null }
                val detail = try { JSONObject(err ?: "").getJSONObject("error").optString("message") } catch (_: Exception) { "" }
                val name = providerName(provider)
                throw IllegalStateException(when (code) {
                    400 -> "$name menolak permintaan (400)" + if (detail.isNotEmpty()) ": ${detail.take(100)}" else ", periksa nama model"
                    401, 403 -> "API key $name ditolak ($code), periksa kuncinya"
                    404 -> "Model $name tidak ditemukan (404), periksa nama model"
                    429 -> "Kuota/batas laju $name tercapai (429)"
                    else -> "$name error $code" + if (detail.isNotEmpty()) ": ${detail.take(100)}" else ""
                })
            }
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            try { c.errorStream?.close() } catch (_: Exception) {}
        }
    }

    private fun callGemini(key: String, model: String, prompt: String, jpeg: ByteArray): String {
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray()
                .put(JSONObject().put("text", prompt))
                .put(JSONObject().put("inline_data", JSONObject()
                    .put("mime_type", "image/jpeg")
                    .put("data", Base64.encodeToString(jpeg, Base64.NO_WRAP)))))))
            .put("generationConfig", JSONObject().put("temperature", 0).put("responseMimeType", "application/json"))
        val resp = post("$GEMINI_URL$model:generateContent", mapOf("x-goog-api-key" to key), body, PROVIDER_GEMINI)
        val parts = JSONObject(resp).getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts")
        val sb = StringBuilder()
        for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text", ""))
        return sb.toString()
    }

    private fun callGroq(key: String, model: String, prompt: String, jpeg: ByteArray): String {
        val uri = "data:image/jpeg;base64," + Base64.encodeToString(jpeg, Base64.NO_WRAP)
        val body = JSONObject()
            .put("model", model)
            .put("temperature", 0)
            .put("response_format", JSONObject().put("type", "json_object"))
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", JSONArray()
                .put(JSONObject().put("type", "text").put("text", prompt))
                .put(JSONObject().put("type", "image_url").put("image_url", JSONObject().put("url", uri))))))
        val resp = post(GROQ_URL, mapOf("Authorization" to "Bearer $key"), body, PROVIDER_GROQ)
        return JSONObject(resp).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
    }
}
