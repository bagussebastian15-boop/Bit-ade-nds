package com.allinone.emulator.translate

/**
 * Perbaikan teks Inggris SEBELUM dikirim ke penerjemah (Google/ML Kit/LLM) dan perapian hasil Indonesia SESUDAHNYA.
 *
 * Masalah yang diatasi:
 * 1. Font piksel membuat koma dan titik tampak sama, sehingga OCR menghasilkan "Hey. You trust me right?" dan
 *    "...support me on this. And we'll be..." (kalimat terpotong jadi dua, Google kehilangan konteks).
 * 2. Kotak dialog sering berhenti di tengah kalimat ("...we'll be a whole lot"), kalimat lanjut di kotak berikutnya.
 *    Potongan diberi "..." supaya diterjemahkan sebagai potongan, bukan sebagai kalimat utuh yang salah.
 * 3. Google Translate memakai "saya/Anda" yang kaku; dialog game lebih wajar dengan "aku/kamu".
 */
object EnglishPrep {

    private val INTERJ = Regex(
        "(^|[.!?]\\s+)(hey|hi|hello|well|oh|ah|look|listen|wait|okay|ok)\\.\\s+(\\p{L}+('\\p{L}+)?)",
        RegexOption.IGNORE_CASE
    )

    // "...this. And we'll..." -> "...this, and we'll..." (titik OCR yang sebenarnya koma)
    private val CONJ = Regex(
        "(?<=[\\p{L}'])\\.\\s+(and|or|but|which|because|though|although|until|unless)\\b",
        RegexOption.IGNORE_CASE
    )

    // "Vinnie. I thought..." -> "Vinnie, I thought..." (sapaan nama di awal kalimat; titik OCR yang sebenarnya koma)
    private val VOCATIVE = Regex("^(\\p{Lu}[\\p{L}']{2,})[.,]\\s+(\\p{L}[\\p{L}']*)")

    private val QUESTION_AUX = Regex(
        "^(is|are|am|was|were|do|does|did|can|could|will|would|should|shall|have|has|had|what|who|whom|whose|where|when|why|how|which)\\b",
        RegexOption.IGNORE_CASE
    )
    private val STATEMENT_START = Regex(
        "^(you|i|we|they|he|she|it|that|this|there)\\b",
        RegexOption.IGNORE_CASE
    )
    private val TAG_RIGHT = Regex("(?<!,)\\s+(right)\\?$", RegexOption.IGNORE_CASE)

    private val FORMAL_HINT = Regex(
        "\\b(sir|ma'am|madam|my lord|my lady|your (?:majesty|highness|excellency|grace)|milord|milady)\\b",
        RegexOption.IGNORE_CASE
    )

    /** true bila teks berhenti di tengah kalimat (tanpa tanda baca akhir), kemungkinan besar lanjut di kotak berikutnya. */
    fun isIncomplete(text: String): Boolean {
        val t = text.trimEnd()
        if (t.isEmpty()) return false
        val words = Regex("[\\p{L}\\p{N}']+").findAll(t).count()
        if (words < 4) return false
        val last = t.last()
        if (last == ',' || last == ';' || last == '-') return true
        // "...and we'll be a whole lot" (menunggu "better/stronger" di kotak berikutnya)
        if (Regex("\\b(whole lot|little bit|bit more|little more|a lot more)$", RegexOption.IGNORE_CASE).containsMatchIn(t)) return true
        // Titik di font piksel sering tidak terbaca, jadi akhir kata benda/kata kerja TIDAK dianggap potongan.
        // Hanya kata yang pasti menggantung (kata sambung, depan, artikel, bantu) yang berarti lanjut ke kotak berikutnya.
        if (!last.isLetterOrDigit()) return false
        val lw = Regex("[\\p{L}']+$").find(t)?.value?.lowercase() ?: return false
        return lw in DANGLING
    }

    private val DANGLING = setOf(
        "a", "an", "the", "and", "or", "but", "so", "to", "of", "in", "on", "at", "for", "with", "from", "by", "as",
        "that", "than", "then", "if", "my", "your", "his", "her", "its", "our", "their", "this", "these", "those",
        "is", "are", "was", "were", "be", "been", "am", "i'm", "you're", "we're", "they're", "it's", "that's",
        "will", "would", "can", "could", "should", "shall", "may", "might", "must", "have", "has", "had", "not",
        "very", "too", "more", "most", "some", "any", "all", "into", "onto", "over", "under", "about", "after",
        "before", "because", "while", "when", "where", "which", "who", "what", "how", "why", "just", "even", "only",
        "also", "gonna", "gotta", "wanna", "hafta", "we've", "i've", "you've", "they've", "we'll", "i'll", "you'll"
    )
    private val OPENERS = setOf("hey", "hi", "hello", "look", "listen", "well", "oh", "yes", "yeah", "no", "okay", "ok", "wait", "so")

    // "your drill" = bor (alat) di game seperti Drill Dozer; mesin terjemahan memilih "latihan". Nama "Drill Dozer" dibiarkan.
    private val DRILL_TOOL = Regex(
        "\\b(your|my|our|his|her|their|this|that|new|super|power|mighty)\\s+drills?\\b(?!\\s+(?:dozer|sergeant|instructor|team|practice|exercise|session))",
        RegexOption.IGNORE_CASE
    )
    private val SHIFT_UP_GEAR = Regex("\\bshift(?:ing|s)?\\s+up\\s+to\\s+another\\s+gear\\b", RegexOption.IGNORE_CASE)

    /** Istilah game yang sering salah diterjemahkan mesin; diganti SEBELUM diterjemahkan. */
    fun gameTerms(text: String): String {
        var s = text
        s = DRILL_TOOL.replace(s) { m -> m.groupValues[1] + " bor" }
        s = SHIFT_UP_GEAR.replace(s) { m -> if (m.value[0].isUpperCase()) "Shifting to a higher gear" else "shifting to a higher gear" }
        return s
    }

    /**
     * @param continuation true bila kotak dialog sebelumnya berhenti di tengah kalimat (teks ini adalah lanjutannya).
     */
    fun prepare(text: String, continuation: Boolean): String {
        var s = gameTerms(text.trim())
        if (s.isEmpty()) return s

        // 1) Titik yang sebenarnya koma.
        s = INTERJ.replace(s) { m ->
            val next = m.groupValues[3]
            val nextFixed = if (next == "I" || next.startsWith("I'")) next else next.replaceFirstChar { it.lowercase() }
            m.groupValues[1] + m.groupValues[2] + ", " + nextFixed
        }
        s = CONJ.replace(s) { m -> ", " + m.groupValues[1].lowercase() }
        s = VOCATIVE.replace(s) { m ->
            val name = m.groupValues[1]
            val next = m.groupValues[2]
            // hanya nama diri (bukan kata kamus): "Stop. I..." tetap dua kalimat
            if (!LatinFix.looksProper(name.lowercase())) m.value
            else {
                val nextFixed = if (next == "I" || next.startsWith("I'")) next else next.replaceFirstChar { it.lowercase() }
                "$name, $nextFixed"
            }
        }

        // 2) Pertanyaan penegas: "You trust me right?" -> "You trust me, right?"
        s = s.split(Regex("(?<=[.!?])\\s+")).joinToString(" ") { sent ->
            val st = sent.trim()
            val core = st.replace(Regex("^\\p{L}+,\\s+"), "")      // lewati sapaan "Hey, "
            if (STATEMENT_START.containsMatchIn(core) && !QUESTION_AUX.containsMatchIn(core)) TAG_RIGHT.replace(st, ", $1?") else st
        }

        // 3) Potongan kalimat: tandai dengan "..." agar tidak dianggap kalimat lengkap.
        if (continuation && !s.startsWith("...") && !s.startsWith("…") &&
            s.substringBefore(' ').trim(',', '.', '!', '?').lowercase() !in OPENERS) {
            val first = s.take(2)
            val keepCap = first == "I " || first.startsWith("I'") || s.take(2) == "I'"
            s = "... " + (if (keepCap) s else s.replaceFirstChar { it.lowercase() })
        }
        if (isIncomplete(s)) s = s.trimEnd(',', ';', '-', ' ') + "..."
        else s = closeSentence(s)
        return s
    }

    /**
     * Titik di font piksel sering tidak terbaca, padahal penerjemah mesin sangat bergantung pada tanda baca akhir:
     * tanpa titik, kalimat dianggap potongan dan diterjemahkan setengah-setengah. Kalimat lengkap diberi titik.
     */
    private fun closeSentence(s: String): String {
        val t = s.trimEnd()
        if (t.isEmpty()) return s
        val last = t.last()
        if (!last.isLetterOrDigit() && last != '\'') return s
        val words = Regex("[\\p{L}\\p{N}']+").findAll(t).count()
        return if (words >= 3) "$t." else s
    }

    /**
     * Hasil Google sering memakai "saya/Anda" yang kaku untuk dialog game. Diubah ke "aku/kamu", kecuali ada penanda
     * bahasa resmi di teks sumber (sir, ma'am, your majesty, ...).
     */
    fun casual(translated: String, source: String): String {
        if (translated.isBlank() || FORMAL_HINT.containsMatchIn(source)) return translated
        var s = translated
        s = s.replace("dalam hal ini", "soal ini").replace("Dalam hal ini", "Soal ini")
        for ((w, r) in listOf("saya" to "aku", "anda" to "kamu")) {
            s = Regex("\\b$w\\b", RegexOption.IGNORE_CASE).replace(s) { m ->
                val atStart = m.range.first == 0 ||
                    s.substring(0, m.range.first).trimEnd().let { it.isEmpty() || it.last() in ".!?" || it.endsWith("...") }
                if (atStart) r.replaceFirstChar { it.uppercase() } else r
            }
        }
        return s
    }
}
