plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// ZeroTier tertanam bersifat OPSIONAL: hanya ikut bila scripts/setup_zerotier_core.sh berhasil (dan tidak dimatikan dengan -PnoZt=true).
// Tanpa itu, aplikasi tetap dibuild dan layar ZeroTier menampilkan bahwa mesinnya tidak ikut.
val ztReady = !project.hasProperty("noZt") &&
    file("zt-sdk/java/com/zerotier/sdk/Node.java").exists() &&
    file("src/main/jniLibs/arm64-v8a/libZeroTierOneJNI.so").exists()

android {
    namespace = "com.allinone.emulator"
    compileSdk = 34
    ndkVersion = "25.2.9519653"   // untuk core SeedlessDS (CMake); dipasang otomatis oleh langkah workflow

    defaultConfig {
        applicationId = "com.allinone.emulator"
        minSdk = 21            // Android 5.0
        targetSdk = 34
        versionCode = 27
        versionName = "1.3"

        // Satu APK saja, hanya arm64-v8a (HP 64-bit). HP 32-bit lama (armeabi-v7a) tidak lagi didukung.
        ndk { abiFilters += listOf("arm64-v8a") }
        externalNativeBuild {
            cmake {
                abiFilters("arm64-v8a")
                cppFlags += "-std=c++17"
            }
        }
    }

    externalNativeBuild {
        cmake {
            path = file("src/main/cpp/CMakeLists.txt")
            version = "3.22.1"
        }
    }

    sourceSets {
        getByName("main") {
            // ZtEngine memakai SDK lewat refleksi, jadi aplikasi selalu bisa dikompilasi; SDK + .so hanya ikut bila siap.
            if (ztReady) java.srcDir("zt-sdk/java")
        }
    }

    buildTypes {
        release { isMinifyEnabled = false }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    // Core libretro dimuat lewat path, jadi .so harus diekstrak ke nativeLibraryDir
    packaging { jniLibs { useLegacyPackaging = true } }
}

// Cek versi terbaru di https://jitpack.io/#Swordfish90/LibretroDroid
val libretroDroidVersion = "0.13.0"

dependencies {
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.6.2")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3")

    // Baca arsip .7z dan .rar (Java murni; .zip sudah bawaan Java)
    implementation("org.apache.commons:commons-compress:1.21")
    implementation("org.tukaani:xz:1.9")
    implementation("com.github.junrar:junrar:7.5.5")
    implementation(project(":libretrodroid"))   // LibretroDroid 0.13.2 + netplay rollback (lihat scripts/setup_libretrodroid_netplay.sh)

    // Terjemahan dialog: OCR + penerjemah on-device (ML Kit). Cek versi terbaru bila gagal resolve.
    implementation("com.google.mlkit:text-recognition:16.0.1")            // Latin
    implementation("com.google.mlkit:text-recognition-japanese:16.0.1")
    implementation("com.google.mlkit:text-recognition-chinese:16.0.1")
    implementation("com.google.mlkit:text-recognition-korean:16.0.1")
    implementation("com.google.mlkit:translate:17.0.3")
    implementation("com.google.mlkit:language-id:17.0.6")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-play-services:1.7.3")
}
