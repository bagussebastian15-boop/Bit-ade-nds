# Emulator All-in-One (Android 5.0+)

Frontend emulator berbasis **libretro** + [LibretroDroid](https://github.com/Swordfish90/LibretroDroid).
Sistem: GBA (mGBA), SNES (Snes9x), Sega Genesis/Mega Drive (Genesis Plus GX),
Nintendo DS (SeedlessDS), Arcade (MAME 2010 dan FBNeo). Gratis, tanpa iklan, ROM milik pengguna sendiri.

## v1.4: jaringan Bit©ade baru + Bit©ade 6

Network ID Bit©ade 1-5 diganti yang terbaru dan ditambah Bit©ade 6 (`ZtStore.DEFAULTS` dan `server/networks.json`):
Bit©ade `12ac4a1e7107ced0`, 2 `17d709436c129b81`, 3 `41d49af6c27f6314`, 4 `ebe7fbd445b2cf51`, 5 `9bee8941b59f9261`, 6 `b15644912e457810`.
Saat update dari versi lama, jaringan Bit©ade lama otomatis dibuang dari daftar dan status nyalanya dipindah ke nomor yang sama di jaringan baru (yang baru default mati).
Package sama (`com.allinone.emulator`), versionCode 29, jadi terpasang sebagai update tanpa menghapus data.

## Cara build

### Opsi A: GitHub Actions (tanpa install apa pun)
1. Push folder ini ke repo GitHub.
2. Tab **Actions** -> workflow **Build APK** jalan otomatis (atau *Run workflow*).
3. Unduh APK dari **Artifacts** (`EmulatorAllInOne-debug-apk`).

### Opsi B: Android Studio
1. Jalankan `bash scripts/fetch_cores.sh` (mengunduh core ke `app/src/main/jniLibs/`).
2. Buka folder ini di Android Studio -> Run.

## Fitur
| Fitur | Implementasi |
|---|---|
| Save/Load state | 5 slot + slot otomatis (disimpan saat pause/keluar); SRAM in-game disimpan terpisah |
| Controller map & plug n play | Deteksi gamepad otomatis, port pemain 1-4, pintasan tombol controller untuk perintah aplikasi (simpan/muat state, pengaturan, library, keluar), kontrol layar SELALU tampil, otomatis sembunyi hanya saat gamepad fisik terhubung (dan muncul lagi saat dicabut) |
| Upscaling & grafis | Skala layar penuh + filter pilihan: halus (bilinear, bawaan) atau tajam (Sharp) di Pengaturan → Performa & tampilan |
| API grafis | OpenGL ES 2.0+ (lihat catatan Vulkan) |
| Fast forward & frame skip | 2x/3x/4x/8x (ketuk tombol 2x cepat untuk ganti kecepatan); frame skip (mGBA) + lewati frame duplikat |
| Cheat | Per game, tambah/aktif/hapus; format kode mengikuti core |
| Terjemahan dialog | Tombol 🌐 (atau R3 di gamepad, atau menu game -> Terjemahkan layar): layar ditangkap, dibaca OCR, lalu diterjemahkan ke Bahasa Indonesia dan ditimpa di atas teks game. Lihat bagian "Terjemahan dialog" |
| Kontrol layar | Multi-touch; D-pad 8 arah (lurus + serong, geser jari tanpa mengangkat) atau stik analog (Pengaturan -> Kontrol arah di layar; stik juga menghasilkan arah digital untuk konsol 2D); untuk game Genesis/Mega Drive kontrol otomatis berubah menjadi pad 6 tombol asli (A B C bawah, X Y Z atas, MODE, START); semua tombol digambar 3D (tebal, bercahaya, turun saat ditekan); game SNES memakai latar bergambar logo Bit©ade (mengisi sisi kiri-kanan layar game saat main, tombol di atasnya; Genesis memakai versi abu-abu gelap, GBA versi ungu, tombol GBA abu-abu terang seperti Game Boy Advance ungu (indigo); pad Genesis berwarna seperti aslinya: X Y Z abu-abu, A B C hitam, START/MODE pil abu-abu) dan pad SNES asli (D-pad salib polos tanpa analog, belah ketupat X/Y/A/B, bahu L/R lebar, SELECT/START pil miring di tengah); tata letak bisa digeser/diubah ukurannya (menu game -> Atur tata letak kontrol), tersimpan terpisah potret/lanskap; transparansi dan getar bisa diatur |

## Nintendo DS (NDS)
- **SeedlessDS (core tertanam, disarankan, arm64 saja)**: core [SeedlessCoreDS](https://github.com/SapphireRhodonite/SeedlessDS-Core) (rev 1cae6f9, GPL-3.0-or-later;
  rekonstruksi dari DraStic r2.6.0.4a menurut pengembangnya) dikompilasi ke dalam APK lewat CMake/NDK (`seedless-core/`, glue JNI di `app/src/main/cpp/`).
  Bukan core libretro, jadi tidak lewat LibretroDroid: `SeedlessNdsActivity` + `SeedlessGlView` menyajikan dua layar (potret atas-bawah, lanskap kiri-kanan),
  sentuhan layar bawah, pad layar/gamepad, dan menu (Back = simpan/muat state slot 1, reset, keluar). Ketuk game NDS = SeedlessDS bila tersedia; tekan lama untuk
  Save/state disimpan di data internal aplikasi (`files/SeedlessDS`). **Belum di-build/diuji di perangkat.** Build butuh internet (CMake mengunduh libarchive/unarr/LZMA dengan cek SHA-256) dan NDK 25.2.
  **Pengaturan khusus SeedlessDS** (`SeedlessSettings` + `SeedlessSettingsMenu`): disimpan di SharedPreferences sendiri (`seedlessds_settings`), sepenuhnya
  terpisah dari `Settings` emulator lain, jadi mengubahnya tidak memengaruhi emulator lain. Dibuka dari Library (Atur > SeedlessDS (NDS)) atau dari
  menu jeda saat bermain (Back > Pengaturan SeedlessDS; game dijeda dan perubahan berlaku langsung). Isi: filter gambar (shader .dfx), susunan layar
  (otomatis/atas-bawah/kiri-kanan, tukar layar, regang), FPS, frame skip, thread emulasi, volume utama + penguatan suara, transparansi/getar kontrol,
  slot save state, nama pengguna dan bahasa firmware NDS, serta reset ke bawaan. Frame skip, thread, nama, dan bahasa berlaku saat game dimulai ulang.
  Resolusi 3D lebih tinggi sengaja belum ditawarkan: `SeedlessGlView` memakai tekstur layar tetap 256x192, jadi hires butuh penyajian yang berbeda.
  JIT hanya efektif di perangkat arm64 dan hanya bila build core dari buildbot memang menyertakannya (belum diverifikasi). State kedua core disimpan terpisah.
- File `.nds` (juga di dalam zip/7z/rar) otomatis masuk library. `scripts/fetch_cores.sh` mengunduhnya sebagai core **opsional**
  (dilewati bila tidak ada di buildbot untuk ABI itu; library akan menampilkan diagnosis "Core belum disertakan").
- **Layar sentuh**: satu jari yang mulai menyentuh di luar tombol bertindak sebagai stylus dan diteruskan ke core sebagai pointer
- **Tombol**: pad bentuk SNES (belah ketupat A/B/X/Y, L/R, Select/Start), tata letak tersimpan terpisah dari SNES, kombo NDS punya pengaturan sendiri.
- **Multiplayer**: BELUM tersedia untuk NDS. Multiplayer rollback bawaan hanya menyinkronkan tombol pad (bukan layar sentuh), membatasi save state 8 MB,
  dan multiplayer DS asli memakai Wi-Fi antar-konsol (dua konsol terpisah), bukan satu konsol dengan dua pad. NDS karena itu disembunyikan dari menu Multiplayer.
  dan LibretroDroid belum mengimplementasikan API itu.

## Terjemahan dialog
- **Jenis teks** (Pengaturan): dua mode terpisah. *Dialog* (bawaan) membaca balon/kotak dialog. *Menu awal game* membaca seluruh layar, tiap tulisan
  (Start, Option, Load, Save, dll.) diterjemahkan sendiri-sendiri dan ditimpa di tempatnya. Tulisan menu yang dikenal (kamus `MenuGlossary.kt`,
  Jepang dan Inggris, toleran salah baca OCR 1-2 huruf) langsung diberi padanan baku; sisanya lewat mesin terjemahan terpilih.
  Tambah padanan sendiri lewat `glosarium_ja.txt` (`jepang=padanan`). Pindah ke mode Dialog lagi bila sudah masuk ke permainan.
- **Mesin terjemahan** (Pengaturan): dua mode yang benar-benar terpisah, tanpa cadangan silang. *Online* punya dua pilihan: **Google Translate** (lebih akurat, wajib internet, teks dialog dikirim ke Google) atau **Groq** (terjemahan AI/LLM lewat api.groq.com; isi API key sendiri dari console.groq.com/keys di Pengaturan > Terjemahan, model bawaan `openai/gpt-oss-120b` dan bisa diganti); bila gagal muncul pesan galat. *Offline* (bawaan) = hanya ML Kit (tanpa internet setelah model diunduh sekali). Cache kedua mode juga terpisah.
- **Teks Jepang**: OCR dirapikan dulu (spasi di antara kana dibuang, 「」 diubah jadi tanda kutip, baris yang terpotong digabung) dan nama tokoh
  Doraemon/Shinchan diganti tulisan Latin (Nobita, Giant, Suneo, Shinnosuke, ...) agar tidak diterjemahkan jadi kata biasa. Tambah sendiri lewat file
  `glosarium_ja.txt` di folder data aplikasi (`jepang=padanan`, satu aturan per baris, `#` = komentar).
- **Koreksi baca Jepang** (`JaPrep.fixOcr`): NFKC (kana setengah lebar/angka lebar penuh), kanji mirip katakana (一→ー, 力→カ, 夕→タ, 口→ロ), へ/ヘ salah aksara, ツ→ッ pada seruan (ワッ, シッ), koma setelah seruan ッ, angka+penghitung → kanji (2人→二人), dan kamus kana→kanji untuk kata umum agar kalimat serba-hiragana tidak ngawur.
- **Cara pakai**: ketuk 🌐 di pojok kanan atas saat dialog tampil (atau R3 di gamepad, atau menu game -> Terjemahkan layar).
  Game dijeda dan terjemahan Indonesia **digambar langsung di atas teks asli** di layar game; tidak ada panel atau tombol tambahan di layar.
  Ketuk 🌐 lagi (atau tombol Kembali) untuk menutup dan melanjutkan game.
- **Teks asli / terjemahan**: saat terjemahan tampil, buka ☰ -> Pengaturan. Di bagian bawah daftar ada "Teks di layar: terjemahan/asli"
  (untuk bolak-balik) dan "Baca ulang terjemahan (mode teliti)" (coba semua varian gambar dan semua aksara). Pesan status berupa toast singkat.
- **Balon dialog gaya komik** (mis. Comix Zone): layar dicari dulu untuk balon putih berisi teks gelap; tiap balon dibaca OCR
  pada potongan kecil yang bersih (jauh lebih akurat daripada seluruh layar yang penuh gambar), lalu terjemahan menimpa isi balon.
  Huruf miring (italic) terdeteksi otomatis dan ikut ditiru. Bila tidak ada balon, dipakai pembacaan seluruh layar seperti biasa.
- **Meniru gaya game**: kotak latar memakai warna latar teks asli, teks memakai warna teks asli, ukuran mengikuti tinggi baris asli
  (mengecil otomatis bila terjemahan lebih panjang), outline dipasang bila game memakainya, huruf besar semua bila game memakainya,
  tebal bila goresan huruf tebal. Huruf terjemahan selalu memakai gaya piksel (huruf dirender kasar ala retro).
  Font asli game tidak bisa disalin persis; yang ditiru adalah warna, ukuran, outline, tebal, dan huruf besar/kecil.
- **Ukuran teks**: ukuran huruf terjemahan mengikuti tinggi huruf asli (huruf besar semua dihitung khusus). Di latar polos (mis. teks cerita di layar hitam)
  kotak penutup boleh melebar atau bertambah baris supaya huruf tidak perlu dikecilkan; di dalam balon dialog ukuran menyesuaikan isi balon.
- **Slang & idiom**: Inggris Amerika dan Britania (gonna, ain't, y'all, knackered, gutted, innit, bloody hell, piece of cake, dll.)
  diubah dulu ke Inggris baku sebelum diterjemahkan. Baris dialog yang berdekatan digabung jadi satu paragraf supaya konteks utuh.
  Teks HURUF BESAR semua diubah ke huruf biasa sebelum diterjemahkan (hasil lebih akurat). Nama pembicara seperti "CLOUD:" tidak diterjemahkan.
- **Kamus pribadi**: buat `slang_user.txt` di folder data aplikasi (Android/data/com.allinone.emulator/files/), satu aturan per baris:
  `slang=padanan baku`, mis. `gonna=going to` atau `the wyrm=the dragon`. Aturan pribadi didahulukan; baris berawalan `#` diabaikan.
- **Mesin**: ML Kit on-device (OCR Latin/Jepang/Mandarin/Korea, deteksi bahasa, terjemahan ke Indonesia).
  Model terjemahan (±30 MB per bahasa) diunduh sekali saat pertama dipakai (butuh internet), setelah itu offline.
- **Font retro/buram**: gambar dinormalkan lalu dibuat 5 varian (warna asli, abu-abu + kontras, dipertajam, dibalik, hitam-putih Otsu);
  hasil OCR dengan skor kepercayaan tertinggi yang dipakai.
- **Pengaturan**: Bahasa teks game, Area baca (seluruh layar / 45% bawah), Gaya huruf.
- **Batas**: butuh Android 7.0+ (PixelCopy); latar bergambar/gradasi membuat kotak penutup terlihat sebagai tambalan;
  terjemahan on-device bukan LLM, jadi slang di luar kamus bisa tetap salah; font dekoratif sangat kecil bisa salah baca.

## Catatan jujur (perlu dicek)
- Fitur terjemahan juga **belum di-build/diuji**. Versi dependensi ML Kit ada di `app/build.gradle.kts`; sesuaikan bila gagal resolve.
- **Belum di-build/diuji** di lingkungan pembuatan (tanpa Android SDK/jaringan). Jika ada error kompilasi,
  hampir pasti di nama API LibretroDroid yang berubah antarversi: ubah `libretroDroidVersion`
  di `app/build.gradle.kts` (lihat jitpack.io/#Swordfish90/LibretroDroid) dan sesuaikan
  `EmulatorActivity.kt` / `Settings.kt` (`ShaderConfig`, `setCheat`, `getGLRetroEvents`).
- **Vulkan** belum disertakan: hanya OpenGL ES. Perlu versi LibretroDroid yang mendukung Vulkan.
- **Upscaling**: core 2D punya resolusi internal tetap, jadi "upscale" = skala + shader, bukan render ulang.
- **Filter**: halus (bilinear, default LibretroDroid) atau tajam (`ShaderConfig.Sharp`), dipilih di Pengaturan; berlaku saat game dimulai.
- **Frame skip** per core: baru mGBA (`mgba_frameskip`). Core lain bisa ditambah di `EmulatorActivity.onCreate`.
- **Arcade** punya dua core: ketuk game = MAME 2010 (set ROM MAME 0.139); **tekan lama** game arcade di library = pilih **FBNeo** atau **MAME 2010**.
  FBNeo memakai file zip yang sama di library, tapi set ROM-nya harus cocok dengan FBNeo (berbeda dari set MAME 0.139). Save state dan SRAM FBNeo disimpan terpisah dari MAME (file MAME 2010 memakai akhiran `.mame2010`).
  Catatan: core MAME 2010 tidak mendukung save state/SRAM libretro dan tidak punya opsi kecepatan CPU; set ROM harus format `.zip`.
  Opsi performa FBNeo (frameskip tetap, kecepatan CPU) belum diuji di perangkat.
  Nama file zip harus sama dengan nama driver MAME (mis. `sfa2.zip`); clone butuh zip induk di library yang sama. Bila game gagal dibuka, aplikasi menampilkan dialog penyebabnya.
  Semua file .zip arcade otomatis dijalankan dengan core ini. BIOS (mis. `neogeo.zip`) diimpor sebagai file zip biasa ke folder yang sama (letakkan di folder ROM yang sama supaya ikut terimpor).
  **BIOS bawaan**: zip di `app/src/main/assets/bios/` (aleck64, aristmk5/6, atarisy1, 3dobios, cdibios, cd32bios, chihiro, airlbios, psx (acpsx/atpsx/atluspsx), dll.) otomatis disalin ke folder ROM arcade saat library dibuka dan disembunyikan dari daftar game. Tambah BIOS lain dengan menaruh zip-nya di folder itu.
  **Core arcade tambahan** (tekan lama game): FBNeo, FB Alpha 2012, MAME 2000 (0.37b5), MAME 2003 (0.78), MAME 2003-Plus (0.78+). Tiap core butuh set ROM versinya sendiri; zip yang sama di folder arcade dipakai semua core. `scripts/fetch_cores.sh` mengunduh core tambahan sebagai opsional (dilewati bila tidak ada di buildbot). Save/state tiap core dipisah lewat akhiran nama file.
- **Lisensi core**: Snes9x, Genesis Plus GX, MAME 2010 berlisensi non-komersial; aplikasi ini
  hanya boleh dibagikan gratis. Cek lisensi masing-masing core sebelum merilis.

## Tombol kombo arcade (v0.4.5)
- Panel arcade punya 2 tombol kombo biru (kapsul) di atas deretan tombol 4 5 6. Satu sentuhan = beberapa tombol aksi ditekan **serentak**
  (bawaan: `4+5+6` tiga pukulan, `1+2+3` tiga tendangan, mengikuti susunan panel Capcom).
- Atur lewat ☰ -> Pengaturan: **Tombol kombo arcade** (aktif/mati), **Isi kombo 1** dan **Isi kombo 2** (centang tombol 1-6; tanpa centang = tombol disembunyikan).
  Perubahan langsung berlaku tanpa memulai ulang game.
- Posisi dan ukuran bisa diubah di menu game -> Atur tata letak kontrol (seret = pindah, ketuk = sembunyikan/tampilkan), tersimpan bersama tata letak arcade.
- Tombol asli yang ikut ditekan kombo ikut tampak tertekan; bila jari lain juga menahan tombol yang sama, tombol itu baru lepas setelah keduanya dilepas.
- **SNES**: pad SNES juga punya 2 tombol kombo (bawaan `A+B` dan `X+Y`), bertumpuk di kiri belah ketupat ABXY. Pengaturannya terpisah dari arcade:
  Tombol kombo SNES, Isi kombo SNES 1/2 (centang A B X Y L R).
- Hanya berlaku di layar sentuh arcade dan SNES. Belum di-build/diuji di perangkat.

## Pemetaan tombol controller eksternal & kombo
- Dari dalam game: ☰ -> Pengaturan -> **Pemetaan tombol controller: <sistem>** langsung membuka layar tombol sistem yang sedang dimainkan. Dari library (menu **Atur**) pilih sistem dulu (GBA, SNES, Genesis, Arcade; arcade MAME dan FBNeo berbagi pemetaan).
- Layar pemetaan menampilkan **semua tombol game** sistem itu (GBA: A, B, L, R, Select, Start, ↑ ↓ ← →; SNES/Genesis/Arcade sesuai tata letaknya) beserta tombol controller yang sekarang terpasang.
- **Ketuk satu tombol game** (jadi hijau), lalu **tekan tombol di controller eksternal**: langsung terpasang dan layar tetap terbuka untuk tombol berikutnya. **Tahan lama** satu tombol game = kembali ke bawaan; **Reset semua** mengembalikan seluruh sistem.
- Kombo (beberapa tombol game sekaligus): tombol **Kombo / lanjutan** -> **+ Tambah pemetaan**, tekan tombol controller, centang beberapa tombol game tujuan. Ketuk pemetaan yang ada untuk mengubah/menghapus.
- Tombol fisik yang dipetakan tidak lagi dikirim apa adanya; tombol yang tidak dipetakan tetap diteruskan seperti biasa. Pintasan aplikasi (simpan/muat state dst.) didahulukan, jadi tombol pintasan tidak bisa dipetakan.
- Tombol game yang ditahan oleh dua tombol fisik baru dilepas setelah keduanya dilepas. Perubahan langsung berlaku tanpa memulai ulang game.
- Batas: D-pad controller yang dilaporkan sebagai sumbu (hat) bukan tombol sehingga tidak bisa dipetakan ulang (tombol arah tetap bisa jadi tujuan kombo). Belum di-build/diuji di perangkat.

## Impor game dari folder
- Library -> **Impor folder** -> pilih folder berisi ROM. Semua file ROM di dalamnya, termasuk subfolder, disalin ke folder app sesuai ekstensinya
  (.gba, .sfc/.smc/.fig/.swc, .md/.gen/.smd/.bin, .zip = arcade). File dengan ekstensi lain diabaikan.
- File yang sudah ada dengan ukuran sama dilewati, jadi mengimpor ulang folder yang sama cepat. Hasil ditampilkan: berapa diimpor, sudah ada, gagal.
- Semua file .zip di folder (termasuk zip lain di luar ROM) ikut diimpor sebagai arcade, dan semua .bin sebagai Genesis. Pisahkan ROM dari file lain bila perlu.
- Android 11+ melarang memilih folder induk penyimpanan, Download, atau Android/data lewat pemilih folder; pilih sebuah subfolder (mis. buat folder `ROM`). Belum di-build/diuji di perangkat.

## Struktur
```
app/src/main/java/com/allinone/emulator/
  data/   Console, Paths, RomLibrary, Settings, CheatStore
  input/  KeyMap, VirtualPadView
  ui/     LibraryActivity, EmulatorActivity, Menus
scripts/fetch_cores.sh        unduh core libretro
.github/workflows/build.yml   build APK otomatis
```

## Perbaikan terjemahan (terbaru)
- **Sisa teks asli mengintip di tepi**: kotak penutup kini diperluas otomatis sampai ujung tinta teks asli (`StyleAnalyzer.grow`) dan bantalannya diperlebar.
- **Hasil acak/rusak** (mis. "Og 'h oriohm ¿nox monn!"): ada penyaring `TextQuality` untuk hasil OCR dan hasil terjemahan. Teks acak tidak lagi ditimpa; OCR otomatis mencoba varian gambar lain.
- **Terjemahan terpotong**: (1) OCR tidak lagi berhenti pada bacaan setengah jadi, balon dicek apakah semua tinta teks sudah terbaca; (2) terjemahan dilakukan per kalimat, "..." dipisah dulu, dan hasil yang terlalu pendek diulang per klausa; (3) teks di balon dialog mengecil sampai 65% agar muat utuh di dalam balon.
- **Tanda seru italic terbaca "/"**: "RELAX/ LET'S" kini dibetulkan jadi "RELAX! LET'S".

## Performa arcade (v0.4.2): kenapa pengaturan dulu tidak berdampak
Diperiksa langsung terhadap source core dan LibretroDroid 0.13.0:
- **Frameskip otomatis tidak pernah aktif.** Mode "Auto/Manual" FBNeo dan "automatic" MAME 2010 butuh frontend yang menjawab
  `RETRO_ENVIRONMENT_SET_AUDIO_BUFFER_STATUS_CALLBACK`; LibretroDroid tidak mengimplementasikannya. Sekarang hanya frameskip **tetap** yang dipakai.
- **Kecepatan CPU arcade** (bawaan 200%) dikirim ke semua core arcade yang punya opsinya (FBNeo, MAME 2003-Plus); MAME 2010 (`mame_current_*`) dan core lama tidak punya opsi ini sehingga mengabaikannya.
- Profil sekarang 4 tingkat (Standar, Seimbang, Ringan, Maksimal) dan berlaku **langsung** saat game berjalan (kecuali kecepatan CPU).
- Frameskip hanya menghemat proses menggambar sprite; beban CPU emulasi tidak berkurang.
- Belum di-build/diuji di perangkat.

## v0.4.4: layar 60 Hz
Hasil diagnostik (penghitung FPS): FBNeo 57 FPS stabil di layar 90 Hz, jadi core tidak kewalahan. LibretroDroid hanya memakai vsync bila
refresh rate layar dalam ±5 Hz dari game; di 90/120 Hz ia memakai pengatur waktu sendiri sehingga frame tampil dengan durasi tak rata (patah-patah).
Sekarang layar dikunci ke mode 60 Hz sebelum core dimulai (Pengaturan -> "Kunci layar 60 Hz"). Cek angka "Hz" di penghitung FPS: harus 60.

## Tata letak & ukuran kontrol bawaan (lanskap)

Posisi dan ukuran kontrol layar bawaan tiap emulator diambil dari tata letak yang sudah diatur pengguna
(`VirtualPadView.applyLandscapeDefaults`). Posisi disimpan sebagai pecahan lebar/tinggi layar, jadi tampilannya sama di
ukuran layar berbeda.

| Emulator | Ukuran tombol | Ukuran D-pad/stik |
|----------|---------------|-------------------|
| Genesis  | 70%           | 70%               |
| SNES     | 60%           | 60%               |
| GBA      | 70%           | 60%               |
| Arcade   | 80%           | 70%               |

Potret tidak berubah. Tata letak yang sudah pernah disimpan tetap dipakai; tombol **Reset** di mode Atur tata letak
mengembalikan ke bawaan ini.

## Terjemahan di layar penuh (controller eksternal)
- Saat gamepad terhubung dan gambar game memenuhi seluruh layar, menekan Terjemahkan **tidak lagi memperkecil gambar**. Lapisan terjemahan memakai skala, titik pusat, dan geseran yang sama dengan view game, sehingga teks terjemahan tetap pas di atas teks aslinya. Belum di-build/diuji di perangkat.

## Menu pengaturan berkategori
Pengaturan kini dikelompokkan: **Performa & tampilan**, **Arcade** (hanya saat main arcade), **Audio**, **Kontrol di layar**,
**Controller eksternal**, dan **Terjemahan**. Layar utama menampilkan tiap kategori dengan ringkasan nilai saat ini; ketuk untuk
membuka daftar isinya. Audio punya pilihan **Mode audio** (stabil / latensi rendah). Belum di-build/diuji di perangkat.

## Perbaikan terjemahan pecah/tumpang tindih
Satu kotak dialog kini digabung jadi satu terjemahan (jarak baris renggang dan teks rata tengah tidak lagi memecahnya),
dan bila dua terjemahan masih bertumpuk, yang bawah digeser agar tetap terbaca. Belum diuji di perangkat.

## Kotak dialog gelap (mis. Super Mario World)
`BubbleFinder` kini juga mendeteksi kotak dialog hitam/gelap berisi teks terang, dibaca dan diterjemahkan SEBAGAI SATU BLOK
(HUD seperti "TIME" tidak ikut diterjemahkan). Potongan kecil yang berada di dalam blok lain digabung/disembunyikan,
dan kata tunggal tidak lagi dipenggal per huruf. Belum diuji di perangkat.

## Deteksi kotak dialog untuk semua game
`BubbleFinder` tidak lagi khusus hitam/putih: ia mencari kotak solid berwarna APA PUN (hitam, biru RPG, putih, krem, dll.),
termasuk kotak lebar di bawah layar yang menempel ke tepi. Satu kotak = satu blok terjemahan. Dialog tanpa kotak solid
(teks di atas gambar/transparan) memakai jalur cadangan: baris teks dikelompokkan dan digabung per paragraf.

## Hanya teks di dalam kotak dialog
Bila ada kotak dialog, hanya kotak berisi kalimat yang diterjemahkan; teks di luar kotak (HUD, label, angka) diabaikan.
Hanya bila TIDAK ada kotak dialog terdeteksi, aplikasi membaca seluruh layar (atau 45% bagian bawah).

## Ukuran huruf terjemahan
Pengaturan > Terjemahan: **huruf minimal** (8-20 dp, bawaan 10) dan **huruf maksimal** (16-48 dp, bawaan 28). Terjemahan tidak akan
lebih kecil dari minimal (tetap terbaca) dan tidak lebih besar dari maksimal. Keduanya otomatis saling menyesuaikan.

## Tata letak terjemahan mengikuti kotak dialog asli
- Kotak terjemahan kini **menumpuk persis di atas kotak dialog asli** (kiri, atas, lebar, tinggi sama) dan posisinya dikunci (tidak digeser).
- **Ukuran huruf** mengikuti tinggi huruf asli game (besar tetap besar, kecil tetap kecil). Bila terjemahan tidak muat, huruf dikecilkan seperlunya (sampai batas terbaca), lalu lebar baris dilonggarkan ke lebar kotak, lalu jarak baris dirapatkan, supaya terjemahan tampil lengkap tanpa terpotong.
- **Jarak antar baris** diukur dari baris asli hasil OCR lalu ditiru; margin dan lebar baris sama dengan area teks asli.
- Untuk kotak dialog, batas ukuran huruf di Pengaturan (min/maks dp) tidak dipakai agar ukuran tetap sama dengan game. Belum di-build/diuji di perangkat.

## Terjemahan kecil: kotak diperbesar sedikit
- Huruf terjemahan tidak lagi dikecilkan di bawah batas terbaca (sekitar 60% ukuran asli, minimal 8 px bitmap); di bawah itu font piksel tampil rusak/acak.
- Bila pada batas terbaca terjemahan masih tidak muat, kotak terjemahan diperbesar bertahap (+8%, +16%, +25%, maks. +35%) dari titik tengah kotak asli dan tetap di dalam layar game, sampai terjemahan jelas dan lengkap. Kotak asli tetap tertutup penuh. Berlaku untuk semua game. Belum di-build/diuji di perangkat.

## Kalimat berjarak jauh dan huruf miring
- **Spasi jarak jauh:** (1) segmen teks yang sebaris tetapi dipisah spasi lebar (sampai ~4,5x tinggi huruf) digabung jadi satu baris urut kiri-kanan; (2) baris yang rata kiri/tengah dengan jarak vertikal sampai ~3,5x tinggi huruf (sebelumnya 1,8x) tetap satu paragraf/satu kalimat; (3) jangkauan penggabungan paragraf berdekatan diperluas 1,5x. Di kotak dialog, semua baris di dalam kotak sudah otomatis satu terjemahan.
- **Huruf miring:** dua varian gambar OCR baru (VARIANT_COUNT = 7) yang meluruskan huruf miring ke kanan (shear 0,25 dan 0,45), lalu kotak hasil OCR dipetakan balik ke koordinat asli. Varian ini dicoba otomatis bila varian biasa belum cukup baik (selalu dicoba di mode teliti). Huruf miring ke kiri belum didukung. Belum di-build/diuji di perangkat.

## Toleransi spasi diperlebar lagi
Segmen sebaris digabung sampai ~8x tinggi huruf (sebelumnya 4,5x); baris sejajar sampai ~6x (sebelumnya 3,5x), baris tidak sejajar 2,5x (sebelumnya 1,8x); jangkauan gabung paragraf 2,5x. Belum di-build/diuji di perangkat.

## Ukuran huruf terjemahan maksimal 16 dp
Batas maksimal bawaan kini 16 dp (kunci pengaturan baru, jadi berlaku juga untuk pengguna lama; bisa diubah di Pengaturan -> Terjemahan) dan juga berlaku di kotak dialog. Font piksel hanya tampil rapi pada kelipatan 8 px bitmap, jadi ukuran akhir dibulatkan ke bawah dan bisa sedikit di bawah 16 dp. Belum di-build/diuji di perangkat.

## RPG Jepang gaya SNES (Tales of Phantasia, dll.): nama tokoh + dialog 「…」 di kotak biru gradasi
Masalah: terjemahan hanya menimpa baris nama ("クレスの父ミゲール" -> "Ayah Cress, Miguel"), sedangkan isi dialog di bawahnya tetap Jepang.
Penyebab dan perbaikan:
- **Kotak tidak terdeteksi.** `BubbleFinder` hanya mengenali kotak SATU warna; latar biru tua -> biru muda (gradasi) gagal uji "kotak penuh" (isi 38% < 55%),
  sehingga yang terbaca malah area gelap di lantai. Kini ada penelusuran ke-3 (`scanSmooth`): piksel bertetangga yang warnanya berubah pelan dihubungkan,
  jadi gradasi tetap satu kotak. Teks = piksel yang jauh berbeda dari warna latar BARIS yang sama. Diuji pada tangkapan layar: kotak ditemukan
  persis di dalam bingkai krem (tepi kiri-kanan tidak memotong huruf).
- **Nama tokoh dipisah dari dialog** (`splitSpeakerCjk`): baris pertama pendek tanpa tanda baca + baris berikutnya diawali 「 / 『 = nama.
  Nama diterjemahkan sendiri, lalu digabung dengan dialog memakai titik dua: `Nama: dialog`.
- **Latar kotak ditiru per baris** (`StyleAnalyzer.gradient` + gradasi vertikal di `TranslationOverlayView`): kotak terjemahan tidak lagi tampak sebagai tambalan biru rata.
- **Kotak di atas layar**: bila "Area baca = 45% bawah" tidak menemukan teks, seluruh layar dibaca ulang otomatis.
- **Mode Otomatis**: pengenal Jepang dicoba dulu (2 varian); hasil pengenal Jepang/Mandarin/Korea yang tidak memuat huruf CJK dibuang supaya teks Inggris tidak salah digabung tanpa spasi.
  Untuk game Jepang tetap disarankan Pengaturan -> Bahasa teks game = Jepang (lebih cepat).
- Nama tokoh Tales of Phantasia (クレス, ミント, チェスター, アーチェ, クラース, ダオス, ミゲール, ...) ditambahkan ke `JaPrep` agar tidak diterjemahkan jadi kata biasa
  (ミント = "mint"); tambah nama lain lewat `glosarium_ja.txt`.
- Belum di-build/diuji di perangkat: yang diuji di luar perangkat hanya deteksi kotak, pengambilan gradasi, dan pemisahan nama (dikompilasi dengan stub Android).
  Kualitas OCR ML Kit pada font piksel tidak bisa diuji di sini.

## Perbaikan terjemahan Jepang (font piksel) - berlaku umum, bukan per-game
- **Potret tokoh tidak lagi tertimpa**: BubbleFinder memakai tepi kiri/kanan paling dalam pada kotak persegi, jadi potret yang menjorok ke kotak dialog tidak ikut terbaca OCR dan tidak ditutup latar terjemahan.
- **Sampah OCR dibuang**: huruf Latin/angka yang "dikarang" pengenal Jepang (mis. `h.1 Sup tass`) dihapus dan mengurangi skor bacaan.
- **Varian gambar baru** (dihaluskan) untuk font piksel.
- **Pemilihan bacaan lewat terjemahan** (mesin Online): bila varian gambar memberi beberapa bacaan berbeda, semuanya diterjemahkan dan dipakai yang hasilnya paling wajar. Bila tidak ada dua bacaan sama panjang, dipakai bacaan paling "di tengah" (jarak edit terkecil).
- Warna teks terjemahan mengikuti kecerahan rata-rata gradasi kotak dialog.
- Opsional: `memori_ja.txt` di folder data aplikasi (`jepang=indonesia`) untuk koreksi kalimat tertentu; kosong secara bawaan.
- **Belum di-build/diuji di perangkat.** Akurasi OCR font piksel tetap bergantung pada ML Kit.

## Pembacaan yang lebih jelas untuk ML Kit
- **Tunggu teks selesai muncul**: tangkapan layar diulang tiap 120 ms sampai 40% bagian bawah tidak berubah (maks. 8x), jadi dialog yang muncul huruf demi huruf tidak terbaca setengah.
- **Kembali ke piksel asli game** (GBA 240x160, SNES 256x224, Genesis 320x224): tepi huruf yang dilembutkan filter layar ditegaskan lagi sebelum OCR. Hanya dipakai bila blok piksel cocok dengan gambar; bila tidak, gambar asli dipakai. Status tampil di diagnosis ("piksel-asli: ya/tidak").
- **Baca ulang per baris** (teks Jepang): tiap baris dipotong, diperbesar, diberi margin putih, lalu dibaca lagi.
- Belum diuji di perangkat.

## Tabel font yang belajar sendiri (GlyphBank)
- Tiap huruf pada baris dialog Jepang dipotong sendiri (jumlah potongan dicocokkan dengan jumlah huruf hasil OCR), bentuknya dicatat bersama huruf yang dibaca ML Kit. Bentuk yang sudah >= 4 kali terlihat dan >= 75% dibaca sama dikenali langsung, dan bacaan ML Kit yang menyimpang dikoreksi.
- Disimpan di `font_bank.txt` (folder data aplikasi); hapus file itu untuk mengulang. Status tampil di diagnosis ("tabel font: ...").
- Baris yang jumlah hurufnya tidak cocok dengan potongan gambar, atau berisi karakter selain kana/kanji/ー、。！？, dilewati agar tabel tidak tercemar.
- Belum ada layar koreksi manual. Belum diuji di perangkat.

## Ganti core MAME 2003-Plus -> MAME 2010
- Core arcade bawaan kini `mame2010_libretro_android.so` (jalankan ulang `scripts/fetch_cores.sh`; hapus `libmame2003_plus_*` lama di `jniLibs`).
- Set ROM berubah dari 0.78 ke **0.139**. Opsi memakai kunci `mame_current_frame_skip`, `mame_current_sample_rate`, `mame_current_skip_*`.
- Save state lama MAME 2003-Plus tidak terpakai (format beda); file baru memakai akhiran `.mame2010`.

## FBNeo terbaru
- `scripts/fetch_cores.sh` selalu mengunduh ulang core **fbneo** dari buildbot nightly (`REFRESH="fbneo mame2010"` untuk menyegarkan core lain).
- Nama opsi FBNeo yang dipakai (`fbneo-frameskip-type`, `fbneo-fixed-frameskip`, `fbneo-cpu-speed-adjust`) sudah dicocokkan dengan dokumentasi build FBNeo terbaru. Set ROM harus cocok dengan versi FBNeo terbaru.

## Hapus game = hapus juga di file manager
- Tekan lama game di library -> **Hapus file saja** atau **Hapus + save & state**. Keduanya kini menghapus file game di library
  **dan berkas aslinya di folder yang tadi diimpor** (lewat Storage Access Framework, `DocumentsContract.deleteDocument`).
  Save, state, dan cheat (folder app: `Android/data/<paket>/files`) juga terhapus dari penyimpanan, dan file manager diminta menyegarkan.
- Tautan game -> berkas asli disimpan di `source_links.tsv` (`data/SourceLinks.kt`) saat **Impor folder**. Game yang diimpor sebelum versi ini
  belum punya tautan: impor ulang foldernya sekali (file yang sudah ada otomatis ditautkan) agar berkas aslinya ikut terhapus.
- Izin tulis folder diminta/dipertahankan saat memilih folder impor. Bila izin dicabut atau berkas sudah dihapus lebih dulu, game tetap terhapus dari library.
- Arsip berisi banyak ROM tidak ditautkan, supaya menghapus satu game tidak menghapus arsip yang dipakai game lain.

## Perbaikan build: "Could not resolve com.github.junrar:junrar" (Read timed out)
- Penyebab: Gradle menanyakan setiap dependensi ke Google Maven (dl.google.com) lebih dulu; junrar sebenarnya ada di Maven Central, tetapi timeout di Google menggagalkan build.
- `settings.gradle.kts`: Google Maven kini dibatasi ke grup `com.android*`, `com.google*`, `androidx*`; JitPack hanya untuk `com.github.Swordfish90`.
- `gradle.properties`: timeout koneksi/baca 180 detik dan ulang otomatis hingga 6 kali.

## "Core Arcade (MAME 2010) belum disertakan"
- Artinya `libmame2010_libretro_android.so` tidak ada di APK: langkah "Unduh core libretro" di workflow masih mengunduh daftar core lama (`mame2003_plus`).
- `.github/workflows/build.yml` yang baru mengunduh core langsung di workflow (mandiri, tidak butuh folder scripts/ di repo), memeriksa bahwa `mame2010` dan `fbneo` benar-benar terunduh sebelum build, dan memakai `retention-days: 1` agar kuota artifact tidak penuh.

## Workflow: proyek di subfolder
- Error "Directory ... does not contain a Gradle build" = `settings.gradle.kts` tidak ada di root repo. Workflow kini mencari sendiri folder proyek
  (`PROJECT_DIR`) dan menjalankan unduh core, pemeriksaan, build, dan upload APK di folder itu.

## Repo berisi zip (bukan file terpisah)
- Bila repo hanya berisi `EmulatorAllInOne.zip` + `README.md`, workflow mengekstrak zip itu ke `_project` lalu membangunnya.
  Zip dengan nama berisi `mame2010` diutamakan. PENTING: `EmulatorAllInOne.zip` lama masih berisi kode MAME 2003-Plus; upload
  `EmulatorAllInOne-mame2010.zip` (atau ekstrak isinya langsung ke root repo) agar build memakai MAME 2010.

## Game MAME 2010 langsung kembali ke library
- Penyebab umum: core MAME 2010 menutup proses sendiri atau crash native bila set ROM tidak cocok (butuh MAME 0.139) atau zip induk/BIOS tidak ada.
  Karena prosesnya mati, tidak ada dialog error biasa.
- Library kini menampilkan dialog "Game tadi menutup aplikasi" (Android 11+) berisi penyebab (crash native / exit() / dll), status, dan jejak crash;
  laporan juga disimpan di `crash_report.txt` (folder data aplikasi).
- Tes cepat: tekan lama game -> **FBNeo**. Bila jalan di FBNeo tapi tidak di MAME 2010, set ROM bukan 0.139.

## Multiplayer rollback (gaya GGPO)
- Menu game -> **Multiplayer (rollback)**. Satu HP **Host** (pemain 1), HP lain **Gabung** dengan mengetik IP host (port 7755 TCP+UDP). Kedua HP wajib memakai ROM dan core yang sama (dicek lewat CRC ROM).
- Cara kerja: tiap frame state disimpan, input lawan ditebak (ulang input terakhir); saat input asli datang dan beda, game kembali ke frame itu lalu disimulasi ulang tanpa gambar/suara. Input delay 1-4 frame dipilih host. State awal host dikirim ke tamu lewat TCP, input lewat UDP (redundan, tahan packet hilang).
- Cocok untuk: SNES (Snes9x), Genesis (Genesis Plus GX), GBA (mGBA), FBNeo. MAME 2003/2010 kurang cocok (state besar/tidak deterministik). Hanya tombol digital (analog/pointer tidak dipakai saat netplay).
- Saat netplay berjalan: simpan/muat state, cheat, reset, dan fast forward dimatikan. Bila koneksi putus, game dilanjutkan sendiri dari posisi terakhir.
- Jaringan: LAN / hotspot / VPN (Tailscale, ZeroTier) langsung bekerja. Lewat internet biasa host perlu membuka port 7755 (TCP+UDP); belum ada server relay/NAT traversal.
- Build: `bash scripts/setup_libretrodroid_netplay.sh` (otomatis di GitHub Actions) mengunduh LibretroDroid 0.13.2 + submodule lalu menimpa dengan patch di `libretrodroid-netplay/overlay/`.
- Uji logika rollback di komputer: `bash tests/run_netplay_test.sh`.


## Multiplayer Online (daftar server / lobby)
- Menu awal (library) -> tombol **Multiplayer Online**. Layar ini menampilkan **Server resmi** (buatan Anda) dan **Server pemain** (dibuat pemain), lalu ketuk server -> **Gabung**. Pemain bisa **Buat server**: pilih game, beri nama, game langsung jalan sebagai host dan server tampil di daftar.
- Daftar hanya berisi ALAMAT. Game tetap peer-to-peer (netplay rollback di atas): host = pemain 1, tamu = pemain 2, 2 pemain per server. Tamu wajib punya game yang sama persis di library (dicocokkan dari nama file + konsol, lalu dicek CRC ROM saat tersambung).
- Server lobby: `server/lobby_server.py` (Python 3, tanpa pustaka tambahan): `PORT=8080 python3 server/lobby_server.py`. Isi alamatnya di `LobbyApi.DEFAULT_URL` (data/LobbyApi.kt) sebelum build, atau pemain mengisinya lewat tombol **Atur**.
- Server resmi diatur di `server/official_servers.json` (tanpa build ulang aplikasi). Tiap entri menunjuk ke HP/PC/VPN yang menjalankan game sebagai host (host, port, title, console). Lobby mengecek TCP ke entri beralamat publik dan menandai **offline** bila tidak terjangkau.
- Server pemain: alamat publik host dibaca lobby dari sambungan HTTP, lalu lobby mengecek port TCP host terbuka dari internet; bila tidak, server tidak didaftarkan (game tetap berjalan, pemain bisa gabung lewat IP). Untuk jaringan LAN/VPN isi **IP VPN/LAN** manual (hanya alamat private/100.64.x.x yang diterima). Server hilang otomatis bila host berhenti mengirim heartbeat (45 dtk).
- Belum ada relay/NAT traversal: host lewat internet biasa tetap harus membuka port 7755 (TCP+UDP) atau memakai VPN (ZeroTier/Tailscale).
- Manifest memakai `usesCleartextTraffic=true` agar lobby `http://IP:port` bisa dipakai; bila lobby Anda sudah HTTPS, hapus atribut itu.

### Penanda ZeroTier di daftar lobby
- Tiap server di daftar punya field `net`: `zerotier`, `tailscale`, `lan`, atau `internet`; aplikasi menampilkannya sebagai `[ZeroTier]` / `[Tailscale]` di samping nama server.
- Penentuan: (1) pilihan eksplisit pemain (Pengaturan -> Multiplayer Online -> Jenis VPN, atau pilihan VPN di form Buat server) dipakai untuk IP non-publik; (2) bila otomatis, lobby mencocokkan IP dengan `ZEROTIER_NETS`; 100.64.0.0/10 = Tailscale; alamat private lain = LAN.
- Rentang ZeroTier tidak tetap (tiap jaringan memilih sendiri). Isi rentang jaringan Anda yang sebenarnya: `ZEROTIER_NETS=10.147.17.0/24,192.168.191.0/24 python3 server/lobby_server.py`. Bawaan hanya rentang yang umum dipakai ZeroTier Central.
- Entri `official_servers.json` boleh memakai `"zerotier": true` atau `"net": "tailscale"`.
- Pengaturan baru di Pengaturan -> **Multiplayer Online**: alamat lobby, nama pemain, IP VPN/LAN saya, jenis VPN (terisi otomatis di form Buat server).
- Uji: `python3 tests/lobby_server_test.py` (otomatis juga dijalankan di GitHub Actions bersama uji netplay). Sisi Kotlin belum di-build/diuji di perangkat.

### Jaringan ZeroTier milik pemilik + persetujuan masuk
- Jaringan Anda didaftarkan di `server/networks.json` (id 16 karakter + nama). Aplikasi menampilkannya di bagian **Jaringan ZeroTier** pada layar Multiplayer Online (tanpa build ulang aplikasi).
- Pemain: isi **Node ID** ZeroTier One miliknya (Atur -> Multiplayer Online), ketuk jaringan -> **Minta akses**. **Cek status** menunjukkan pending/disetujui/ditolak. Tombol Lainnya: salin Network ID, buka ZeroTier One.
- Pemilik: jalankan lobby dengan `ADMIN_KEY=rahasia`, isi kunci yang sama di Atur -> Multiplayer Online -> Kunci admin. Tombol **Persetujuan** muncul di layar lobby: ketuk permintaan -> Setujui/Tolak.
- Setelah **Setujui**, centang **Auth** untuk node itu di my.zerotier.com (otorisasi otomatis lewat API Central belum dibuat). Tanpa ADMIN_KEY, fitur persetujuan mati.
- Permintaan disimpan di `server/requests.json` (dihapus otomatis setelah 30 hari bila tak diputuskan). Maks. 5 permintaan menunggu per alamat.
- Lobby harus bisa dijangkau pemain: jalankan `python3 server/lobby_server.py` di PC/VPS (bila di PC yang sudah masuk jaringan Bit©ade, alamatnya `http://<IP-ZeroTier-PC>:8080`), lalu isi alamat itu di Atur -> Alamat lobby atau `LobbyApi.DEFAULT_URL`.

### Node ID ZeroTier otomatis dari ZeroTier One
- Android melarang aplikasi membaca data aplikasi lain, dan ZeroTier One tidak punya API untuk itu, jadi Node ID tidak bisa dibaca diam-diam. Alurnya: **Ambil dari ZeroTier One** (di Atur, atau otomatis saat Minta akses tanpa Node ID) membuka ZeroTier One -> pemain mengetuk Node ID di bagian bawah (tersalin ke clipboard; cek di perangkat bahwa versi ZeroTier One Anda menyalinnya) -> kembali ke aplikasi -> aplikasi membaca clipboard, memvalidasi 10 karakter heksadesimal, lalu menawarkan "Pakai Node ID ini?".
- Clipboard hanya dibaca setelah pemain menekan tombol itu. Belum di-build/diuji di perangkat.

### ZeroTier tertanam (VPN di dalam aplikasi, pengganti aplikasi ZeroTier One)
- Layar **ZeroTier** (tombol di lobby, atau Atur -> Multiplayer Online -> ZeroTier di aplikasi): Tambah jaringan (Network ID), toggle per jaringan, izin data seluler (bawaan mati), Node ID + status ONLINE/OFFLINE. Ketuk Node ID untuk menyalin; ketuk jaringan untuk menyalin ID / menghapus.
- Di lobby: ketuk jaringan -> **Minta akses**. Bila Node ID belum ada, ZeroTier tertanam dinyalakan dulu (Node ID dibuat otomatis, tanpa clipboard). Setelah pemilik menyetujui dan mencentang Auth, jaringan tersambung sendiri; form Buat server otomatis memakai IP ZeroTier dan menandai server `[ZeroTier]`.
- Arsitektur: `ZtEngine` (node ZeroTier lewat SDK resmi, dipakai via refleksi) <-> `EthBridge` (ARP + IP<->Ethernet) <-> TUN `ZeroTierVpnService` <-> soket netplay biasa. Kode netplay tidak diubah. VPN dibatasi hanya untuk aplikasi ini dan hanya rentang IP jaringan ZeroTier.
- Build: `scripts/setup_zerotier_core.sh` mengunduh ZeroTierOne (tag di `ZT_TAGS`), membangun `libZeroTierOneJNI.so` dengan NDK dan menyalin SDK Java ke `app/zt-sdk/`. Workflow memakainya bila berhasil; bila gagal APK tetap dibuild tanpa ZeroTier tertanam (layar ZeroTier menjelaskan hal itu). Ringkasan hasilnya ada di tab Summary run Actions ("ZeroTier tertanam: YA/TIDAK") dan artifact **zerotier-api** (layout + daftar API SDK) untuk mencocokkan bila versi SDK berbeda.
- Uji tanpa Android: `bash tests/run_ztengine_test.sh` (ZtEngine melawan SDK palsu), `bash tests/run_ethbridge_test.sh`.
- **Server muncul otomatis (siaran ZeroTier, tanpa lobby)**: saat host menyalakan server dari Buat server, aplikasi mengirim paket UDP kecil (port 7756) ke alamat siaran subnet jaringan ZeroTier tiap 3 detik. Pemain lain yang tersambung ke jaringan yang sama melihatnya di bagian **Server di jaringan ZeroTier (otomatis)** pada layar Multiplayer Online (daftar disegarkan tiap 2 detik; server hilang bila 10 detik tak terdengar). Tidak perlu alamat lobby atau PC yang menyala terus. Paket dikirim/diterima langsung sebagai frame IPv4 lewat `ZtEngine` (`ZtDiscovery`), bukan lewat soket Android, jadi tidak bergantung pada TUN meneruskan siaran. Syarat: di my.zerotier.com pengaturan jaringan **Enable Broadcast** aktif, dan aturan alur jaringan masih mengizinkan IPv4 (bawaan). Hanya berlaku di satu jaringan ZeroTier; di luar itu tetap pakai lobby / IP. Tes: `bash tests/run_ztdiscovery_test.sh`. Belum diuji di perangkat.
- **Uji koneksi** (layar ZeroTier -> tombol *Uji koneksi*, isi IP ZeroTier teman): menguji jalur bertahap supaya kelihatan lapisan mana yang macet: (1) mesin ONLINE, (2) peer terlihat (langsung / lewat relay, ping), (3) ARP dijawab oleh HP teman, (4) UDP pulang-pergi lewat VPN (butuh build ini di kedua HP; port gema 7757). Hasil bisa disalin. ARP gagal = HP teman tak terjangkau lewat ZeroTier; ARP ok tapi UDP gagal = masalah VPN/TUN; keduanya ok tapi game gagal = masalah lapisan netplay.
- Batasan: Android hanya mengizinkan satu VPN aktif (jangan jalankan ZeroTier One asli bersamaan); izin VPN diminta sekali; cek data seluler hanya saat ZeroTier dinyalakan; IPv6 belum didukung; belum di-build/diuji di perangkat. Lisensi ZeroTier BSL 1.1: baca LICENSE.txt di repositori ZeroTierOne sebelum merilis.

## Pemain di jaringan ZeroTier + Ajak main (tanpa lobby)
- Selama ZeroTier di aplikasi menyala, tiap HP menyiarkan **kehadiran** (nama pemain + Node ID) tiap 3 detik ke alamat siaran subnet, memakai jalur yang sama dengan pengumuman server (`ZtDiscovery`, UDP 7756, paket `AIOPLR1`). Tidak perlu ada yang membuat server dulu.
- Layar **Multiplayer Online** menampilkan bagian **Pemain di jaringan ZeroTier (n)**, seperti daftar member di my.zerotier.com tapi langsung di aplikasi. Pemain hilang dari daftar bila 10 detik tak terdengar.
  - Pemain yang sedang host: tertulis `host: <game> (1/2)`, ketuk -> **Gabung**.
  - Pemain yang belum main: ketuk -> **Ajak main** -> pilih game. Server dibuat otomatis dan pengumumannya memuat `invite=<IP ZeroTier pemain itu>`; di HP pemain itu muncul dialog "<nama> mengajak main <game>, Gabung?" (sekali per server) selama layar Multiplayer Online terbuka.
- Nama yang tampil = Pengaturan -> Nama pemain. Game yang sama persis tetap wajib ada di library kedua pemain.
- Batas: satu sesi netplay tetap **2 pemain** (host = P1, tamu = P2). Banyak HP bisa saling melihat di satu jaringan, tetapi satu game hanya menghubungkan dua. Main bertiga/berempat butuh perubahan besar di `netplay.cpp` (belum dikerjakan).
- Syarat jaringan sama seperti server otomatis: **Enable Broadcast** aktif di my.zerotier.com dan aturan alur masih mengizinkan IPv4.
- Tes: `bash tests/run_ztdiscovery_test.sh` (sudah mencakup kehadiran, 3 HP saling melihat, ajakan). Sisi Kotlin (`LobbyActivity`, `ZeroTierVpnService`) belum di-build/diuji di perangkat.

## NDS (SeedlessDS): terjemahan & fast forward

Dua ikon di pojok kanan atas layar game (sama seperti emulator lain):

- **Terjemahan (A/文)**: ketuk 1x = terjemahkan / tutup; ketuk 2x = langsung terjemahkan menu (Start, Option, dst.); tahan 2 detik = pilih mesin (Google, Groq, ML Kit offline). Mesin, OCR, dan overlay-nya sama persis dengan yang dipakai emulator lain. Semua pilihan juga ada di menu jeda > **Terjemahan…** (mode dengan/tanpa jeda, baca ulang teliti, diagnosis OCR). Saat controller eksternal tersambung, logo terjemahan tetap tampil sebagai tombol melayang yang bisa digeser ke mana pun (posisi diingat).
- **Fast forward (panah ganda)**: ketuk 1x = hidup/mati; ketuk 2x cepat = ganti ke kecepatan berikutnya (2x, 3x, 4x, 5x, 8x, tanpa batas, lalu kembali ke 2x) dan fast forward menyala. Dijalankan lewat bit 29 config core + kecepatan di bit 12..15. Kecepatan diatur di Pengaturan SeedlessDS > Performa (2x, 3x bawaan, 4x, 5x, 8x, tanpa batas).
- Gamepad: **R2** = fast forward, **L2** = terjemahkan. Tombol bisa disembunyikan di Pengaturan > Performa.
