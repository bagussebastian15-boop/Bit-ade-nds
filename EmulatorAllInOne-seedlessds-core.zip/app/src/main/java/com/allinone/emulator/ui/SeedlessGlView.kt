package com.allinone.emulator.ui

import android.content.Context
import android.graphics.PixelFormat
import android.opengl.GLES20
import android.view.Surface
import android.view.SurfaceHolder
import android.view.SurfaceView
import com.allinone.emulator.data.SeedlessSettings
import com.seedlessds.app.SeedlessBridge
import com.seedlessds.app.filesystem.PathCache
import com.seedlessds.core.SeedlessCore
import java.nio.ByteBuffer
import java.nio.ByteOrder
import javax.microedition.khronos.egl.EGL10
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.egl.EGLContext
import javax.microedition.khronos.egl.EGLDisplay
import javax.microedition.khronos.egl.EGLSurface

/**
 * Penyaji dua layar NDS untuk core SeedlessDS. Versi ringkas dari DsGlView (SeedlessDS 1.0.1): satu layar fisik,
 * resolusi asli 256x192, filter "None", tanpa layar eksternal / zero-copy / ring buffer.
 * Alur per frame sama dengan aslinya: frameWord -> waitScreen -> fxRender -> eglSwapBuffers.
 */
class SeedlessGlView(context: Context) : SurfaceView(context) {

    private val renderer = DsRenderer()
    private val thread = RenderThread()

    /** Persegi layar bawah (x, y, lebar, tinggi) dalam piksel view; dipakai untuk memetakan sentuhan. */
    @Volatile var bottomScreenRect: FloatArray = floatArrayOf(0f, 0f, 0f, 0f)
        private set

    @Volatile var onFirstFrame: (() -> Unit)? = null

    // Pengaturan tampilan khusus SeedlessDS (dibaca dari SeedlessSettings, bukan Settings emulator lain).
    private val cfg = SeedlessSettings(context)
    @Volatile private var filterName = cfg.filter
    @Volatile private var layoutMode = cfg.layoutMode
    @Volatile private var swapScreens = cfg.swapScreens
    @Volatile private var stretchScreens = cfg.stretch
    @Volatile private var displayDirty = false

    /** Jumlah frame yang sudah ditampilkan; dipakai penghitung FPS. */
    @Volatile var framesPresented = 0L
        private set

    /** Baca ulang filter dan susunan layar dari pengaturan; diterapkan pada frame berikutnya (tanpa memulai ulang game). */
    fun applyDisplay() {
        filterName = cfg.filter
        layoutMode = cfg.layoutMode
        swapScreens = cfg.swapScreens
        stretchScreens = cfg.stretch
        displayDirty = true
    }

    @Volatile private var padState = 0
    @Volatile private var touchActive = false
    @Volatile private var touchPacked = 0

    private fun pushInput() {
        SeedlessCore.input(padState or (if (touchActive) 0x80000000.toInt() else 0), touchPacked, 0)
    }

    /** Bit tombol core: UP0 DOWN1 LEFT2 RIGHT3 A4 B5 X6 Y7 L8 R9 START10 SELECT11. */
    fun setButton(bit: Int, pressed: Boolean) {
        if (bit < 0) return
        padState = if (pressed) padState or (1 shl bit) else padState and (1 shl bit).inv()
        pushInput()
    }

    fun releaseAll() { padState = 0; touchActive = false; touchPacked = 0; pushInput() }

    /** [x],[y] dalam piksel view; sentuhan di luar layar bawah dijepit ke tepinya, ACTION_UP melepas stylus. */
    fun touch(down: Boolean, x: Float, y: Float) {
        if (!down) { touchActive = false; touchPacked = 0; pushInput(); return }
        val r = bottomScreenRect
        if (r[2] <= 0f || r[3] <= 0f) return
        val lx = ((x - r[0]) / r[2]).coerceIn(0f, 1f)
        val ly = ((y - r[1]) / r[3]).coerceIn(0f, 1f)
        val dx = (lx * 255f).toInt().coerceIn(0, 255)
        val dy = (ly * 191f).toInt().coerceIn(0, 191)
        touchActive = true; touchPacked = (dx shl 16) or dy; pushInput()
    }

    init {
        keepScreenOn = true
        holder.setFormat(PixelFormat.RGB_565)
        holder.addCallback(object : SurfaceHolder.Callback {
            override fun surfaceCreated(h: SurfaceHolder) {}
            override fun surfaceChanged(h: SurfaceHolder, format: Int, w: Int, hh: Int) =
                thread.onSurfaceReady(h.surface, w, hh)
            override fun surfaceDestroyed(h: SurfaceHolder) = thread.onSurfaceGone()
        })
        thread.start()
    }

    fun onPause() { SeedlessCore.signalScreen(); thread.setPaused(true) }
    fun onResume() = thread.setPaused(false)

    override fun onDetachedFromWindow() {
        thread.shutdown()
        super.onDetachedFromWindow()
    }

    private inner class RenderThread : Thread("DsRender") {
        private val lock = Object()
        private var pending: Surface? = null
        private var pendingW = 0
        private var pendingH = 0
        private var surfaceChanged = false
        private var dropWindow = false
        private var exiting = false
        private var paused = false

        private val egl = EGLContext.getEGL() as EGL10
        private var dpy: EGLDisplay? = null
        private var cfg: EGLConfig? = null
        private var ctx: EGLContext? = null
        private var win: EGLSurface? = null
        private var winW = 0
        private var winH = 0
        private var started = false
        private var current: Surface? = null

        fun onSurfaceReady(surface: Surface, w: Int, h: Int) = synchronized(lock) {
            pending = surface; pendingW = w; pendingH = h; surfaceChanged = true
            lock.notifyAll()
        }

        fun onSurfaceGone() {
            SeedlessCore.signalScreen()
            synchronized(lock) {
                pending = null
                dropWindow = true
                lock.notifyAll()
                val deadline = System.currentTimeMillis() + 800
                while (dropWindow && System.currentTimeMillis() < deadline) {
                    runCatching { lock.wait(100) }
                }
            }
        }

        fun setPaused(value: Boolean) = synchronized(lock) { paused = value; lock.notifyAll() }

        fun shutdown() {
            SeedlessCore.signalScreen()
            synchronized(lock) { exiting = true; lock.notifyAll() }
            runCatching { join(1000) }
        }

        override fun run() {
            while (true) {
                var surface: Surface? = null
                var w = 0
                var h = 0
                var fresh = false
                synchronized(lock) {
                    while (true) {
                        if (dropWindow) { destroyWindow(); dropWindow = false; lock.notifyAll() }
                        if (exiting) { teardown(); return }
                        if (!paused && pending != null) {
                            surface = pending; w = pendingW; h = pendingH
                            fresh = surfaceChanged; surfaceChanged = false
                            break
                        }
                        runCatching { lock.wait() }
                    }
                }
                if (!ensureWindow(surface!!, w, h, fresh)) {
                    runCatching { sleep(16) }
                    continue
                }
                val drew = renderer.draw()
                egl.eglSwapBuffers(dpy, win)
                if (drew) renderer.afterSwap()
            }
        }

        private fun ensureWindow(surface: Surface, w: Int, h: Int, fresh: Boolean): Boolean {
            if (!initEgl()) return false
            if (win != null && (fresh || !(current === surface && surface.isValid))) destroyWindow()
            if (win == null) {
                val s = egl.eglCreateWindowSurface(dpy, cfg, surface, null)
                if (s == null || s == EGL10.EGL_NO_SURFACE) return false
                win = s
                current = surface
                if (!egl.eglMakeCurrent(dpy, s, s, ctx)) { destroyWindow(); return false }
                winW = 0; winH = 0
                if (!started) { renderer.created(); started = true }
            }
            if (w != winW || h != winH) {
                winW = w; winH = h
                renderer.changed(w, h)
            }
            return true
        }

        private fun initEgl(): Boolean {
            if (ctx != null) return true
            val d = egl.eglGetDisplay(EGL10.EGL_DEFAULT_DISPLAY)
            if (d == null || d == EGL10.EGL_NO_DISPLAY) return false
            if (!egl.eglInitialize(d, IntArray(2))) return false
            val attribs = intArrayOf(
                EGL10.EGL_RED_SIZE, 5, EGL10.EGL_GREEN_SIZE, 6, EGL10.EGL_BLUE_SIZE, 5, EGL10.EGL_ALPHA_SIZE, 0,
                EGL10.EGL_RENDERABLE_TYPE, EGL_OPENGL_ES2_BIT, EGL10.EGL_SURFACE_TYPE, EGL10.EGL_WINDOW_BIT,
                EGL10.EGL_NONE,
            )
            val out = arrayOfNulls<EGLConfig>(1)
            val n = IntArray(1)
            if (!egl.eglChooseConfig(d, attribs, out, 1, n) || n[0] == 0) return false
            val c = out[0] ?: return false
            val context = egl.eglCreateContext(d, c, EGL10.EGL_NO_CONTEXT,
                intArrayOf(EGL_CONTEXT_CLIENT_VERSION, 2, EGL10.EGL_NONE))
            if (context == null || context == EGL10.EGL_NO_CONTEXT) return false
            dpy = d; cfg = c; ctx = context
            return true
        }

        private fun destroyWindow() {
            val d = dpy ?: return
            win?.let {
                egl.eglMakeCurrent(d, EGL10.EGL_NO_SURFACE, EGL10.EGL_NO_SURFACE, EGL10.EGL_NO_CONTEXT)
                runCatching { egl.eglDestroySurface(d, it) }
            }
            win = null
            current = null
        }

        private fun teardown() {
            destroyWindow()
            val d = dpy ?: return
            ctx?.let { runCatching { egl.eglDestroyContext(d, it) } }
            ctx = null
            runCatching { egl.eglTerminate(d) }
            dpy = null
            started = false
        }
    }

    private companion object {
        const val EGL_OPENGL_ES2_BIT = 4
        const val EGL_CONTEXT_CLIENT_VERSION = 0x3098
        const val SRC_W = 256
        const val SRC_H = 192
    }

    private inner class DsRenderer {
        private val FX_UV_BLOCK = floatArrayOf(
            0f, 0f, 0f, 1f, 1f, 1f, 0f, 0f, 1f, 1f, 1f, 0f,
            0f, 0f, 0f, 1f, 1f, 1f, 0f, 0f, 1f, 1f, 1f, 0f,
            0f, 0f, 0f, 1f, 1f, 1f, 0f, 0f, 1f, 1f, 1f, 0f,
            0f, 1f, 0f, 0f, 1f, 0f, 0f, 1f, 1f, 0f, 1f, 1f,
            0f, 0f, 0f, 1f, 1f, 1f, 0f, 0f, 1f, 1f, 1f, 0f,
            0f, 0f, 0f, 1f, 1f, 1f, 0f, 0f, 1f, 1f, 1f, 0f,
        )
        private var topTex = 0
        private var bottomTex = 0
        private var vbo = 0
        private var viewW = 0
        private var viewH = 0
        private var topPxW = SRC_W; private var topPxH = SRC_H
        private var botPxW = SRC_W; private var botPxH = SRC_H
        private var presentSet = false
        private var loadedFilter = ""

        /** Muat shader .dfx; bila file tidak ada/gagal, jatuh kembali ke None supaya layar tidak hitam. */
        private fun loadFilter(name: String) {
            var n = name
            var r = SeedlessCore.fxLoad(PathCache.SYS_PREFIX + "shaders/$n.dfx", 0, 2208)
            if (r < 0 && n != SeedlessSettings.DEFAULT_FILTER) {
                n = SeedlessSettings.DEFAULT_FILTER
                r = SeedlessCore.fxLoad(PathCache.SYS_PREFIX + "shaders/$n.dfx", 0, 2208)
            }
            loadedFilter = n
            android.util.Log.i("SeedlessGl", "filter $n -> hasil muat $r")
            SeedlessCore.fxSetup(SRC_W, SRC_H, 0, 0, viewW, viewH)
        }

        fun created() {
            presentSet = false
            GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
            val tex = IntArray(2)
            GLES20.glGenTextures(2, tex, 0)
            topTex = tex[0]; bottomTex = tex[1]
            createScreenTexture(topTex)
            createScreenTexture(bottomTex)
            SeedlessCore.clearScreens(topTex, bottomTex)

            val buf = IntArray(1)
            GLES20.glGenBuffers(1, buf, 0)
            vbo = buf[0]
            GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, vbo)
            GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, 4416, null, GLES20.GL_DYNAMIC_DRAW)

            val fullQuad = floatArrayOf(-1f, 1f, -1f, -1f, 1f, -1f, -1f, 1f, 1f, -1f, 1f, 1f)
            writeVbo(96, fullQuad)
            writeVbo(144, fullQuad)
            writeVbo(2208, FX_UV_BLOCK)

            GLES20.glDisable(GLES20.GL_DEPTH_TEST)
            GLES20.glDisable(GLES20.GL_BLEND)
        }

        private fun createScreenTexture(id: Int) {
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, id)
            GLES20.glTexImage2D(GLES20.GL_TEXTURE_2D, 0, GLES20.GL_RGBA, SRC_W, SRC_H, 0,
                GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, null)
            GLES20.glTexParameterf(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR.toFloat())
            GLES20.glTexParameterf(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR.toFloat())
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
        }

        fun changed(width: Int, height: Int) {
            viewW = width; viewH = height
            GLES20.glViewport(0, 0, width, height)
            GLES20.glClearColor(0f, 0f, 0f, 1f)

            GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, vbo)
            writeScreenGeometry(width, height)

            loadFilter(filterName)
            SeedlessCore.applyConfig(SeedlessSupport.configBits(cfg))
        }

        private fun fit(maxW: Float, maxH: Float): Pair<Float, Float> {
            if (stretchScreens) return Pair(maxW, maxH)
            val a = SRC_W.toFloat() / SRC_H
            return if (maxW / maxH > a) Pair(maxH * a, maxH) else Pair(maxW, maxW / a)
        }

        private fun quadNdc(w: Int, h: Int, r: FloatArray): FloatArray {
            fun ndx(px: Float) = px / w * 2f - 1f
            fun ndy(px: Float) = 1f - px / h * 2f
            val x0 = ndx(r[0]); val x1 = ndx(r[0] + r[2]); val yt = ndy(r[1]); val yb = ndy(r[1] + r[3])
            return floatArrayOf(x0, yt, x0, yb, x1, yb, x0, yt, x1, yb, x1, yt)
        }

        private fun writeScreenGeometry(w: Int, h: Int) {
            // Mode otomatis: potret = atas-bawah, lanskap = kiri-kanan. Mode 1/2 memaksa salah satunya.
            val vertical = when (layoutMode) { 1 -> true; 2 -> false; else -> h > w }
            val first: FloatArray    // slot kiri / atas
            val second: FloatArray   // slot kanan / bawah
            if (vertical) {
                val (sw, sh) = fit(w.toFloat(), h / 2f)
                val x = (w - sw) / 2f
                // potret: menempel di atas layar (kontrol di bawahnya); lanskap: di tengah
                val y = if (h > w) 0f else (h - 2f * sh) / 2f
                first = floatArrayOf(x, y, sw, sh)
                second = floatArrayOf(x, y + sh, sw, sh)
            } else {
                val halfW = w / 2f
                val (sw, sh) = fit(halfW, h.toFloat())
                val y = (h - sh) / 2f
                first = floatArrayOf((halfW - sw) / 2f, y, sw, sh)
                second = floatArrayOf(halfW + (halfW - sw) / 2f, y, sw, sh)
            }
            // Tukar layar: layar atas NDS digambar di slot kedua, layar bawah (sentuh) di slot pertama.
            val top = if (swapScreens) second else first
            val bot = if (swapScreens) first else second
            val geo = FloatArray(24)
            System.arraycopy(quadNdc(w, h, top), 0, geo, 0, 12)
            System.arraycopy(quadNdc(w, h, bot), 0, geo, 12, 12)
            topPxW = top[2].toInt(); topPxH = top[3].toInt()
            botPxW = bot[2].toInt(); botPxH = bot[3].toInt()
            bottomScreenRect = bot
            writeVbo(0, geo)
            writeVbo(2208, FX_UV_BLOCK)
        }

        /** Terapkan perubahan filter/susunan layar dari menu pengaturan (dipanggil di thread GL). */
        private fun applyDisplayChanges() {
            if (!displayDirty) return
            displayDirty = false
            if (viewW <= 0 || viewH <= 0) return
            GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, vbo)
            writeScreenGeometry(viewW, viewH)
            if (filterName != loadedFilter) loadFilter(filterName)
        }

        private fun writeVbo(offsetBytes: Int, data: FloatArray) {
            val b = ByteBuffer.allocateDirect(data.size * 4).order(ByteOrder.nativeOrder())
            b.asFloatBuffer().put(data).flip()
            GLES20.glBufferSubData(GLES20.GL_ARRAY_BUFFER, offsetBytes, data.size * 4, b)
        }

        private fun setPresentMode() {
            if (presentSet) return
            presentSet = runCatching { SeedlessBridge.presentMode(3) }.getOrDefault(false)
        }

        fun draw(): Boolean {
            setPresentMode()
            applyDisplayChanges()
            val i7 = SeedlessCore.frameWord() and 0xFFFF
            GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, 0)
            GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
            if (i7 != 0) return false
            SeedlessCore.waitScreen()
            GLES20.glDisable(GLES20.GL_BLEND)
            SeedlessCore.fxRender(topTex, bottomTex, 0, 6, 18, topPxW, topPxH, botPxW, botPxH, false)
            return true
        }

        fun afterSwap() {
            framesPresented++
            onFirstFrame?.let { cb -> onFirstFrame = null; post { cb() } }
        }
    }
}
