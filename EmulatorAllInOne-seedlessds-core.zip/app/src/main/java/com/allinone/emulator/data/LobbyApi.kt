package com.allinone.emulator.data

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Klien daftar server multiplayer online ("lobby").
 * Lobby hanya DAFTAR alamat: game tetap berjalan peer-to-peer lewat netplay rollback (host = pemain 1, tamu = pemain 2).
 * Server lobby ada di folder server/ (lobby_server.py).
 */
object LobbyApi {

    /**
     * Alamat lobby server buatan Anda. GANTI sebelum build rilis, mis. "http://123.45.67.89:8080" atau "https://lobby.contoh.com".
     * Pemain juga bisa mengubahnya lewat tombol "Lobby" di layar Multiplayer Online.
     */
    const val DEFAULT_URL = ""

    data class Room(
        val id: String,
        val name: String,
        val host: String,
        val port: Int,
        val title: String,      // nama game (nama file tanpa ekstensi), dicocokkan dengan library pemain
        val console: String,    // nama enum Console (menentukan core)
        val players: Int,
        val maxPlayers: Int,
        val official: Boolean,
        val note: String,
        val owner: String,
        val online: Boolean = true,  // server resmi: false bila lobby tidak bisa menghubungi host-nya
        val net: String = ""         // jenis jaringan menurut lobby: zerotier | tailscale | lan | internet
    ) {
        val full: Boolean get() = players >= maxPlayers
    }

    /** Jaringan ZeroTier milik pemilik lobby; pemain harus minta akses (disetujui pemilik) sebelum bisa masuk. */
    data class Network(val id: String, val name: String)

    /** Permintaan masuk yang menunggu persetujuan pemilik. */
    data class Pending(val network: String, val networkName: String, val node: String, val owner: String)

    data class Listing(val official: List<Room>, val rooms: List<Room>, val networks: List<Network> = emptyList())

    /** Ditolak server (mis. port host tidak terjangkau dari internet). */
    class Rejected(msg: String) : Exception(msg)

    class NewRoom(
        val name: String, val title: String, val console: String, val port: Int,
        val delay: Int, val owner: String, val publicIp: String,
        val vpn: String = ""   // "zerotier" / "tailscale" / "" (otomatis); hanya berlaku bila publicIp diisi
    )

    fun list(base: String): Listing {
        val j = JSONObject(request("GET", base, "/api/rooms", null))
        val nets = ArrayList<Network>()
        j.optJSONArray("networks")?.let { a ->
            for (i in 0 until a.length()) a.optJSONObject(i)?.let { nets += Network(it.optString("id"), it.optString("name")) }
        }
        return Listing(parse(j.optJSONArray("official"), true), parse(j.optJSONArray("rooms"), false), nets)
    }

    /** Minta akses ke jaringan ZeroTier. Mengembalikan status: pending | approved | denied. */
    fun requestAccess(base: String, network: String, node: String, owner: String): String {
        val body = JSONObject().put("network", network).put("node", node).put("owner", owner)
        return JSONObject(request("POST", base, "/api/networks/request", body)).optString("status")
    }

    /** Status permintaan: none | pending | approved | denied. */
    fun accessStatus(base: String, network: String, node: String): String {
        val body = JSONObject().put("network", network).put("node", node)
        return JSONObject(request("POST", base, "/api/networks/status", body)).optString("status")
    }

    /** Pemilik: daftar permintaan yang menunggu. */
    fun pending(base: String, adminKey: String): List<Pending> {
        val a = JSONObject(request("GET", base, "/api/admin/requests", null, adminKey)).optJSONArray("pending")
            ?: return emptyList()
        val out = ArrayList<Pending>()
        for (i in 0 until a.length()) a.optJSONObject(i)?.let {
            out += Pending(it.optString("network"), it.optString("network_name"), it.optString("node"), it.optString("owner"))
        }
        return out
    }

    /** Pemilik: setujui / tolak satu permintaan. */
    fun decide(base: String, adminKey: String, network: String, node: String, approve: Boolean) {
        val body = JSONObject().put("network", network).put("node", node).put("approve", approve)
        request("POST", base, "/api/admin/decide", body, adminKey)
    }

    /** Daftarkan server milik sendiri. Mengembalikan token untuk heartbeat / menutup. */
    fun register(base: String, r: NewRoom): String {
        val body = JSONObject()
            .put("name", r.name).put("title", r.title).put("console", r.console)
            .put("port", r.port).put("delay", r.delay).put("owner", r.owner).put("ip", r.publicIp).put("vpn", r.vpn)
        return JSONObject(request("POST", base, "/api/rooms", body)).getString("token")
    }

    fun heartbeat(base: String, token: String, players: Int) {
        request("POST", base, "/api/rooms/heartbeat", JSONObject().put("token", token).put("players", players))
    }

    fun close(base: String, token: String) {
        request("POST", base, "/api/rooms/close", JSONObject().put("token", token))
    }

    private fun parse(a: JSONArray?, official: Boolean): List<Room> {
        if (a == null) return emptyList()
        val out = ArrayList<Room>()
        for (i in 0 until a.length()) {
            val o = a.optJSONObject(i) ?: continue
            out += Room(
                id = o.optString("id"), name = o.optString("name", "Server"),
                host = o.optString("host"), port = o.optInt("port", 7755),
                title = o.optString("title"), console = o.optString("console"),
                players = o.optInt("players", if (official) 0 else 1), maxPlayers = o.optInt("max", 2),
                official = official, note = o.optString("note"), owner = o.optString("owner"),
                online = o.optBoolean("online", true), net = o.optString("net")
            )
        }
        return out
    }

    private fun request(method: String, base: String, path: String, body: JSONObject?, adminKey: String = ""): String {
        val url = URL(base.trim().trimEnd('/') + path)
        val c = url.openConnection() as HttpURLConnection
        try {
            c.requestMethod = method
            c.connectTimeout = 6000
            c.readTimeout = 8000
            c.setRequestProperty("Accept", "application/json")
            if (adminKey.isNotEmpty()) c.setRequestProperty("X-Admin-Key", adminKey)
            if (body != null) {
                c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json")
                c.outputStream.use { it.write(body.toString().toByteArray()) }
            }
            val code = c.responseCode
            val text = (if (code in 200..299) c.inputStream else c.errorStream)?.use { String(it.readBytes()) }.orEmpty()
            if (code !in 200..299) {
                val msg = try { JSONObject(text).optString("error") } catch (_: Exception) { "" }
                throw if (code == 400 || code == 403 || code == 429) Rejected(msg.ifEmpty { "Ditolak server ($code)" })
                else java.io.IOException(msg.ifEmpty { "Server lobby membalas $code" })
            }
            return text
        } finally {
            c.disconnect()
        }
    }
}
