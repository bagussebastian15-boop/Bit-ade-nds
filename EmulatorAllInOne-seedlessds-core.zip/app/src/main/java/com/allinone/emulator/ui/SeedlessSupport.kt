package com.allinone.emulator.ui

import android.content.Context
import android.os.Build
import com.allinone.emulator.data.SeedlessSettings
import com.seedlessds.app.filesystem.PathCache
import java.io.File

/**
 * Pendukung core NDS SeedlessDS (SeedlessCoreDS, GPL-3.0-or-later) yang ditanam di APK ini.
 * Core hanya ada untuk arm64-v8a; di APK/perangkat lain NDS tetap memakai DeSmuME/melonDS.
 */
object SeedlessSupport {
    private const val ASSET_ROOT = "seedlessds"

    /** Core terpasang di APK ini dan HP-nya arm64 (library asli sudah bisa dimuat). */
    val available: Boolean by lazy {
        Build.SUPPORTED_ABIS.any { it == "arm64-v8a" } &&
            try { !com.seedlessds.core.SeedlessCore.startupError } catch (_: Throwable) { false }
    }

    /** Salin BIOS pengganti, database game, dan shader ke filesDir/SeedlessDS (dilewati bila sudah ada dan ukurannya sama). */
    fun ensureInstalled(ctx: Context) {
        val sys = File(ctx.filesDir, PathCache.DATA_DIR).apply { mkdirs() }
        copyAsset(ctx, "game_database.xml", File(sys, "game_database.xml"))
        copyAsset(ctx, "LC_default.dat", File(sys, "config/LC_default.dat"))
        copyAsset(ctx, "nds_bios_arm7_replacement.bin", File(sys, "system/nds_bios_arm7_replacement.bin"))
        copyAsset(ctx, "nds_bios_arm9_replacement.bin", File(sys, "system/nds_bios_arm9_replacement.bin"))
        copyDir(ctx, "shaders", File(sys, "shaders"))
        listOf("savestates", "backup", "cheats", "user").forEach { File(sys, it).mkdirs() }
    }

    private fun copyAsset(ctx: Context, name: String, out: File) {
        val path = "$ASSET_ROOT/$name"
        val size = try { ctx.assets.openFd(path).length } catch (_: Exception) { -1L }
        if (out.exists() && (size < 0 || out.length() == size)) return
        out.parentFile?.mkdirs()
        ctx.assets.open(path).use { i -> out.outputStream().use { o -> i.copyTo(o) } }
    }

    private fun copyDir(ctx: Context, rel: String, dest: File) {
        val path = "$ASSET_ROOT/$rel"
        val entries = try { ctx.assets.list(path) } catch (_: Exception) { null } ?: return
        if (entries.isEmpty()) {
            dest.parentFile?.mkdirs()
            if (!dest.exists()) ctx.assets.open(path).use { i -> dest.outputStream().use { o -> i.copyTo(o) } }
            return
        }
        dest.mkdirs()
        for (e in entries) copyDir(ctx, "$rel/$e", File(dest, e))
    }

    /** Jumlah thread emulasi otomatis menurut jumlah inti CPU. */
    private fun autoThreads(): Int {
        val cpus = Runtime.getRuntime().availableProcessors()
        return if (cpus >= 6) 8 else if (cpus >= 5) 4 else if (cpus >= 4) 3 else if (cpus >= 2) 2 else 1
    }

    /** Parameter pengguna firmware NDS: bahasa | warna 0 | bulan 6 | tanggal 6 (dipakai [SeedlessCore.firmwareUser]). */
    fun firmwarePacked(s: SeedlessSettings): Int = s.language or (0 shl 8) or (6 shl 16) or (6 shl 24)

    /**
     * Bit konfigurasi core (sama dengan DsSettings.pack() di SeedlessDS). Bawaan memilih jalur paling ringan:
     * resolusi asli 256x192 (tanpa hires 3D), tanpa Lua. Bagian yang bisa diubah pengguna dibaca dari
     * [SeedlessSettings] (frame skip, thread, penguatan suara); sisanya tetap.
     */
    fun configBits(s: SeedlessSettings): Long {
        val threads = if (s.threads == 0) autoThreads() else s.threads
        var v = 0L
        v = v or (s.frameSkip.toLong() and 15L)   // frameskipValue
        v = v or (1L shl 5)                    // frameskipType 0 (otomatis)
        v = v or ((3L and 3L) shl 8)           // audioLatency = 3
        v = v or ((2L and 15L) shl 12)         // ffwdSpeed = 2
        v = v or ((threads.toLong() and 15L) shl 16)
        v = v or ((2L and 7L) shl 32)          // autofireSpeed
        v = v or ((s.volumeBoost.toLong() and 3L) shl 37)   // penguatan suara (CONFIG_VOLUME_SHIFT di core)
        v = v or ((1L and 15L) shl 43)         // slot2Type
        v = v or 0x80000000L                   // suara
        v = v or 0x8000000L                    // cheat aktif
        v = v or 0x4000000L                    // mikrofon
        v = v or 0x2000000L                    // backup ikut di save state
        return v
    }
}

/**
 * Gerbang pengaman untuk panggilan ke core yang memakai mutex/objek layar milik core.
 *
 * Begitu game berhenti, core menghancurkan mutex + kondisi layar (gpu2d_worker_shutdown) dan objek audio-nya. Memanggil
 * signalScreen()/waitScreen()/applyConfig() sesudah itu membuat libc meng-abort proses (SIGABRT, status 134), yang tampil
 * sebagai "Core/aplikasi memanggil exit()" saat keluar ke library. Semua panggilan sinkronisasi dari sisi Kotlin lewat sini;
 * [close] menunggu panggilan yang sedang berjalan selesai lalu menutup gerbang SEBELUM core diminta berhenti.
 */
object SeedlessGate {
    private val lock = Any()
    @Volatile var alive = true
        private set

    /** Bangunkan thread yang menunggu layar. Aman dipanggil kapan pun; tidak berbuat apa-apa bila core sudah ditutup. */
    fun signal() {
        synchronized(lock) { if (alive) com.seedlessds.core.SeedlessCore.signalScreen() }
    }

    /** Tutup gerbang: setelah ini tidak ada lagi panggilan layar/konfigurasi ke core. */
    fun close() { synchronized(lock) { alive = false } }

    /** Buka lagi untuk game berikutnya (dipanggil setelah core dibuat ulang). */
    fun open() { synchronized(lock) { alive = true } }
}
