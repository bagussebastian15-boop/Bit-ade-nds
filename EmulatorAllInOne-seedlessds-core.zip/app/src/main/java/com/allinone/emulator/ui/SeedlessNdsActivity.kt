package com.allinone.emulator.ui

import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.allinone.emulator.input.VirtualPadView
import com.seedlessds.app.SeedlessBridge
import com.seedlessds.app.filesystem.PathCache
import com.seedlessds.core.SeedlessCore
import java.io.File

/**
 * Game NDS dengan core SeedlessDS (SeedlessCoreDS) yang ditanam di APK. Tidak memakai LibretroDroid:
 * core punya EGL/OpenGL dan audio OpenSL ES sendiri; activity ini hanya menyajikan dua layar, meneruskan tombol/sentuhan,
 * dan menyediakan menu (simpan/muat state, reset, keluar).
 */
class SeedlessNdsActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_ROM = "rom"
        private const val TAG = "SeedlessNds"
        /** attachSurface (nds_create) cukup sekali per proses, sama seperti SeedlessDS. */
        @Volatile private var inited = false
        private const val STATE_SLOT = 1
    }

    private lateinit var glView: SeedlessGlView
    private lateinit var pad: VirtualPadView
    private var emuThread: Thread? = null
    private var menuOpen = false
    private var hatX = 0
    private var hatY = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        enterImmersive()

        val romPath = intent.getStringExtra(EXTRA_ROM)
        if (romPath == null || !File(romPath).isFile || !SeedlessSupport.available) { finish(); return }

        try {
            SeedlessSupport.ensureInstalled(this)
            PathCache.setAppContext(applicationContext)
            PathCache.changeRom(romPath, romPath, File(romPath).name)
            if (!inited) {
                SeedlessCore.attachSurface(this, 1, Build.VERSION.SDK_INT)
                inited = true
            }
        } catch (t: Throwable) {
            fail("Gagal menyiapkan core SeedlessDS: ${t.javaClass.simpleName}: ${t.message}")
            return
        }

        glView = SeedlessGlView(this)
        pad = VirtualPadView(this).apply {
            opacity = 60
            haptics = false
            ndsLayout = true
            snesLayout = true
            onKey = { key, down -> keyToBit(key).let { if (it >= 0) glView.setButton(it, down) } }
            onScreenTouch = { action, x, y ->
                glView.touch(action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_MOVE, x, y)
            }
        }
        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        root.addView(glView, FrameLayout.LayoutParams(-1, -1, Gravity.CENTER))
        root.addView(pad, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() = showMenu()
        })

        startEmulation(romPath)
    }

    private fun startEmulation(romPath: String) {
        val t = Thread {
            try {
                SeedlessCore.firmwareUser("Player", 1 or (0 shl 8) or (6 shl 16) or (6 shl 24))
                SeedlessCore.autosaveInterval(0)
                SeedlessCore.audioVolume(100)
                SeedlessBridge.resetMemory()
                val ok = SeedlessCore.loadRom(romPath, -1, SeedlessSupport.configBits(), 0, false, -1L)
                if (!ok) runOnUiThread { fail("Core SeedlessDS menolak game ini (format tidak dikenali atau ROM rusak).") }
            } catch (e: Throwable) {
                runOnUiThread { fail("Core SeedlessDS gagal berjalan: ${e.javaClass.simpleName}: ${e.message}") }
            }
        }
        t.name = "seedless-emu"; t.priority = Thread.MAX_PRIORITY
        emuThread = t; t.start()
    }

    private fun fail(msg: String) {
        if (isFinishing || isDestroyed) return
        AlertDialog.Builder(this).setTitle("NDS (SeedlessDS)").setMessage(msg)
            .setPositiveButton("OK") { _, _ -> finish() }
            .setOnCancelListener { finish() }
            .show()
    }

    // ---------------------------------------------------------------- menu

    private fun setPaused(p: Boolean) {
        try { SeedlessCore.pause(if (p) 1 else 0) } catch (_: Throwable) {}
    }

    private fun showMenu() {
        if (menuOpen) return
        menuOpen = true
        setPaused(true)
        val items = arrayOf("Lanjut", "Simpan state (slot $STATE_SLOT)", "Muat state (slot $STATE_SLOT)", "Reset game", "Keluar ke library")
        AlertDialog.Builder(this).setTitle("NDS · SeedlessDS").setItems(items) { _, i ->
            when (i) {
                1 -> stateOp("Simpan") { SeedlessCore.stateSave(STATE_SLOT, false) }
                2 -> stateOp("Muat") { SeedlessCore.stateLoad(STATE_SLOT) }
                3 -> try { SeedlessCore.reset() } catch (_: Throwable) {}
                4 -> { closeMenu(resume = false); finish(); return@setItems }
            }
            closeMenu(resume = true)
        }.setOnCancelListener { closeMenu(resume = true) }.show()
    }

    private fun closeMenu(resume: Boolean) {
        menuOpen = false
        if (resume) setPaused(false)
    }

    private fun stateOp(label: String, op: () -> Boolean) {
        Thread {
            val ok = try { op() } catch (_: Throwable) { false }
            runOnUiThread { Toast.makeText(this, if (ok) "$label state: berhasil" else "$label state: gagal", Toast.LENGTH_SHORT).show() }
        }.start()
    }

    // ---------------------------------------------------------------- input

    /** Tombol Android (dari pad layar maupun gamepad fisik) ke bit core; -1 = bukan tombol game. */
    private fun keyToBit(code: Int): Int = when (code) {
        KeyEvent.KEYCODE_DPAD_UP -> 0
        KeyEvent.KEYCODE_DPAD_DOWN -> 1
        KeyEvent.KEYCODE_DPAD_LEFT -> 2
        KeyEvent.KEYCODE_DPAD_RIGHT -> 3
        KeyEvent.KEYCODE_BUTTON_A -> 4
        KeyEvent.KEYCODE_BUTTON_B -> 5
        KeyEvent.KEYCODE_BUTTON_X -> 6
        KeyEvent.KEYCODE_BUTTON_Y -> 7
        KeyEvent.KEYCODE_BUTTON_L1 -> 8
        KeyEvent.KEYCODE_BUTTON_R1 -> 9
        KeyEvent.KEYCODE_BUTTON_START -> 10
        KeyEvent.KEYCODE_BUTTON_SELECT -> 11
        else -> -1
    }

    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        val bit = keyToBit(e.keyCode)
        if (bit >= 0 && e.device?.isVirtual == false && e.repeatCount == 0 && ::glView.isInitialized) {
            glView.setButton(bit, e.action == KeyEvent.ACTION_DOWN)
            return true
        }
        if (e.keyCode == KeyEvent.KEYCODE_BUTTON_MODE && e.action == KeyEvent.ACTION_DOWN) { showMenu(); return true }
        return super.dispatchKeyEvent(e)
    }

    override fun onGenericMotionEvent(e: MotionEvent): Boolean {
        if (::glView.isInitialized && e.source and InputDevice.SOURCE_JOYSTICK != 0 && e.action == MotionEvent.ACTION_MOVE) {
            val x = e.getAxisValue(MotionEvent.AXIS_HAT_X).let { if (it == 0f) e.getAxisValue(MotionEvent.AXIS_X) else it }
            val y = e.getAxisValue(MotionEvent.AXIS_HAT_Y).let { if (it == 0f) e.getAxisValue(MotionEvent.AXIS_Y) else it }
            val nx = if (x < -0.5f) -1 else if (x > 0.5f) 1 else 0
            val ny = if (y < -0.5f) -1 else if (y > 0.5f) 1 else 0
            if (nx != hatX) { glView.setButton(2, nx < 0); glView.setButton(3, nx > 0); hatX = nx }
            if (ny != hatY) { glView.setButton(0, ny < 0); glView.setButton(1, ny > 0); hatY = ny }
            return true
        }
        return super.onGenericMotionEvent(e)
    }

    // ---------------------------------------------------------------- lifecycle

    private fun enterImmersive() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) enterImmersive()
    }

    override fun onPause() {
        super.onPause()
        if (!::glView.isInitialized) return
        glView.releaseAll()
        setPaused(true)
        glView.onPause()
    }

    override fun onResume() {
        super.onResume()
        if (!::glView.isInitialized) return
        glView.onResume()
        if (!menuOpen) setPaused(false)
    }

    override fun onDestroy() {
        if (::glView.isInitialized) {
            try { SeedlessCore.quit(); emuThread?.join(2000); SeedlessCore.release() } catch (_: Throwable) {}
        }
        super.onDestroy()
    }
}
