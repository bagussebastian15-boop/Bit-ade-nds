package com.allinone.emulator.ui

import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.HapticFeedbackConstants
import android.view.ViewConfiguration
import android.content.Context
import android.hardware.input.InputManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.allinone.emulator.data.Settings
import com.allinone.emulator.data.SeedlessSettings
import com.allinone.emulator.input.VirtualPadView
import com.seedlessds.app.SeedlessBridge
import com.seedlessds.app.filesystem.PathCache
import com.seedlessds.core.SeedlessCore
import java.io.File

/**
 * Game NDS dengan core SeedlessDS (SeedlessCoreDS) yang ditanam di APK. Tidak memakai LibretroDroid:
 * core punya EGL/OpenGL dan audio OpenSL ES sendiri; activity ini hanya menyajikan dua layar, meneruskan tombol/sentuhan,
 * dan menyediakan menu (simpan/muat state, reset, keluar).
 */
class SeedlessNdsActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_ROM = "rom"
        private const val TAG = "SeedlessNds"
        /** attachSurface (nds_create) cukup sekali per proses, sama seperti SeedlessDS. */
        @Volatile private var inited = false
        private const val SWAP_BTN_DP = 44
    }

    /** Pengaturan khusus SeedlessDS (terpisah dari Settings emulator lain). */
    private lateinit var cfg: SeedlessSettings
    private var fpsView: TextView? = null
    private val uiHandler = Handler(Looper.getMainLooper())
    private var lastFrames = 0L
    private var lastFpsAt = 0L
    private val fpsTick = object : Runnable {
        override fun run() {
            val now = System.nanoTime()
            val frames = glView.framesPresented
            val dt = (now - lastFpsAt) / 1e9
            if (dt > 0.0) fpsView?.text = "${Math.round((frames - lastFrames) / dt)} FPS"
            lastFrames = frames; lastFpsAt = now
            if (cfg.showFps) uiHandler.postDelayed(this, 1000)
        }
    }

    private val stateSlot get() = cfg.stateSlot

    private lateinit var glView: SeedlessGlView
    private lateinit var pad: VirtualPadView
    private lateinit var layoutEditor: ScreenLayoutEditor
    private lateinit var padEditorBar: View
    /** true saat mengatur tata letak kontrol; game tetap dijeda sampai Simpan/Batal. */
    private var padEditing = false
    /** Tombol melayang untuk menukar layar atas/bawah seketika saat game berjalan. */
    private lateinit var swapBtn: TextView
    private var comboBackup: Pair<String, String>? = null
    private var emuThread: Thread? = null
    private var menuOpen = false
    private var hatX = 0
    private var hatY = 0

    // ---- gamepad eksternal: layar utama otomatis fullscreen, layar kecil di atasnya
    private val inputManager by lazy { getSystemService(Context.INPUT_SERVICE) as InputManager }
    private val deviceListener = object : InputManager.InputDeviceListener {
        override fun onInputDeviceAdded(deviceId: Int) = refreshGamepad()
        override fun onInputDeviceRemoved(deviceId: Int) = refreshGamepad()
        override fun onInputDeviceChanged(deviceId: Int) = refreshGamepad()
    }

    private fun hasExternalGamepad(): Boolean = InputDevice.getDeviceIds().any { id ->
        val d = InputDevice.getDevice(id) ?: return@any false
        val s = d.sources
        !d.isVirtual && ((s and InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD ||
            (s and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK)
    }

    /** Aktifkan/matikan mode gamepad sesuai ada tidaknya gamepad fisik dan pengaturan. Aman dipanggil dari thread mana pun. */
    private fun refreshGamepad() {
        runOnUiThread {
            if (!::glView.isInitialized || !::pad.isInitialized) return@runOnUiThread
            val on = cfg.gamepadFullscreen && hasExternalGamepad()
            glView.setGamepadMode(on)
            pad.hideControls = on
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        enterImmersive()

        cfg = SeedlessSettings(this)
        val romPath = intent.getStringExtra(EXTRA_ROM)
        if (romPath == null || !File(romPath).isFile || !SeedlessSupport.available) { finish(); return }

        try {
            SeedlessSupport.ensureInstalled(this)
            PathCache.setAppContext(applicationContext)
            PathCache.changeRom(romPath, romPath, File(romPath).name)
            if (!inited) {
                SeedlessCore.attachSurface(this, 1, Build.VERSION.SDK_INT)
                inited = true
            }
        } catch (t: Throwable) {
            fail("Gagal menyiapkan core SeedlessDS: ${t.javaClass.simpleName}: ${t.message}")
            return
        }

        glView = SeedlessGlView(this)
        pad = VirtualPadView(this).apply {
            opacity = cfg.padOpacity
            haptics = cfg.haptics
            ndsLayout = true
            snesLayout = true
            // Tombol kombo NDS (dipakai bersama emulator NDS lain, sama seperti tata letak tombolnya).
            Settings(this@SeedlessNdsActivity).let { combo1Spec = it.ndsCombo1; combo2Spec = it.ndsCombo2 }
            onComboEdit = { slot -> showComboDialog(slot) }
            onKey = { key, down -> keyToBit(key).let { if (it >= 0) glView.setButton(it, down) } }
            onScreenTouch = { action, x, y ->
                glView.touch(action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_MOVE, x, y)
            }
        }
        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        root.addView(glView, FrameLayout.LayoutParams(-1, -1, Gravity.CENTER))
        root.addView(pad, FrameLayout.LayoutParams(-1, -1))
        fpsView = TextView(this).apply {
            setTextColor(Color.WHITE); setShadowLayer(4f, 0f, 0f, Color.BLACK)
            textSize = 12f; setPadding(16, 8, 16, 8); visibility = View.GONE
        }
        root.addView(fpsView, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.START))
        swapBtn = buildSwapButton()
        root.addView(swapBtn, FrameLayout.LayoutParams(dp(SWAP_BTN_DP), dp(SWAP_BTN_DP), Gravity.TOP or Gravity.START))
        root.addOnLayoutChangeListener { _, l, t, r, b, ol, ot, orr, ob ->
            if (r - l != orr - ol || b - t != ob - ot) placeSwapButton()
        }
        // Editor susunan layar kustom: menutupi game saat aktif, game tetap berjalan di belakangnya.
        layoutEditor = ScreenLayoutEditor(this, cfg).apply {
            visibility = View.GONE
            onPreview = { t, b -> glView.previewLayout(t, b) }
            onFinish = { save, t, b -> finishLayoutEdit(save, t, b) }
        }
        root.addView(layoutEditor, FrameLayout.LayoutParams(-1, -1))
        padEditorBar = buildPadEditorBar().apply { visibility = View.GONE }
        root.addView(padEditorBar, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL))
        setContentView(root)
        applyUi()   // inti belum berjalan di sini, jadi hanya bagian tampilan
        inputManager.registerInputDeviceListener(deviceListener, uiHandler)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    padEditing -> finishPadEdit(false)
                    ::layoutEditor.isInitialized && layoutEditor.isActive -> layoutEditor.finish(true)
                    else -> showMenu()
                }
            }
        })

        startEmulation(romPath)
    }

    private fun startEmulation(romPath: String) {
        val t = Thread {
            try {
                SeedlessCore.firmwareUser(cfg.nickname, SeedlessSupport.firmwarePacked(cfg))
                SeedlessCore.autosaveInterval(0)
                SeedlessCore.audioVolume(cfg.volume)
                SeedlessBridge.resetMemory()
                val ok = SeedlessCore.loadRom(romPath, -1, SeedlessSupport.configBits(cfg), 0, false, -1L)
                if (!ok) runOnUiThread { fail("Core SeedlessDS menolak game ini (format tidak dikenali atau ROM rusak).") }
            } catch (e: Throwable) {
                runOnUiThread { fail("Core SeedlessDS gagal berjalan: ${e.javaClass.simpleName}: ${e.message}") }
            }
        }
        t.name = "seedless-emu"; t.priority = Thread.MAX_PRIORITY
        emuThread = t; t.start()
    }

    private fun fail(msg: String) {
        if (isFinishing || isDestroyed) return
        AlertDialog.Builder(this).setTitle("NDS (SeedlessDS)").setMessage(msg)
            .setPositiveButton("OK") { _, _ -> finish() }
            .setOnCancelListener { finish() }
            .show()
    }

    // ---------------------------------------------------------------- menu

    private fun setPaused(p: Boolean) {
        try { SeedlessCore.pause(if (p) 1 else 0) } catch (_: Throwable) {}
    }

    private fun showMenu() {
        if (menuOpen || (::layoutEditor.isInitialized && layoutEditor.isActive)) return
        menuOpen = true
        setPaused(true)
        val slot = stateSlot
        val items = arrayOf("Lanjut", "Simpan state (slot $slot)", "Muat state (slot $slot)", "Reset game",
            "Atur tata letak kontrol", "Pengaturan SeedlessDS", "Keluar ke library")
        AlertDialog.Builder(this).setTitle("NDS · SeedlessDS").setItems(items) { _, i ->
            when (i) {
                1 -> stateOp("Simpan") { SeedlessCore.stateSave(slot, false) }
                2 -> stateOp("Muat") { SeedlessCore.stateLoad(slot) }
                3 -> try { SeedlessCore.reset() } catch (_: Throwable) {}
                4 -> { startPadEdit(); return@setItems }
                5 -> {
                    // Game tetap dijeda selama pengaturan terbuka; perubahan diterapkan langsung, lalu game lanjut saat ditutup.
                    SeedlessSettingsMenu.show(this, cfg, onChange = { applyLive() }, onClosed = { closeMenu(resume = true) },
                        onEditLayout = { startLayoutEdit() })
                    return@setItems
                }
                6 -> { closeMenu(resume = false); finish(); return@setItems }
            }
            closeMenu(resume = true)
        }.setOnCancelListener { closeMenu(resume = true) }.show()
    }

    // ---------------------------------------------------------------- tata letak kontrol virtual

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    /** Mulai mengatur tombol: seret = pindah, ketuk = nonaktif/aktif, ukuran lewat bilah. Game tetap dijeda. */
    private fun startPadEdit() {
        comboBackup = pad.combo1Spec to pad.combo2Spec
        padEditing = true
        pad.editMode = true
        padEditorBar.visibility = View.VISIBLE
    }

    private fun finishPadEdit(save: Boolean) {
        if (!padEditing) return
        if (save) {
            Settings(this).let { it.ndsCombo1 = pad.combo1Spec; it.ndsCombo2 = pad.combo2Spec }
            pad.saveLayout()
        } else {
            comboBackup?.let { pad.combo1Spec = it.first; pad.combo2Spec = it.second }
            pad.reloadLayout()
        }
        comboBackup = null
        pad.editMode = false
        padEditing = false
        padEditorBar.visibility = View.GONE
        closeMenu(resume = true)
        if (save) Toast.makeText(this, "Tata letak kontrol disimpan", Toast.LENGTH_SHORT).show()
    }

    /** Pilih tombol apa saja yang ditekan sekaligus oleh slot kombo [slot] (0 atau 1). Tanpa pilihan = tombol disembunyikan. */
    private fun showComboDialog(slot: Int) {
        val tokens = VirtualPadView.SNES_COMBO_KEYS
        val names = arrayOf("A", "B", "X", "Y", "L", "R", "Select", "Start", "↑ Atas", "↓ Bawah", "← Kiri", "→ Kanan")
        val have = (if (slot == 0) pad.combo1Spec else pad.combo2Spec).split('+').map { it.trim() }.toSet()
        val checked = BooleanArray(tokens.size) { tokens[it] in have }
        fun setSpec(spec: String) { if (slot == 0) pad.combo1Spec = spec else pad.combo2Spec = spec }
        AlertDialog.Builder(this)
            .setTitle("Tombol kombo ${slot + 1}")
            .setMultiChoiceItems(names, checked) { _, i, v -> checked[i] = v }
            .setPositiveButton("Simpan") { _, _ -> setSpec(tokens.filterIndexed { i, _ -> checked[i] }.joinToString("+")) }
            .setNeutralButton("Kosongkan") { _, _ -> setSpec("") }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun buildPadEditorBar(): View {
        fun btn(label: String, onClick: () -> Unit) = Button(this).apply {
            text = label; isAllCaps = false; textSize = 13f
            minWidth = 0; minimumWidth = 0
            setPadding(dp(10), dp(4), dp(10), dp(4))
            setOnClickListener { onClick() }
        }
        fun label(t: String) = TextView(this).apply {
            text = t; setTextColor(Color.WHITE); textSize = 12f; setPadding(dp(8), 0, dp(2), 0)
        }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            addView(label("Arah"))
            addView(btn("−") { pad.changeDirScale(-0.1f) })
            addView(btn("+") { pad.changeDirScale(0.1f) })
            addView(label("Tombol"))
            addView(btn("−") { pad.changeScale(-0.1f) })
            addView(btn("+") { pad.changeScale(0.1f) })
            addView(btn("Reset") { pad.resetLayout() })
            addView(btn("Batal") { finishPadEdit(false) })
            addView(btn("Simpan") { finishPadEdit(true) })
        }
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setBackgroundColor(0xAA000000.toInt())
            setPadding(dp(8), dp(4), dp(8), dp(4))
            addView(TextView(context).apply {
                text = "Seret tombol = pindah.  Ketuk = nonaktif/aktif.  Arah = ukuran D-pad, Tombol = ukuran tombol lain.  " +
                    "Ketuk \"+ Kombo\" = buat tombol kombo"
                setTextColor(Color.WHITE); textSize = 12f
            })
            addView(row)
        }
    }

    /** Buka editor susunan layar kustom (dipanggil dari menu pengaturan; menu itu menutup dan game lanjut berjalan). */
    private fun startLayoutEdit() {
        val rects = glView.rectsForEditing()
        if (rects == null) {
            Toast.makeText(this, "Layar belum siap, coba lagi sebentar lagi", Toast.LENGTH_SHORT).show()
            return
        }
        pad.releaseTouches()
        layoutEditor.begin(rects.first, rects.second)
    }

    private fun finishLayoutEdit(save: Boolean, top: FloatArray, bot: FloatArray) {
        if (save) {
            val portrait = glView.height > glView.width
            cfg.setCustomScreen(portrait, true, top)
            cfg.setCustomScreen(portrait, false, bot)
            cfg.layoutMode = SeedlessSettings.MODE_CUSTOM
            cfg.swapScreens = false   // editor mulai dari tampilan yang terlihat, jadi tukar sudah tercermin di posisi
            Toast.makeText(this, "Susunan layar kustom disimpan (${if (portrait) "potret" else "lanskap"})", Toast.LENGTH_SHORT).show()
        }
        glView.previewLayout(null, null)
        glView.applyDisplay()
    }

    /** Terapkan pengaturan SeedlessDS yang bisa berlaku langsung (tanpa memulai ulang game). */
    private fun applyLive() {
        try {
            SeedlessCore.audioVolume(cfg.volume)
            SeedlessCore.applyConfig(SeedlessSupport.configBits(cfg))
        } catch (_: Throwable) {}
        applyUi()
    }

    /** Bagian pengaturan yang hanya menyangkut tampilan Android (layar, kontrol, FPS). */
    private fun applyUi() {
        if (::glView.isInitialized) glView.applyDisplay()
        refreshGamepad()
        if (::pad.isInitialized) { pad.opacity = cfg.padOpacity; pad.haptics = cfg.haptics }
        if (::swapBtn.isInitialized) {
            swapBtn.visibility = if (cfg.showSwapButton) View.VISIBLE else View.GONE
            swapBtn.alpha = (cfg.padOpacity / 100f).coerceIn(0.35f, 1f)
            placeSwapButton()
        }
        uiHandler.removeCallbacks(fpsTick)
        fpsView?.visibility = if (cfg.showFps) View.VISIBLE else View.GONE
        if (cfg.showFps && ::glView.isInitialized) {
            lastFrames = glView.framesPresented; lastFpsAt = System.nanoTime()
            uiHandler.postDelayed(fpsTick, 1000)
        }
    }

    // ---------------------------------------------------------------- tukar layar seketika

    /** Tukar layar atas/bawah saat ini juga, game tidak dijeda. Dipakai tombol melayang dan tombol L3/R3 gamepad. */
    private fun swapScreensNow(feedbackView: View? = null) {
        if (!::glView.isInitialized || menuOpen || padEditing || (::layoutEditor.isInitialized && layoutEditor.isActive)) return
        glView.toggleSwap()
        if (cfg.haptics) (feedbackView ?: glView).performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
    }

    /** Tombol bulat kecil \u21C4: ketuk = tukar layar, seret = pindahkan (posisi tersimpan). */
    private fun buildSwapButton(): TextView {
        val slop = ViewConfiguration.get(this).scaledTouchSlop
        return TextView(this).apply {
            text = "\u21C4"
            setTextColor(Color.WHITE)
            textSize = 20f
            gravity = Gravity.CENTER
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0x99202530.toInt()); setStroke(dp(1), 0x66FFFFFF) }
            elevation = dp(4).toFloat()
            var downX = 0f; var downY = 0f; var startTx = 0f; var startTy = 0f; var dragging = false
            setOnTouchListener { v, e ->
                val parent = v.parent as? View
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        downX = e.rawX; downY = e.rawY; startTx = v.translationX; startTy = v.translationY; dragging = false
                        v.parent?.requestDisallowInterceptTouchEvent(true)
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = e.rawX - downX; val dy = e.rawY - downY
                        if (!dragging && (kotlin.math.abs(dx) > slop * 2 || kotlin.math.abs(dy) > slop * 2)) dragging = true
                        if (dragging && parent != null) {
                            val maxX = (parent.width - v.width).coerceAtLeast(0).toFloat()
                            val maxY = (parent.height - v.height).coerceAtLeast(0).toFloat()
                            v.translationX = (startTx + dx).coerceIn(0f, maxX)
                            v.translationY = (startTy + dy).coerceIn(0f, maxY)
                        }
                    }
                    MotionEvent.ACTION_UP -> {
                        if (dragging && parent != null) {
                            val maxX = (parent.width - v.width).coerceAtLeast(1).toFloat()
                            val maxY = (parent.height - v.height).coerceAtLeast(1).toFloat()
                            cfg.swapButtonX = (v.translationX / maxX).coerceIn(0f, 1f)
                            cfg.swapButtonY = (v.translationY / maxY).coerceIn(0f, 1f)
                        } else swapScreensNow(v)
                    }
                }
                true
            }
        }
    }

    /** Letakkan tombol sesuai posisi tersimpan (bawaan: sesuai orientasi, lihat di bawah). */
    private fun placeSwapButton() {
        if (!::swapBtn.isInitialized) return
        val parent = swapBtn.parent as? View ?: return
        val maxX = (parent.width - dp(SWAP_BTN_DP)).coerceAtLeast(0).toFloat()
        val maxY = (parent.height - dp(SWAP_BTN_DP)).coerceAtLeast(0).toFloat()
        // Bawaan (belum pernah digeser) diukur dari screenshot pengguna: potret di tengah bawah layar game,
        // lanskap di tepi kanan di sebelah tombol X.
        val portrait = parent.height > parent.width
        val fx = cfg.swapButtonX.let { if (it < 0f) (if (portrait) 0.4725f else 0.9859f) else it }
        val fy = cfg.swapButtonY.let { if (it < 0f) (if (portrait) 0.8862f else 0.7199f) else it }
        swapBtn.translationX = (fx * maxX).coerceIn(0f, maxX)
        swapBtn.translationY = (fy * maxY).coerceIn(0f, maxY)
    }

    private fun closeMenu(resume: Boolean) {
        menuOpen = false
        if (resume) setPaused(false)
    }

    private fun stateOp(label: String, op: () -> Boolean) {
        Thread {
            val ok = try { op() } catch (_: Throwable) { false }
            runOnUiThread { Toast.makeText(this, if (ok) "$label state: berhasil" else "$label state: gagal", Toast.LENGTH_SHORT).show() }
        }.start()
    }

    // ---------------------------------------------------------------- input

    /** Tombol Android (dari pad layar maupun gamepad fisik) ke bit core; -1 = bukan tombol game. */
    private fun keyToBit(code: Int): Int = when (code) {
        KeyEvent.KEYCODE_DPAD_UP -> 0
        KeyEvent.KEYCODE_DPAD_DOWN -> 1
        KeyEvent.KEYCODE_DPAD_LEFT -> 2
        KeyEvent.KEYCODE_DPAD_RIGHT -> 3
        KeyEvent.KEYCODE_BUTTON_A -> 4
        KeyEvent.KEYCODE_BUTTON_B -> 5
        KeyEvent.KEYCODE_BUTTON_X -> 6
        KeyEvent.KEYCODE_BUTTON_Y -> 7
        KeyEvent.KEYCODE_BUTTON_L1 -> 8
        KeyEvent.KEYCODE_BUTTON_R1 -> 9
        KeyEvent.KEYCODE_BUTTON_START -> 10
        KeyEvent.KEYCODE_BUTTON_SELECT -> 11
        else -> -1
    }

    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        val bit = keyToBit(e.keyCode)
        if (bit >= 0 && e.device?.isVirtual == false && e.repeatCount == 0 && ::glView.isInitialized) {
            glView.setButton(bit, e.action == KeyEvent.ACTION_DOWN)
            return true
        }
        if ((e.keyCode == KeyEvent.KEYCODE_BUTTON_THUMBL || e.keyCode == KeyEvent.KEYCODE_BUTTON_THUMBR) &&
            e.device?.isVirtual == false) {
            if (e.action == KeyEvent.ACTION_DOWN && e.repeatCount == 0) swapScreensNow()
            return true
        }
        if (e.keyCode == KeyEvent.KEYCODE_BUTTON_MODE && e.action == KeyEvent.ACTION_DOWN) { showMenu(); return true }
        return super.dispatchKeyEvent(e)
    }

    override fun onGenericMotionEvent(e: MotionEvent): Boolean {
        if (::glView.isInitialized && e.source and InputDevice.SOURCE_JOYSTICK != 0 && e.action == MotionEvent.ACTION_MOVE) {
            val x = e.getAxisValue(MotionEvent.AXIS_HAT_X).let { if (it == 0f) e.getAxisValue(MotionEvent.AXIS_X) else it }
            val y = e.getAxisValue(MotionEvent.AXIS_HAT_Y).let { if (it == 0f) e.getAxisValue(MotionEvent.AXIS_Y) else it }
            val nx = if (x < -0.5f) -1 else if (x > 0.5f) 1 else 0
            val ny = if (y < -0.5f) -1 else if (y > 0.5f) 1 else 0
            if (nx != hatX) { glView.setButton(2, nx < 0); glView.setButton(3, nx > 0); hatX = nx }
            if (ny != hatY) { glView.setButton(0, ny < 0); glView.setButton(1, ny > 0); hatY = ny }
            return true
        }
        return super.onGenericMotionEvent(e)
    }

    // ---------------------------------------------------------------- lifecycle

    private fun enterImmersive() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) enterImmersive()
    }

    override fun onPause() {
        super.onPause()
        if (!::glView.isInitialized) return
        glView.releaseAll()
        setPaused(true)
        glView.onPause()
    }

    override fun onResume() {
        super.onResume()
        if (!::glView.isInitialized) return
        glView.onResume()
        refreshGamepad()
        if (!menuOpen) setPaused(false)
    }

    override fun onDestroy() {
        runCatching { inputManager.unregisterInputDeviceListener(deviceListener) }
        uiHandler.removeCallbacks(fpsTick)
        if (::glView.isInitialized) {
            try { SeedlessCore.quit(); emuThread?.join(2000); SeedlessCore.release() } catch (_: Throwable) {}
        }
        super.onDestroy()
    }
}
