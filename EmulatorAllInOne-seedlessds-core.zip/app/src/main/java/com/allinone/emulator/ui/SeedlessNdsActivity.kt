package com.allinone.emulator.ui

import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.os.Handler
import android.os.Looper
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.allinone.emulator.data.SeedlessSettings
import com.allinone.emulator.input.VirtualPadView
import com.seedlessds.app.SeedlessBridge
import com.seedlessds.app.filesystem.PathCache
import com.seedlessds.core.SeedlessCore
import java.io.File

/**
 * Game NDS dengan core SeedlessDS (SeedlessCoreDS) yang ditanam di APK. Tidak memakai LibretroDroid:
 * core punya EGL/OpenGL dan audio OpenSL ES sendiri; activity ini hanya menyajikan dua layar, meneruskan tombol/sentuhan,
 * dan menyediakan menu (simpan/muat state, reset, keluar).
 */
class SeedlessNdsActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_ROM = "rom"
        private const val TAG = "SeedlessNds"
        /** attachSurface (nds_create) cukup sekali per proses, sama seperti SeedlessDS. */
        @Volatile private var inited = false
    }

    /** Pengaturan khusus SeedlessDS (terpisah dari Settings emulator lain). */
    private lateinit var cfg: SeedlessSettings
    private var fpsView: TextView? = null
    private val uiHandler = Handler(Looper.getMainLooper())
    private var lastFrames = 0L
    private var lastFpsAt = 0L
    private val fpsTick = object : Runnable {
        override fun run() {
            val now = System.nanoTime()
            val frames = glView.framesPresented
            val dt = (now - lastFpsAt) / 1e9
            if (dt > 0.0) fpsView?.text = "${Math.round((frames - lastFrames) / dt)} FPS"
            lastFrames = frames; lastFpsAt = now
            if (cfg.showFps) uiHandler.postDelayed(this, 1000)
        }
    }

    private val stateSlot get() = cfg.stateSlot

    private lateinit var glView: SeedlessGlView
    private lateinit var pad: VirtualPadView
    private lateinit var layoutEditor: ScreenLayoutEditor
    private var emuThread: Thread? = null
    private var menuOpen = false
    private var hatX = 0
    private var hatY = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        enterImmersive()

        cfg = SeedlessSettings(this)
        val romPath = intent.getStringExtra(EXTRA_ROM)
        if (romPath == null || !File(romPath).isFile || !SeedlessSupport.available) { finish(); return }

        try {
            SeedlessSupport.ensureInstalled(this)
            PathCache.setAppContext(applicationContext)
            PathCache.changeRom(romPath, romPath, File(romPath).name)
            if (!inited) {
                SeedlessCore.attachSurface(this, 1, Build.VERSION.SDK_INT)
                inited = true
            }
        } catch (t: Throwable) {
            fail("Gagal menyiapkan core SeedlessDS: ${t.javaClass.simpleName}: ${t.message}")
            return
        }

        glView = SeedlessGlView(this)
        pad = VirtualPadView(this).apply {
            opacity = cfg.padOpacity
            haptics = cfg.haptics
            ndsLayout = true
            snesLayout = true
            onKey = { key, down -> keyToBit(key).let { if (it >= 0) glView.setButton(it, down) } }
            onScreenTouch = { action, x, y ->
                glView.touch(action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_MOVE, x, y)
            }
        }
        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        root.addView(glView, FrameLayout.LayoutParams(-1, -1, Gravity.CENTER))
        root.addView(pad, FrameLayout.LayoutParams(-1, -1))
        fpsView = TextView(this).apply {
            setTextColor(Color.WHITE); setShadowLayer(4f, 0f, 0f, Color.BLACK)
            textSize = 12f; setPadding(16, 8, 16, 8); visibility = View.GONE
        }
        root.addView(fpsView, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.START))
        // Editor susunan layar kustom: menutupi game saat aktif, game tetap berjalan di belakangnya.
        layoutEditor = ScreenLayoutEditor(this, cfg).apply {
            visibility = View.GONE
            onPreview = { t, b -> glView.previewLayout(t, b) }
            onFinish = { save, t, b -> finishLayoutEdit(save, t, b) }
        }
        root.addView(layoutEditor, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)
        applyUi()   // inti belum berjalan di sini, jadi hanya bagian tampilan

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (::layoutEditor.isInitialized && layoutEditor.isActive) layoutEditor.finish(true) else showMenu()
            }
        })

        startEmulation(romPath)
    }

    private fun startEmulation(romPath: String) {
        val t = Thread {
            try {
                SeedlessCore.firmwareUser(cfg.nickname, SeedlessSupport.firmwarePacked(cfg))
                SeedlessCore.autosaveInterval(0)
                SeedlessCore.audioVolume(cfg.volume)
                SeedlessBridge.resetMemory()
                val ok = SeedlessCore.loadRom(romPath, -1, SeedlessSupport.configBits(cfg), 0, false, -1L)
                if (!ok) runOnUiThread { fail("Core SeedlessDS menolak game ini (format tidak dikenali atau ROM rusak).") }
            } catch (e: Throwable) {
                runOnUiThread { fail("Core SeedlessDS gagal berjalan: ${e.javaClass.simpleName}: ${e.message}") }
            }
        }
        t.name = "seedless-emu"; t.priority = Thread.MAX_PRIORITY
        emuThread = t; t.start()
    }

    private fun fail(msg: String) {
        if (isFinishing || isDestroyed) return
        AlertDialog.Builder(this).setTitle("NDS (SeedlessDS)").setMessage(msg)
            .setPositiveButton("OK") { _, _ -> finish() }
            .setOnCancelListener { finish() }
            .show()
    }

    // ---------------------------------------------------------------- menu

    private fun setPaused(p: Boolean) {
        try { SeedlessCore.pause(if (p) 1 else 0) } catch (_: Throwable) {}
    }

    private fun showMenu() {
        if (menuOpen || (::layoutEditor.isInitialized && layoutEditor.isActive)) return
        menuOpen = true
        setPaused(true)
        val slot = stateSlot
        val items = arrayOf("Lanjut", "Simpan state (slot $slot)", "Muat state (slot $slot)", "Reset game",
            "Pengaturan SeedlessDS", "Keluar ke library")
        AlertDialog.Builder(this).setTitle("NDS · SeedlessDS").setItems(items) { _, i ->
            when (i) {
                1 -> stateOp("Simpan") { SeedlessCore.stateSave(slot, false) }
                2 -> stateOp("Muat") { SeedlessCore.stateLoad(slot) }
                3 -> try { SeedlessCore.reset() } catch (_: Throwable) {}
                4 -> {
                    // Game tetap dijeda selama pengaturan terbuka; perubahan diterapkan langsung, lalu game lanjut saat ditutup.
                    SeedlessSettingsMenu.show(this, cfg, onChange = { applyLive() }, onClosed = { closeMenu(resume = true) },
                        onEditLayout = { startLayoutEdit() })
                    return@setItems
                }
                5 -> { closeMenu(resume = false); finish(); return@setItems }
            }
            closeMenu(resume = true)
        }.setOnCancelListener { closeMenu(resume = true) }.show()
    }

    /** Buka editor susunan layar kustom (dipanggil dari menu pengaturan; menu itu menutup dan game lanjut berjalan). */
    private fun startLayoutEdit() {
        val rects = glView.rectsForEditing()
        if (rects == null) {
            Toast.makeText(this, "Layar belum siap, coba lagi sebentar lagi", Toast.LENGTH_SHORT).show()
            return
        }
        pad.releaseTouches()
        layoutEditor.begin(rects.first, rects.second)
    }

    private fun finishLayoutEdit(save: Boolean, top: FloatArray, bot: FloatArray) {
        if (save) {
            val portrait = glView.height > glView.width
            cfg.setCustomScreen(portrait, true, top)
            cfg.setCustomScreen(portrait, false, bot)
            cfg.layoutMode = SeedlessSettings.MODE_CUSTOM
            Toast.makeText(this, "Susunan layar kustom disimpan (${if (portrait) "potret" else "lanskap"})", Toast.LENGTH_SHORT).show()
        }
        glView.previewLayout(null, null)
        glView.applyDisplay()
    }

    /** Terapkan pengaturan SeedlessDS yang bisa berlaku langsung (tanpa memulai ulang game). */
    private fun applyLive() {
        try {
            SeedlessCore.audioVolume(cfg.volume)
            SeedlessCore.applyConfig(SeedlessSupport.configBits(cfg))
        } catch (_: Throwable) {}
        applyUi()
    }

    /** Bagian pengaturan yang hanya menyangkut tampilan Android (layar, kontrol, FPS). */
    private fun applyUi() {
        if (::glView.isInitialized) glView.applyDisplay()
        if (::pad.isInitialized) { pad.opacity = cfg.padOpacity; pad.haptics = cfg.haptics }
        uiHandler.removeCallbacks(fpsTick)
        fpsView?.visibility = if (cfg.showFps) View.VISIBLE else View.GONE
        if (cfg.showFps && ::glView.isInitialized) {
            lastFrames = glView.framesPresented; lastFpsAt = System.nanoTime()
            uiHandler.postDelayed(fpsTick, 1000)
        }
    }

    private fun closeMenu(resume: Boolean) {
        menuOpen = false
        if (resume) setPaused(false)
    }

    private fun stateOp(label: String, op: () -> Boolean) {
        Thread {
            val ok = try { op() } catch (_: Throwable) { false }
            runOnUiThread { Toast.makeText(this, if (ok) "$label state: berhasil" else "$label state: gagal", Toast.LENGTH_SHORT).show() }
        }.start()
    }

    // ---------------------------------------------------------------- input

    /** Tombol Android (dari pad layar maupun gamepad fisik) ke bit core; -1 = bukan tombol game. */
    private fun keyToBit(code: Int): Int = when (code) {
        KeyEvent.KEYCODE_DPAD_UP -> 0
        KeyEvent.KEYCODE_DPAD_DOWN -> 1
        KeyEvent.KEYCODE_DPAD_LEFT -> 2
        KeyEvent.KEYCODE_DPAD_RIGHT -> 3
        KeyEvent.KEYCODE_BUTTON_A -> 4
        KeyEvent.KEYCODE_BUTTON_B -> 5
        KeyEvent.KEYCODE_BUTTON_X -> 6
        KeyEvent.KEYCODE_BUTTON_Y -> 7
        KeyEvent.KEYCODE_BUTTON_L1 -> 8
        KeyEvent.KEYCODE_BUTTON_R1 -> 9
        KeyEvent.KEYCODE_BUTTON_START -> 10
        KeyEvent.KEYCODE_BUTTON_SELECT -> 11
        else -> -1
    }

    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        val bit = keyToBit(e.keyCode)
        if (bit >= 0 && e.device?.isVirtual == false && e.repeatCount == 0 && ::glView.isInitialized) {
            glView.setButton(bit, e.action == KeyEvent.ACTION_DOWN)
            return true
        }
        if (e.keyCode == KeyEvent.KEYCODE_BUTTON_MODE && e.action == KeyEvent.ACTION_DOWN) { showMenu(); return true }
        return super.dispatchKeyEvent(e)
    }

    override fun onGenericMotionEvent(e: MotionEvent): Boolean {
        if (::glView.isInitialized && e.source and InputDevice.SOURCE_JOYSTICK != 0 && e.action == MotionEvent.ACTION_MOVE) {
            val x = e.getAxisValue(MotionEvent.AXIS_HAT_X).let { if (it == 0f) e.getAxisValue(MotionEvent.AXIS_X) else it }
            val y = e.getAxisValue(MotionEvent.AXIS_HAT_Y).let { if (it == 0f) e.getAxisValue(MotionEvent.AXIS_Y) else it }
            val nx = if (x < -0.5f) -1 else if (x > 0.5f) 1 else 0
            val ny = if (y < -0.5f) -1 else if (y > 0.5f) 1 else 0
            if (nx != hatX) { glView.setButton(2, nx < 0); glView.setButton(3, nx > 0); hatX = nx }
            if (ny != hatY) { glView.setButton(0, ny < 0); glView.setButton(1, ny > 0); hatY = ny }
            return true
        }
        return super.onGenericMotionEvent(e)
    }

    // ---------------------------------------------------------------- lifecycle

    private fun enterImmersive() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) enterImmersive()
    }

    override fun onPause() {
        super.onPause()
        if (!::glView.isInitialized) return
        glView.releaseAll()
        setPaused(true)
        glView.onPause()
    }

    override fun onResume() {
        super.onResume()
        if (!::glView.isInitialized) return
        glView.onResume()
        if (!menuOpen) setPaused(false)
    }

    override fun onDestroy() {
        uiHandler.removeCallbacks(fpsTick)
        if (::glView.isInitialized) {
            try { SeedlessCore.quit(); emuThread?.join(2000); SeedlessCore.release() } catch (_: Throwable) {}
        }
        super.onDestroy()
    }
}
