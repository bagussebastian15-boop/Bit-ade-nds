package com.allinone.emulator.data

import android.content.Context
import java.io.File

/**
 * Activity NDS berjalan di proses sendiri (":nds") supaya core native yang abort/keluar saat game ditutup tidak ikut
 * menutup library. Saat pemain sengaja keluar dari game, proses NDS ditandai "keluar bersih" di sini sebelum dimatikan,
 * sehingga library tidak salah menampilkan laporan "Game tadi menutup aplikasi" untuk keluar yang disengaja.
 */
object NdsExitMarker {
    private const val NAME = "nds_clean_exit"
    private const val KEEP = 40
    private const val WINDOW_MS = 15_000L

    private fun file(ctx: Context) = File(ctx.applicationContext.filesDir, NAME)

    /** Catat bahwa proses NDS akan keluar dengan sengaja sekarang. */
    fun mark(ctx: Context) {
        try {
            val f = file(ctx)
            val old = if (f.isFile) f.readLines().takeLast(KEEP - 1) else emptyList()
            f.writeText((old + System.currentTimeMillis().toString()).joinToString("\n"))
        } catch (_: Throwable) {}
    }

    /** Apakah keluarnya proses NDS pada [exitTimestamp] adalah keluar yang disengaja? */
    fun isCleanExit(ctx: Context, exitTimestamp: Long): Boolean = try {
        val f = file(ctx)
        f.isFile && f.readLines().any { l ->
            val t = l.trim().toLongOrNull()
            t != null && kotlin.math.abs(t - exitTimestamp) <= WINDOW_MS
        }
    } catch (_: Throwable) { false }
}
