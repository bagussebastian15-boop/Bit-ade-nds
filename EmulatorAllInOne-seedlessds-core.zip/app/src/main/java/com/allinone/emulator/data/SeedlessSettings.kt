package com.allinone.emulator.data

import android.content.Context

/**
 * Pengaturan KHUSUS core NDS SeedlessDS. Disimpan di file SharedPreferences sendiri ("seedlessds_settings"),
 * terpisah dari [Settings] yang dipakai emulator lain (libretro, arcade, DeSmuME/melonDS). Mengubah apa pun di sini
 * tidak memengaruhi emulator lain, dan sebaliknya.
 */
class SeedlessSettings(ctx: Context) {
    private val p = ctx.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    // ------------------------------------------------------------ tampilan

    /** Nama file shader .dfx (tanpa ekstensi) di folder shaders SeedlessDS. Bawaan "None" = tanpa filter. */
    var filter: String
        get() = p.getString("filter", null)?.takeIf { f -> FILTERS.any { it.first == f } } ?: DEFAULT_FILTER
        set(v) = p.edit().putString("filter", v).apply()

    /** 0 = otomatis (potret atas-bawah, lanskap kiri-kanan), 1 = selalu atas-bawah, 2 = selalu kiri-kanan, 3 = kustom. */
    var layoutMode: Int
        get() = p.getInt("layout", 0).coerceIn(0, MODE_CUSTOM)
        set(v) = p.edit().putInt("layout", v).apply()

    /** Tukar posisi layar atas dan bawah (sentuhan tetap mengikuti layar bawah). */
    var swapScreens: Boolean
        get() = p.getBoolean("swap", false)
        set(v) = p.edit().putBoolean("swap", v).apply()

    /** Tampilkan tombol melayang \u21C4 di atas game untuk menukar layar atas/bawah seketika (tanpa menjeda game). */
    var showSwapButton: Boolean
        get() = p.getBoolean("swapbtn", true)
        set(v) = p.edit().putBoolean("swapbtn", v).apply()

    /** Posisi tombol tukar layar sebagai pecahan 0..1 dari area yang bisa dijangkau; -1 = posisi bawaan (pojok kanan atas). */
    var swapButtonX: Float
        get() = p.getFloat("swapbtn_x", -1f)
        set(v) = p.edit().putFloat("swapbtn_x", v).apply()

    var swapButtonY: Float
        get() = p.getFloat("swapbtn_y", -1f)
        set(v) = p.edit().putFloat("swapbtn_y", v).apply()

    fun resetSwapButtonPosition() = p.edit().remove("swapbtn_x").remove("swapbtn_y").apply()

    /** false = jaga rasio 4:3 (bawaan), true = regangkan memenuhi area tiap layar. */
    var stretch: Boolean
        get() = p.getBoolean("stretch", false)
        set(v) = p.edit().putBoolean("stretch", v).apply()

    // ---- susunan layar KUSTOM (posisi & ukuran bebas, seperti DraStic) ----

    private fun customKey(portrait: Boolean, top: Boolean) = "cl_${if (portrait) "p" else "l"}_${if (top) "top" else "bot"}"

    /**
     * Posisi satu layar NDS pada susunan kustom untuk orientasi tertentu: [x, y, lebar, tinggi, tersembunyi(0/1)].
     * Empat angka pertama berupa pecahan dari lebar/tinggi view (jadi tetap benar di layar berukuran berbeda).
     * null = belum pernah diatur untuk orientasi itu.
     */
    fun customScreen(portrait: Boolean, top: Boolean): FloatArray? {
        val raw = p.getString(customKey(portrait, top), null) ?: return null
        val a = raw.split(',').mapNotNull { it.toFloatOrNull() }
        if (a.size != 5 || a.any { !it.isFinite() }) return null
        if (a[2] < 0.02f || a[3] < 0.02f || a[2] > 6f || a[3] > 6f) return null
        return a.toFloatArray()
    }

    fun setCustomScreen(portrait: Boolean, top: Boolean, v: FloatArray) =
        p.edit().putString(customKey(portrait, top), v.joinToString(",")).apply()

    /** Hapus semua susunan kustom tersimpan (potret dan lanskap). */
    fun clearCustom() = p.edit()
        .remove(customKey(true, true)).remove(customKey(true, false))
        .remove(customKey(false, true)).remove(customKey(false, false)).apply()

    /** Saat mengedit: true = ukuran layar dikunci ke rasio asli 4:3, false = bebas ditarik ke bentuk apa pun. */
    var customLockRatio: Boolean
        get() = p.getBoolean("cl_lock", true)
        set(v) = p.edit().putBoolean("cl_lock", v).apply()

    /** Saat mengedit: layar "menempel" ke tepi/tengah layar HP dan ke layar satunya. */
    var customMagnet: Boolean
        get() = p.getBoolean("cl_magnet", true)
        set(v) = p.edit().putBoolean("cl_magnet", v).apply()

    var showFps: Boolean
        get() = p.getBoolean("showfps", false)
        set(v) = p.edit().putBoolean("showfps", v).apply()

    // ------------------------------------------------------------ performa

    /** Nilai frame skip core (0..8). Bawaan 4 sama seperti sebelumnya. */
    var frameSkip: Int
        get() = p.getInt("frameskip", DEFAULT_FRAMESKIP).coerceIn(0, 8)
        set(v) = p.edit().putInt("frameskip", v).apply()

    /** Jumlah thread emulasi; 0 = otomatis menurut jumlah inti CPU. */
    var threads: Int
        get() = p.getInt("threads", 0).let { if (it in THREAD_CHOICES) it else 0 }
        set(v) = p.edit().putInt("threads", v).apply()

    // ------------------------------------------------------------ audio

    /** Volume utama 0..100 (0 = senyap). */
    var volume: Int
        get() = p.getInt("volume", 100).coerceIn(0, 100)
        set(v) = p.edit().putInt("volume", v).apply()

    /** Penguatan suara emulasi 0..3 (bawaan 1). Dipakai core lewat bit konfigurasi. */
    var volumeBoost: Int
        get() = p.getInt("boost", 1).coerceIn(0, 3)
        set(v) = p.edit().putInt("boost", v).apply()

    // ------------------------------------------------------------ kontrol

    var padOpacity: Int
        get() = p.getInt("padopacity", 60).coerceIn(10, 100)
        set(v) = p.edit().putInt("padopacity", v).apply()

    var haptics: Boolean
        get() = p.getBoolean("haptics", false)
        set(v) = p.edit().putBoolean("haptics", v).apply()

    /** Slot save state yang dipakai menu (1..5). */
    var stateSlot: Int
        get() = p.getInt("stateslot", 1).coerceIn(1, 5)
        set(v) = p.edit().putInt("stateslot", v).apply()

    // ------------------------------------------------------------ firmware NDS

    /** Nama pengguna di firmware NDS (maks. 10 karakter). */
    var nickname: String
        get() = p.getString("nick", null)?.takeIf { it.isNotBlank() } ?: DEFAULT_NICK
        set(v) = p.edit().putString("nick", v.trim().take(10).ifEmpty { DEFAULT_NICK }).apply()

    /** Bahasa firmware NDS: 0 Jepang, 1 Inggris, 2 Prancis, 3 Jerman, 4 Italia, 5 Spanyol. */
    var language: Int
        get() = p.getInt("lang", 1).coerceIn(0, 5)
        set(v) = p.edit().putInt("lang", v).apply()

    /** Kembalikan semua pengaturan SeedlessDS ke bawaan (tidak menyentuh pengaturan emulator lain). */
    fun resetAll() = p.edit().clear().apply()

    companion object {
        const val FILE = "seedlessds_settings"
        const val DEFAULT_FILTER = "None"
        const val MODE_CUSTOM = 3
        const val DEFAULT_FRAMESKIP = 4
        const val DEFAULT_NICK = "Player"
        val THREAD_CHOICES = listOf(0, 1, 2, 3, 4, 6, 8)
        val LANGUAGES = listOf("Jepang", "Inggris", "Prancis", "Jerman", "Italia", "Spanyol")

        /** (nama file .dfx tanpa ekstensi, label). Semuanya ikut di assets/seedlessds/shaders. */
        val FILTERS = listOf(
            "None" to "Tanpa filter (bawaan, paling ringan)",
            "Linear" to "Linear (halus)",
            "sharp_bilinear" to "Sharp bilinear (tajam tapi halus)",
            "sharp_bilinear+nds_color" to "Sharp bilinear + warna layar NDS",
            "lcd1x" to "LCD 1x (efek kisi LCD)",
            "lcd1x+nds_color" to "LCD 1x + warna layar NDS",
            "zfast_lcd" to "zfast LCD (kisi LCD ringan)",
            "zfast_lcd+nds_color" to "zfast LCD + warna layar NDS",
            "Scanline" to "Scanline (garis CRT)",
            "Scale2X" to "Scale2X (haluskan tepi piksel)",
            "HQ2X" to "HQ2X (haluskan tepi piksel, lebih berat)",
            "Quilez" to "Quilez (halus)",
            "FXAA" to "FXAA (anti-aliasing, berat)",
            "FXAA HQ" to "FXAA HQ (anti-aliasing, paling berat)",
            "SMAA" to "SMAA (anti-aliasing, berat)",
        )

        fun filterLabel(name: String) = FILTERS.firstOrNull { it.first == name }?.second ?: name
    }
}
