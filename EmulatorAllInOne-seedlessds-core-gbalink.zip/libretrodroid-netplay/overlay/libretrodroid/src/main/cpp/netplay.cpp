#include "netplay.h"

#include <arpa/inet.h>
#include <cerrno>
#include <chrono>
#include <cstdlib>
#include <cstring>
#include <fcntl.h>
#include <netinet/tcp.h>
#include <poll.h>
#include <random>
#include <sys/socket.h>
#include <unistd.h>
#include <algorithm>

#ifdef __ANDROID__
#include "log.h"
#define NPLOG(...) LOGI(__VA_ARGS__)
#else
#define NPLOG(...) ((void) 0)
#endif

namespace libretrodroid {

namespace {

constexpr uint16_t UDP_MAGIC = 0x4E50;
constexpr uint32_t TCP_MAGIC = 0x4C524E50;
constexpr uint32_t PROTOCOL_VERSION = 1;
constexpr uint8_t PKT_INPUT = 1;
constexpr uint8_t PKT_PUNCH = 3;
constexpr size_t HDR = 40;
constexpr int MAX_INPUTS_PER_PACKET = 32;
constexpr uint32_t PEER_TIMEOUT_MS = 10000;

void put16(std::vector<uint8_t> &b, uint16_t v) {
    b.push_back(v & 0xFF);
    b.push_back((v >> 8) & 0xFF);
}

void put32(std::vector<uint8_t> &b, uint32_t v) {
    for (int i = 0; i < 4; i++) b.push_back((v >> (8 * i)) & 0xFF);
}

uint16_t get16(const uint8_t *p) { return (uint16_t) (p[0] | (p[1] << 8)); }

uint32_t get32(const uint8_t *p) {
    return (uint32_t) p[0] | ((uint32_t) p[1] << 8) | ((uint32_t) p[2] << 16) | ((uint32_t) p[3] << 24);
}

bool sendAll(int fd, const void *data, size_t n) {
    auto *p = (const uint8_t *) data;
    while (n > 0) {
        ssize_t r = send(fd, p, n, MSG_NOSIGNAL);
        if (r < 0 && errno == EINTR) continue;
        if (r <= 0) return false;
        p += r;
        n -= (size_t) r;
    }
    return true;
}

bool recvAll(int fd, void *data, size_t n, int timeoutMs, const std::atomic<bool> &stop) {
    auto *p = (uint8_t *) data;
    auto deadline = std::chrono::steady_clock::now() + std::chrono::milliseconds(timeoutMs);
    while (n > 0) {
        if (stop.load() || std::chrono::steady_clock::now() > deadline) return false;
        pollfd pf{fd, POLLIN, 0};
        int pr = poll(&pf, 1, 100);
        if (pr < 0 && errno == EINTR) continue;
        if (pr <= 0) continue;
        ssize_t r = recv(fd, p, n, 0);
        if (r < 0 && (errno == EINTR || errno == EAGAIN)) continue;
        if (r <= 0) return false;
        p += r;
        n -= (size_t) r;
    }
    return true;
}

uint32_t fnv1a(const uint8_t *d, size_t n) {
    uint32_t h = 2166136261u;
    for (size_t i = 0; i < n; i++) {
        h ^= d[i];
        h *= 16777619u;
    }
    return h;
}

} // namespace

uint32_t Netplay::nowMs() {
    auto t = std::chrono::steady_clock::now().time_since_epoch();
    return (uint32_t) std::chrono::duration_cast<std::chrono::milliseconds>(t).count();
}

Netplay::Netplay(CoreHooks hooks, uint16_t port, uint32_t gameHash, int inputDelay)
    : hooks_(std::move(hooks)), port_(port), gameHash_(gameHash),
      delay_(std::max(1, std::min(8, inputDelay))) {
    std::fill(std::begin(stateFrame_), std::end(stateFrame_), -1);
    std::fill(std::begin(myHashFrame_), std::end(myHashFrame_), -1);
    std::fill(std::begin(myHash_), std::end(myHash_), 0u);
}

Netplay::~Netplay() { stop(); }

void Netplay::fail(int err) {
    error_.store(err);
    status_.store(ENDED);
}

bool Netplay::openUdp(bool bindPort) {
    udp_ = socket(AF_INET, SOCK_DGRAM, 0);
    if (udp_ < 0) return false;
    fcntl(udp_, F_SETFL, fcntl(udp_, F_GETFL, 0) | O_NONBLOCK);
    sockaddr_in a{};
    a.sin_family = AF_INET;
    a.sin_addr.s_addr = htonl(INADDR_ANY);
    a.sin_port = htons(bindPort ? port_ : 0);
    return bind(udp_, (sockaddr *) &a, sizeof(a)) == 0;
}

bool Netplay::startHost() {
    localPlayer_ = 0;
    stateBytes_ = hooks_.stateSize();
    if (stateBytes_ == 0 || stateBytes_ > MAX_STATE_BYTES) {
        fail(ERR_STATE_TOO_BIG);
        return false;
    }
    if (!openUdp(true)) {
        fail(ERR_SOCKET);
        return false;
    }
    listen_ = socket(AF_INET, SOCK_STREAM, 0);
    int one = 1;
    setsockopt(listen_, SOL_SOCKET, SO_REUSEADDR, &one, sizeof(one));
    sockaddr_in a{};
    a.sin_family = AF_INET;
    a.sin_addr.s_addr = htonl(INADDR_ANY);
    a.sin_port = htons(port_);
    if (listen_ < 0 || bind(listen_, (sockaddr *) &a, sizeof(a)) != 0 || listen(listen_, 1) != 0) {
        fail(ERR_SOCKET);
        return false;
    }
    status_.store(HOST_WAITING);
    netThread_ = std::thread([this] { netThreadHost(); });
    return true;
}

bool Netplay::startJoin(const std::string &hostIp) {
    localPlayer_ = 1;
    stateBytes_ = hooks_.stateSize();
    if (stateBytes_ == 0 || stateBytes_ > MAX_STATE_BYTES) {
        fail(ERR_STATE_TOO_BIG);
        return false;
    }
    if (!openUdp(false)) {
        fail(ERR_SOCKET);
        return false;
    }
    status_.store(CLIENT_CONNECTING);
    netThread_ = std::thread([this, hostIp] { netThreadClient(hostIp); });
    return true;
}

void Netplay::stop() {
    stopFlag_.store(true);
    if (tcp_ >= 0) {
        if (status_.load() == RUNNING) send(tcp_, "Q", 1, MSG_NOSIGNAL);
        shutdown(tcp_, SHUT_RDWR);
    }
    if (listen_ >= 0) shutdown(listen_, SHUT_RDWR);
    if (netThread_.joinable()) netThread_.join();
    if (tcp_ >= 0) close(tcp_);
    if (listen_ >= 0) close(listen_);
    if (udp_ >= 0) close(udp_);
    tcp_ = listen_ = udp_ = -1;
    status_.store(OFF);
}

bool Netplay::controlsCore() const {
    int s = status_.load();
    return s == SYNCING || s == RUNNING;
}

void Netplay::monitorTcp() {
    while (!stopFlag_.load() && status_.load() != ENDED) {
        pollfd pf{tcp_, POLLIN, 0};
        int pr = poll(&pf, 1, 200);
        if (pr > 0 && (pf.revents & (POLLIN | POLLHUP | POLLERR))) {
            char c;
            ssize_t r = recv(tcp_, &c, 1, 0);
            if (r == 0 || (r < 0 && errno != EINTR && errno != EAGAIN) || (r == 1 && c == 'Q')) {
                if (!stopFlag_.load()) fail(ERR_PEER_LEFT);
                return;
            }
        }
    }
}

void Netplay::netThreadHost() {
    // 1. tunggu client
    auto deadline = std::chrono::steady_clock::now() + std::chrono::seconds(180);
    while (!stopFlag_.load()) {
        if (std::chrono::steady_clock::now() > deadline) return fail(ERR_TIMEOUT);
        pollfd pf{listen_, POLLIN, 0};
        if (poll(&pf, 1, 200) > 0 && (pf.revents & POLLIN)) {
            tcp_ = accept(listen_, nullptr, nullptr);
            break;
        }
    }
    if (tcp_ < 0 || stopFlag_.load()) return;
    int one = 1;
    setsockopt(tcp_, IPPROTO_TCP, TCP_NODELAY, &one, sizeof(one));

    // 2. HELLO
    uint8_t hello[16];
    if (!recvAll(tcp_, hello, sizeof(hello), 8000, stopFlag_)) return fail(ERR_CONNECT);
    uint32_t code = 0;
    if (get32(hello) != TCP_MAGIC || get32(hello + 4) != PROTOCOL_VERSION) code = ERR_VERSION;
    else if (get32(hello + 8) != gameHash_ || get32(hello + 12) != (uint32_t) stateBytes_) code = ERR_GAME_MISMATCH;

    std::random_device rd;
    session_ = rd() | 1u;
    std::vector<uint8_t> reply;
    put32(reply, TCP_MAGIC);
    put32(reply, code);
    put32(reply, session_);
    put32(reply, (uint32_t) delay_);
    sendAll(tcp_, reply.data(), reply.size());
    if (code != 0) return fail((int) code);

    // 3. snapshot state host -> client
    status_.store(SYNCING);
    needSnapshot_.store(true);
    for (int i = 0; i < 2000 && !snapshotReady_.load(); i++) {
        if (stopFlag_.load()) return;
        usleep(5000);
    }
    if (!snapshotReady_.load()) return fail(ERR_TIMEOUT);
    {
        std::lock_guard<std::mutex> lock(mu_);
        std::vector<uint8_t> msg;
        put32(msg, (uint32_t) blob_.size());
        msg.insert(msg.end(), blob_.begin(), blob_.end());
        if (!sendAll(tcp_, msg.data(), msg.size())) return fail(ERR_CONNECT);
    }

    // 4. tunggu client siap
    uint8_t ready;
    if (!recvAll(tcp_, &ready, 1, 20000, stopFlag_) || ready != 'R') return fail(ERR_TIMEOUT);
    startFlag_.store(true);
    monitorTcp();
}

void Netplay::netThreadClient(std::string ip) {
    sockaddr_in a{};
    a.sin_family = AF_INET;
    a.sin_port = htons(port_);
    if (inet_pton(AF_INET, ip.c_str(), &a.sin_addr) != 1) return fail(ERR_CONNECT);
    peer_ = a;

    tcp_ = socket(AF_INET, SOCK_STREAM, 0);
    if (tcp_ < 0) return fail(ERR_SOCKET);
    int flags = fcntl(tcp_, F_GETFL, 0);
    fcntl(tcp_, F_SETFL, flags | O_NONBLOCK);
    int cr = connect(tcp_, (sockaddr *) &a, sizeof(a));
    if (cr < 0 && errno != EINPROGRESS) return fail(ERR_CONNECT);
    if (cr < 0) {
        bool ok = false;
        for (int i = 0; i < 80 && !stopFlag_.load(); i++) {
            pollfd pf{tcp_, POLLOUT, 0};
            if (poll(&pf, 1, 100) > 0) {
                int err = 0;
                socklen_t len = sizeof(err);
                getsockopt(tcp_, SOL_SOCKET, SO_ERROR, &err, &len);
                ok = (err == 0);
                break;
            }
        }
        if (stopFlag_.load()) return;
        if (!ok) return fail(ERR_CONNECT);
    }
    fcntl(tcp_, F_SETFL, flags);
    int one = 1;
    setsockopt(tcp_, IPPROTO_TCP, TCP_NODELAY, &one, sizeof(one));

    std::vector<uint8_t> hello;
    put32(hello, TCP_MAGIC);
    put32(hello, PROTOCOL_VERSION);
    put32(hello, gameHash_);
    put32(hello, (uint32_t) stateBytes_);
    if (!sendAll(tcp_, hello.data(), hello.size())) return fail(ERR_CONNECT);

    uint8_t reply[16];
    if (!recvAll(tcp_, reply, sizeof(reply), 10000, stopFlag_)) return fail(ERR_CONNECT);
    if (get32(reply) != TCP_MAGIC) return fail(ERR_VERSION);
    if (get32(reply + 4) != 0) return fail((int) get32(reply + 4));
    session_ = get32(reply + 8);
    delay_ = std::max(1, std::min(8, (int) get32(reply + 12)));
    peerKnown_.store(true);
    status_.store(SYNCING);

    uint8_t lenb[4];
    if (!recvAll(tcp_, lenb, 4, 15000, stopFlag_)) return fail(ERR_TIMEOUT);
    uint32_t len = get32(lenb);
    if (len != (uint32_t) stateBytes_) return fail(ERR_GAME_MISMATCH);
    {
        std::vector<uint8_t> tmp(len);
        if (!recvAll(tcp_, tmp.data(), len, 20000, stopFlag_)) return fail(ERR_TIMEOUT);
        std::lock_guard<std::mutex> lock(mu_);
        blob_.swap(tmp);
    }
    blobReady_.store(true);

    for (int i = 0; i < 2000 && !loaded_.load(); i++) {
        if (stopFlag_.load()) return;
        // buka lubang NAT: kirim paket UDP kosong ke host
        std::vector<uint8_t> punch;
        put16(punch, UDP_MAGIC);
        punch.push_back(PKT_PUNCH);
        put32(punch, session_);
        punch.resize(HDR, 0);
        if (i % 20 == 0) sendto(udp_, punch.data(), punch.size(), 0, (sockaddr *) &peer_, sizeof(peer_));
        usleep(5000);
    }
    if (!loaded_.load()) return fail(ERR_TIMEOUT);

    uint8_t r = 'R';
    if (!sendAll(tcp_, &r, 1)) return fail(ERR_CONNECT);
    startFlag_.store(true);
    monitorTcp();
}

// ---------------------------------------------------------------- rollback

void Netplay::beginRunning() {
    for (int i = 0; i < WINDOW; i++) {
        local_[i] = Slot{};
        remote_[i] = Slot{};
        used_[i] = Slot{};
    }
    for (int f = 0; f < delay_; f++) {
        local_[f & (WINDOW - 1)] = Slot{f, 0};
        remote_[f & (WINDOW - 1)] = Slot{f, 0};
    }
    cur_ = 0;
    verified_ = -1;
    remoteConfirmed_ = delay_ - 1;
    peerAck_ = delay_ - 1;
    peerFrame_ = 0;
    peerAdv_ = 0;
    stallCooldown_ = 0;
    lastRecvMs_ = nowMs();
    states_.assign(RING, std::vector<uint8_t>(stateBytes_));
    std::fill(std::begin(stateFrame_), std::end(stateFrame_), -1);
    inputs_[0] = inputs_[1] = 0;
    status_.store(RUNNING);
    NPLOG("netplay: mulai, pemain %d, delay %d", localPlayer_, delay_);
}

bool Netplay::remoteKnown(int frame, uint16_t &v) const {
    const Slot &s = remote_[frame & (WINDOW - 1)];
    if (s.frame != frame) return false;
    v = s.value;
    return true;
}

uint16_t Netplay::remoteFor(int frame) const {
    uint16_t v;
    if (frame <= remoteConfirmed_ && remoteKnown(frame, v)) return v;
    if (remoteKnown(remoteConfirmed_, v)) return v; // prediksi: ulang input terakhir yang pasti
    return 0;
}

void Netplay::applyInputs(int frame) {
    const Slot &l = local_[frame & (WINDOW - 1)];
    uint16_t lv = (l.frame == frame) ? l.value : 0;
    uint16_t rv = remoteFor(frame);
    inputs_[localPlayer_] = lv;
    inputs_[1 - localPlayer_] = rv;
    used_[frame & (WINDOW - 1)] = Slot{frame, rv};
}

int16_t Netplay::coreInput(unsigned port, unsigned id) const {
    if (port > 1) return 0;
    uint16_t m = inputs_[port];
    if (id == 256) return (int16_t) m; // RETRO_DEVICE_ID_JOYPAD_MASK
    if (id < 16) return (m >> id) & 1;
    return 0;
}

void Netplay::resimulateFrom(int f) {
    int idx = f % RING;
    if (stateFrame_[idx] != f) {
        desync_.store(true); // state sudah terlalu lama, tidak bisa rollback
        return;
    }
    hooks_.load(states_[idx].data(), stateBytes_);
    lastRollback_.store(cur_ - f);
    for (int g = f; g < cur_; g++) {
        if (g > f) {
            int gi = g % RING;
            hooks_.save(states_[gi].data(), stateBytes_);
            stateFrame_[gi] = g;
        }
        applyInputs(g);
        hooks_.run(false);
    }
}

void Netplay::maybeChecksum() {
    int f = (verified_ / 60) * 60;
    if (f <= 0 || f <= lastCheckedFrame_) return;
    int idx = f % RING;
    if (stateFrame_[idx] != f) return;
    lastCheckedFrame_ = f;
    uint32_t h = fnv1a(states_[idx].data(), stateBytes_);
    int k = (f / 60) & 7;
    myHashFrame_[k] = f;
    myHash_[k] = h;
    checkFrame_ = f;
    checkHash_ = h;
}

bool Netplay::tick(uint16_t localMask) {
    int s = status_.load();
    if (s == SYNCING) {
        if (localPlayer_ == 0 && needSnapshot_.load() && !snapshotReady_.load()) {
            std::lock_guard<std::mutex> lock(mu_);
            blob_.assign(stateBytes_, 0);
            if (!hooks_.save(blob_.data(), stateBytes_)) {
                fail(ERR_STATE_TOO_BIG);
                return false;
            }
            needSnapshot_.store(false);
            snapshotReady_.store(true);
        }
        if (localPlayer_ == 1 && blobReady_.load() && !loaded_.load()) {
            std::lock_guard<std::mutex> lock(mu_);
            if (!hooks_.load(blob_.data(), blob_.size())) {
                fail(ERR_GAME_MISMATCH);
                return false;
            }
            loaded_.store(true);
        }
        if (startFlag_.load() && status_.load() == SYNCING) beginRunning();
        return false;
    }
    if (s != RUNNING) return false;

    receivePackets();
    if (nowMs() - lastRecvMs_ > PEER_TIMEOUT_MS) {
        fail(ERR_TIMEOUT);
        return false;
    }

    // 1. cek tebakan: frame <= remoteConfirmed_ yang dijalankan dengan input lawan salah -> rollback
    int limit = std::min(remoteConfirmed_, cur_ - 1);
    for (int f = verified_ + 1; f <= limit; f++) {
        uint16_t real = 0;
        remoteKnown(f, real);
        const Slot &u = used_[f & (WINDOW - 1)];
        if (u.frame == f && u.value != real) {
            resimulateFrom(f);
            verified_ = limit;
            break;
        }
        verified_ = f;
    }
    maybeChecksum();

    // 2. perlu menunggu?
    bool stall = (cur_ - 1 - verified_) >= MAX_PREDICTION;
    int myAdv = cur_ - peerFrame_;
    if (stallCooldown_ > 0) stallCooldown_--;
    if (!stall && stallCooldown_ == 0 && (myAdv - peerAdv_) >= 5) {
        stall = true;
        stallCooldown_ = 12;
    }

    // 3. jalankan frame
    if (!stall) {
        int lf = cur_ + delay_;
        local_[lf & (WINDOW - 1)] = Slot{lf, localMask};

        int idx = cur_ % RING;
        hooks_.save(states_[idx].data(), stateBytes_);
        stateFrame_[idx] = cur_;
        applyInputs(cur_);
        hooks_.run(true);
        cur_++;
    }

    sendInputPacket();
    pumpOutgoing();
    return !stall;
}

// ---------------------------------------------------------------- paket UDP

void Netplay::rawSend(const std::vector<uint8_t> &pkt) {
    if (debugLossPercent > 0 && (rand() % 100) < debugLossPercent) return;
    if (debugLatencyMs > 0) {
        delayed_.push_back({nowMs() + (uint32_t) debugLatencyMs, pkt});
        return;
    }
    sendto(udp_, pkt.data(), pkt.size(), 0, (sockaddr *) &peer_, sizeof(peer_));
}

void Netplay::pumpOutgoing() {
    uint32_t now = nowMs();
    while (!delayed_.empty() && (int32_t) (now - delayed_.front().due) >= 0) {
        sendto(udp_, delayed_.front().data.data(), delayed_.front().data.size(), 0,
               (sockaddr *) &peer_, sizeof(peer_));
        delayed_.pop_front();
    }
}

void Netplay::sendInputPacket() {
    if (!peerKnown_.load()) return;
    int newest = cur_ + delay_ - 1;
    int start = peerAck_ + 1;
    if (newest - start + 1 > MAX_INPUTS_PER_PACKET) start = newest - MAX_INPUTS_PER_PACKET + 1;
    int count = std::max(0, newest - start + 1);

    uint32_t now = nowMs();
    std::vector<uint8_t> b;
    put16(b, UDP_MAGIC);
    b.push_back(PKT_INPUT);
    put32(b, session_);
    put32(b, (uint32_t) remoteConfirmed_);
    put32(b, (uint32_t) start);
    b.push_back((uint8_t) count);
    put32(b, (uint32_t) cur_);
    put32(b, (uint32_t) (cur_ - peerFrame_));
    put32(b, now ? now : 1);
    put32(b, lastPeerSendMs_);
    put32(b, (uint32_t) checkFrame_);
    put32(b, checkHash_);
    for (int i = 0; i < count; i++) {
        const Slot &s = local_[(start + i) & (WINDOW - 1)];
        put16(b, s.frame == start + i ? s.value : 0);
    }
    rawSend(b);
}

void Netplay::receivePackets() {
    uint8_t buf[512];
    for (int i = 0; i < 64; i++) {
        sockaddr_in from{};
        socklen_t fl = sizeof(from);
        ssize_t n = recvfrom(udp_, buf, sizeof(buf), 0, (sockaddr *) &from, &fl);
        if (n < 0) break;
        handlePacket(buf, (size_t) n, from);
    }
}

void Netplay::handlePacket(const uint8_t *p, size_t n, const sockaddr_in &from) {
    if (n < HDR || get16(p) != UDP_MAGIC || get32(p + 3) != session_) return;
    if (!peerKnown_.load()) {
        peer_ = from;
        peerKnown_.store(true);
    }
    lastRecvMs_ = nowMs();
    if (p[2] != PKT_INPUT) return;

    int ack = (int32_t) get32(p + 7);
    int start = (int32_t) get32(p + 11);
    int count = p[15];
    peerFrame_ = (int32_t) get32(p + 16);
    peerAdv_ = (int32_t) get32(p + 20);
    lastPeerSendMs_ = get32(p + 24);
    uint32_t echo = get32(p + 28);
    int32_t cf = (int32_t) get32(p + 32);
    uint32_t ch = get32(p + 36);

    peerAck_ = std::max(peerAck_, ack);
    if (echo != 0) {
        int rtt = (int) (nowMs() - echo);
        if (rtt >= 0 && rtt < 3000) pingMs_.store((pingMs_.load() * 3 + rtt) / 4);
    }
    if (n < HDR + (size_t) count * 2) return;
    for (int i = 0; i < count; i++) {
        int f = start + i;
        if (f > remoteConfirmed_ && f < remoteConfirmed_ + WINDOW) {
            remote_[f & (WINDOW - 1)] = Slot{f, get16(p + HDR + i * 2)};
        }
    }
    while (remote_[(remoteConfirmed_ + 1) & (WINDOW - 1)].frame == remoteConfirmed_ + 1) remoteConfirmed_++;

    if (cf > 0) {
        int k = (cf / 60) & 7;
        if (myHashFrame_[k] == cf && myHash_[k] != ch) desync_.store(true);
    }
}

} // namespace libretrodroid
