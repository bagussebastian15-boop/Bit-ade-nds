#!/usr/bin/env bash
# Menyiapkan LibretroDroid 0.13.2 (sumber) + patch netplay rollback ke folder libretrodroid-src/.
# Perlu internet sekali (git clone, termasuk submodule oboe dan libretro-common).
set -euo pipefail
cd "$(dirname "$0")/.."
DEST=libretrodroid-src
if [ ! -d "$DEST/.git" ] && [ ! -f "$DEST/libretrodroid/src/main/cpp/oboe/CMakeLists.txt" ]; then
  rm -rf "$DEST"
  for TAG in 0.13.2 v0.13.2; do
    if git clone --depth 1 --branch "$TAG" --recurse-submodules --shallow-submodules \
         https://github.com/Swordfish90/LibretroDroid.git "$DEST"; then break; fi
  done
fi
[ -f "$DEST/libretrodroid/src/main/cpp/oboe/CMakeLists.txt" ] || { echo "Submodule oboe tidak ada"; exit 1; }
# Timpa file yang diubah untuk netplay (dan build.gradle.kts modul agar cocok dengan Gradle proyek ini)
cp -r libretrodroid-netplay/overlay/libretrodroid/. "$DEST/libretrodroid/"
rm -f "$DEST/libretrodroid/build.gradle"
echo "LibretroDroid + netplay siap di $DEST/libretrodroid"
