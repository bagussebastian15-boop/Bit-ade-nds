#!/usr/bin/env bash
# Membangun core "mgba_link" (GBA Link Cable) dari sumber mGBA dengan NDK, lalu menaruhnya di
# app/src/main/jniLibs/<abi>/libmgba_link_libretro_android.so. Core ini TERPISAH dari libmgba_libretro_android.so
# (yang diunduh fetch_cores.sh), jadi core lain tidak disentuh. Butuh internet (git + libretro.h).
#   ABIS="arm64-v8a armeabi-v7a" MGBA_TAG=0.10.3 bash scripts/build_mgba_link_core.sh
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
ABIS="${ABIS:-arm64-v8a armeabi-v7a}"
MGBA_TAG="${MGBA_TAG:-0.10.3}"
NDK="${ANDROID_NDK_HOME:-${ANDROID_NDK_ROOT:-}}"
[ -z "$NDK" ] && NDK="$(ls -d "${ANDROID_HOME:-/nonexistent}"/ndk/* 2>/dev/null | sort -V | tail -n1 || true)"
[ -d "$NDK" ] || { echo "NDK tidak ditemukan (set ANDROID_NDK_HOME)"; exit 1; }
WORK="$ROOT/build_mgba_link"; mkdir -p "$WORK" "$ROOT/mgba-link/third_party"

[ -d "$WORK/mgba" ] || git clone --depth 1 --branch "$MGBA_TAG" https://github.com/mgba-emu/mgba.git "$WORK/mgba"
# Jaring pengaman: NDK sudah punya strtof_l (inline), sedangkan formatting.c mGBA mendefinisikannya lagi ->
# "redefinition of 'strtof_l'". Ganti nama definisi milik mGBA (hanya di salinan build ini, idempotent).
FMT="$WORK/mgba/src/util/formatting.c"
if [ -f "$FMT" ] && grep -qE '^float strtof_l\(' "$FMT"; then
  sed -i -E 's/^float strtof_l\(/float mgba_unused_strtof_l(/' "$FMT"
fi

[ -s "$ROOT/mgba-link/third_party/libretro.h" ] || curl -fsSL --retry 5 \
  https://raw.githubusercontent.com/libretro/libretro-common/master/include/libretro.h -o "$ROOT/mgba-link/third_party/libretro.h"

for abi in $ABIS; do
  echo "== mgba_link: $abi =="
  LOG="$WORK/$abi.log"
  report() {  # tampilkan baris error saja (log penuh ada di artifact "mgba-link-log")
    {
      echo "### Core mGBA Link gagal ($abi): $1"
      echo '```'
      grep -nE "error|Error|undefined|not found|No such file|fatal" "$LOG" | grep -v "Werror" | head -40
      echo '```'
    } | tee -a "${GITHUB_STEP_SUMMARY:-/dev/null}"
  }
  if ! cmake -S "$ROOT/mgba-link" -B "$WORK/$abi" -G "Unix Makefiles" \
      -DCMAKE_TOOLCHAIN_FILE="$NDK/build/cmake/android.toolchain.cmake" -DANDROID_ABI="$abi" -DANDROID_PLATFORM=android-21 \
      -DCMAKE_BUILD_TYPE=Release -DMGBA_SRC="$WORK/mgba" > "$LOG" 2>&1; then
    report "konfigurasi CMake"; exit 1
  fi
  if ! cmake --build "$WORK/$abi" --target mgba_link_libretro -j"$(nproc)" >> "$LOG" 2>&1; then
    report "kompilasi"; exit 1
  fi
  out="$(find "$WORK/$abi" -name libmgba_link_libretro_android.so | head -n1)"
  [ -s "$out" ] || { echo "Hasil build tidak ditemukan untuk $abi"; exit 1; }
  mkdir -p "$ROOT/app/src/main/jniLibs/$abi"
  cp -f "$out" "$ROOT/app/src/main/jniLibs/$abi/libmgba_link_libretro_android.so"
  echo "-> app/src/main/jniLibs/$abi/libmgba_link_libretro_android.so"
done
