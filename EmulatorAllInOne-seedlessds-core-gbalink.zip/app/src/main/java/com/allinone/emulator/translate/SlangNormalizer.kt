package com.allinone.emulator.translate

import java.io.File

/**
 * Penerjemah on-device sering salah pada slang. Solusinya: slang/idiom diubah dulu menjadi Inggris baku
 * (mis. "gonna" -> "going to", "knackered" -> "exhausted"), baru diterjemahkan ke Indonesia.
 *
 * Kamus pribadi: buat file slang_user.txt di folder data aplikasi (Android/data/com.allinone.emulator/files/),
 * satu aturan per baris dengan format  slang=padanan baku  (baris berawalan # diabaikan). Aturan pribadi didahulukan.
 */
object SlangNormalizer {

    /** Kamus gabungan satu lintasan: tiap posisi teks diganti paling banyak SEKALI (tidak ada penggantian berantai). */
    private class Dict(val map: Map<String, String>, val re: Regex?)

    private val builtin: Dict by lazy { build(parse(BUILTIN)) }

    private var merged: Dict? = null
    private var mergedStamp = -2L

    /** Kamus bawaan + kamus pribadi (bila ada). Aturan pribadi menggantikan aturan bawaan untuk kata yang sama. */
    private fun dictFor(f: File?): Dict {
        if (f == null || !f.exists()) return builtin
        val stamp = f.lastModified()
        val cur = merged
        if (cur != null && mergedStamp == stamp) return cur
        val m = LinkedHashMap<String, String>(builtin.map)
        try { for ((k, v) in parse(f.readText())) m[k] = v } catch (_: Exception) {}
        return build(m).also { merged = it; mergedStamp = stamp }
    }

    fun normalize(text: String, userFile: File?): String {
        var s = text.replace('\u2019', '\'').replace('\u2018', '\'').replace('`', '\'').replace('\u00B4', '\'')
        // "goin'" -> "going", "nothin'" -> "nothing"
        s = Regex("\\b([A-Za-z]{2,})in'(?![A-Za-z])").replace(s) { it.groupValues[1] + "ing" }
        return apply(s, dictFor(userFile))
    }

    private fun apply(s: String, d: Dict): String {
        val re = d.re ?: return s
        return re.replace(s) { m ->
            val key = m.value.lowercase().replace(Regex("\\s+"), " ")
            val rep = d.map[key] ?: return@replace m.value
            if (m.value.isNotEmpty() && m.value[0].isUpperCase() && rep.isNotEmpty())
                rep.replaceFirstChar { it.uppercase() } else rep
        }
    }

    private fun parse(src: String): List<Pair<String, String>> =
        src.lineSequence()
            .map { it.trim() }
            .filter { it.isNotEmpty() && !it.startsWith("#") && it.contains('=') }
            .map { it.substringBefore('=').trim().lowercase() to it.substringAfter('=').trim() }
            .filter { it.first.isNotEmpty() }
            .toList()

    private fun build(rules: List<Pair<String, String>>): Dict = build(rules.toMap())

    private fun build(rules: Map<String, String>): Dict {
        if (rules.isEmpty()) return Dict(rules, null)
        // Frasa panjang dicoba lebih dulu; spasi dalam frasa cocok dengan spasi apa pun.
        val keys = rules.keys.sortedByDescending { it.length }
        val alt = keys.joinToString("|") { k -> k.split(' ').filter { it.isNotEmpty() }.joinToString("\\s+") { Regex.escape(it) } }
        return Dict(rules, Regex("(?<![A-Za-z'])(?:$alt)(?![A-Za-z'])", RegexOption.IGNORE_CASE))
    }

    private const val BUILTIN = """
# ---- idiom yang sering diterjemahkan kata per kata ----
game over, man=it is all over, buddy
the end=the end of the story
have a nice trip=have a good journey
# ---- kontraksi & ucapan lisan (AS) ----
gonna=going to
wanna=want to
gotta=have to
hafta=have to
gimme=give me
lemme=let me
dunno=don't know
kinda=kind of
sorta=sort of
outta=out of
lotta=lot of
whatcha=what are you
gotcha=understood
y'all=you all
ya'll=you all
c'mon=come on
'cause=because
cuz=because
'til=until
'em=them
tho=though
thru=through
nite=night
ya=you
i ain't=I am not
you ain't=you are not
we ain't=we are not
they ain't=they are not
he ain't=he is not
she ain't=she is not
it ain't=it is not
ain't=is not
ain't it=isn't it
fixin' to=about to
fixing to=about to
# ---- slang Amerika ----
dude=my friend
bro=my friend
kiddo=child
cop=police officer
cops=police officers
hella=very
freakin=very
freaking=very
freakin'=very
no biggie=it is not a big deal
my bad=my mistake
heads up=warning
hang out=spend time together
hanging out=spending time together
chill out=calm down
freak out=panic
freaking out=panicking
ticked off=angry
pissed off=very angry
screw up=make a mistake
screwed up=made a mistake
screwed=in trouble
bummer=too bad
gee=wow
golly=wow
whoa=wow
yikes=oh no
phew=what a relief
holy cow=wow
holy smoke=wow
holy moly=wow
howdy=hello
hiya=hello
g'day=hello
you bet=of course
for real=seriously
no way=impossible
what's up=how are you
wassup=how are you
sup=how are you
hang in there=be strong
hold your horses=wait a moment
take it easy=relax
give me a break=be reasonable
that sucks=that is terrible
nailed it=did it perfectly
rip off=cheat
ripped off=cheated
beat it=go away
scram=go away
get lost=go away
shut up=be quiet
shut it=be quiet
ma'am=madam
# ---- slang Britania ----
first mate=first mate
mate=friend
bloke=man
lad=boy
lass=girl
chap=man
old chap=my friend
guv=boss
guvnor=boss
bloody hell=damn it
bloody good=very good
bloody brilliant=very good
bloody idiot=complete idiot
blimey=wow
cor blimey=wow
crikey=wow
cheers=thank you
innit=isn't it
knackered=exhausted
gutted=devastated
chuffed=very pleased
daft=stupid
barmy=crazy
bonkers=crazy
quid=pounds
loo=toilet
lorry=truck
telly=television
nicked=stole
bollocks=nonsense
sod off=go away
piss off=go away
bugger off=go away
bugger=damn
ta-ra=goodbye
oi=hey
wanker=idiot
tosser=idiot
skint=broke
cuppa=cup of tea
peckish=hungry
gobsmacked=astonished
dodgy=suspicious
naff=tacky
gaff=house
fancy a=would you like a
jolly good=very good
cock up=mistake
cocked up=made a mistake
taking the mickey=making fun
take the mickey=make fun
bob's your uncle=and that is all
on the dole=unemployed
blighter=rascal
# ---- idiom umum ----
piece of cake=very easy
kick the bucket=die
kicked the bucket=died
break a leg=good luck
spill the beans=reveal the secret
spilled the beans=revealed the secret
under the weather=sick
an arm and a leg=a lot of money
hit the sack=go to sleep
hit the hay=go to sleep
call it a day=stop for today
let the cat out of the bag=reveal the secret
bite the bullet=endure it bravely
cut me some slack=be patient with me
cut some slack=be patient
once in a blue moon=very rarely
raining cats and dogs=raining heavily
the last straw=the final limit
throw in the towel=give up
pull someone's leg=joke with someone
pulling my leg=joking with me
it's a deal=agreed
fair enough=understood
fair dinkum=genuine
"""
}
