package com.allinone.emulator.data

import java.io.File

/**
 * Core mGBA kedua khusus Link Cable (dua GBA virtual dalam satu core). Terpisah total dari core GBA biasa:
 * file .so sendiri, file state sendiri, dan save sendiri, jadi jalur GBA/SNES/Genesis/NDS/arcade tidak tersentuh.
 */
object GbaLink {
    const val CORE = "libmgba_link_libretro_android.so"

    /** Akhiran nama file state/save agar tidak tercampur dengan core mGBA biasa. */
    const val STATE_TAG = ".link"

    /**
     * true = GBA 1 dan GBA 2 dijalankan di dua thread (lebih cepat, tetapi BELUM terbukti sinkron di dua HP).
     * false = berurutan seperti versi lama yang sudah sinkron. Ubah lalu build ulang untuk membandingkan.
     */
    const val PARALLEL = false

    /**
     * Salin SATU ARAH save GBA biasa ke save Link saat save Link belum ada (supaya progres game tidak hilang).
     * Save biasa tidak pernah ditulis dari mode Link.
     */
    fun seedSave(linkSave: File, normalSave: File) {
        try {
            if (!linkSave.exists() && normalSave.exists()) {
                linkSave.parentFile?.mkdirs()
                normalSave.copyTo(linkSave, overwrite = false)
            }
        } catch (_: Exception) {}
    }
}
