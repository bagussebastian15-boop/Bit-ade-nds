package com.allinone.emulator.net;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Jembatan paket IP (TUN Android = layer 3) dengan frame Ethernet (jaringan ZeroTier = layer 2), khusus IPv4.
 * Menangani ARP: mencari MAC tujuan, menjawab ARP untuk IP kita, dan menahan paket sampai MAC diketahui.
 * Dipisah dari kode yang memakai library ZeroTier supaya bisa diuji di komputer (tests/run_ethbridge_test.sh).
 */
public final class EthBridge {

    public interface Sender { void sendFrame(long dstMac, long srcMac, int etherType, byte[] payload); }
    public interface TunWriter { void write(byte[] buf, int off, int len); }

    public static final long BROADCAST = 0xFFFFFFFFFFFFL;
    public static final int ETH_IPV4 = 0x0800;
    public static final int ETH_ARP = 0x0806;
    private static final int MAX_PENDING = 8;
    private static final long ARP_RETRY_MS = 250;

    private final long myMac;
    private final int myIp;
    private final int mask;
    private final Sender sender;
    private final TunWriter tun;
    private final Map<Integer, Long> arp = new HashMap<>();
    private final Map<Integer, ArrayDeque<byte[]>> pending = new HashMap<>();
    private final Map<Integer, Long> lastRequest = new HashMap<>();

    public EthBridge(long myMac, int myIp, int prefix, Sender sender, TunWriter tun) {
        this.myMac = myMac;
        this.myIp = myIp;
        this.mask = prefix <= 0 ? 0 : (prefix >= 32 ? -1 : -1 << (32 - prefix));
        this.sender = sender;
        this.tun = tun;
    }

    public int ip() { return myIp; }
    public int prefixMask() { return mask; }

    public static int ipToInt(byte[] b, int off) {
        return ((b[off] & 0xff) << 24) | ((b[off + 1] & 0xff) << 16) | ((b[off + 2] & 0xff) << 8) | (b[off + 3] & 0xff);
    }

    public static int parseIp(String s) {
        String[] p = s.split("\\.");
        if (p.length != 4) throw new IllegalArgumentException(s);
        int v = 0;
        for (String x : p) v = (v << 8) | Integer.parseInt(x);
        return v;
    }

    private boolean isBroadcast(int dst) { return mask != 0 && (dst & ~mask) == ~mask; }
    private static boolean isMulticast(int dst) { return (dst >>> 28) == 0xE; }
    private boolean inSubnet(int ip) { return (ip & mask) == (myIp & mask); }

    /** True bila paket IP ini harus dikirim lewat jaringan ini (tujuan di subnet, multicast, atau broadcast). */
    public boolean accepts(byte[] pkt, int len) {
        if (len < 20 || (pkt[0] >> 4) != 4) return false;
        int dst = ipToInt(pkt, 16);
        return dst != myIp && (inSubnet(dst) || isMulticast(dst) || dst == -1);
    }

    /** Paket IP dari TUN (aplikasi kita) menuju jaringan ZeroTier. */
    public void fromTun(byte[] pkt, int len) {
        if (!accepts(pkt, len)) return;
        int dst = ipToInt(pkt, 16);
        byte[] ip = Arrays.copyOf(pkt, len);
        List<Runnable> out = new ArrayList<>();
        synchronized (this) {
            long dmac;
            if (dst == -1 || isBroadcast(dst)) dmac = BROADCAST;
            else if (isMulticast(dst)) dmac = 0x01005E000000L | (dst & 0x7FFFFF);
            else {
                Long known = arp.get(dst);
                if (known == null) {
                    ArrayDeque<byte[]> q = pending.computeIfAbsent(dst, k -> new ArrayDeque<>());
                    if (q.size() >= MAX_PENDING) q.pollFirst();
                    q.addLast(ip);
                    long now = System.currentTimeMillis();
                    Long last = lastRequest.get(dst);
                    if (last == null || now - last >= ARP_RETRY_MS) {
                        lastRequest.put(dst, now);
                        final byte[] req = arpPacket(1, myMac, myIp, 0L, dst);
                        out.add(() -> sender.sendFrame(BROADCAST, myMac, ETH_ARP, req));
                    }
                    flush(out);
                    return;
                }
                dmac = known;
            }
            final long d = dmac;
            out.add(() -> sender.sendFrame(d, myMac, ETH_IPV4, ip));
        }
        flush(out);
    }

    /** Frame dari jaringan ZeroTier (payload setelah header Ethernet). */
    public void fromNet(long srcMac, long dstMac, int etherType, byte[] frame) {
        if (frame == null) return;
        List<Runnable> out = new ArrayList<>();
        if (etherType == ETH_ARP) {
            if (frame.length < 28) return;
            int oper = ((frame[6] & 0xff) << 8) | (frame[7] & 0xff);
            long sha = mac(frame, 8);
            int spa = ipToInt(frame, 14);
            int tpa = ipToInt(frame, 24);
            if (spa == 0 || spa == myIp) return;
            synchronized (this) {
                arp.put(spa, sha);
                ArrayDeque<byte[]> q = pending.remove(spa);
                if (q != null) for (byte[] p : q) out.add(() -> sender.sendFrame(sha, myMac, ETH_IPV4, p));
                if (oper == 1 && tpa == myIp) {
                    final byte[] rep = arpPacket(2, myMac, myIp, sha, spa);
                    out.add(() -> sender.sendFrame(sha, myMac, ETH_ARP, rep));
                }
            }
            flush(out);
        } else if (etherType == ETH_IPV4) {
            if (frame.length < 20 || (frame[0] >> 4) != 4) return;
            int dst = ipToInt(frame, 16);
            if (!(dst == myIp || dst == -1 || isBroadcast(dst) || isMulticast(dst))) return;
            int src = ipToInt(frame, 12);
            if (src != myIp && inSubnet(src)) synchronized (this) { arp.putIfAbsent(src, srcMac); }
            int total = ((frame[2] & 0xff) << 8) | (frame[3] & 0xff);   // buang padding Ethernet
            int n = (total >= 20 && total <= frame.length) ? total : frame.length;
            tun.write(frame, 0, n);
        }
    }

    /** True bila IP ini berada di subnet jaringan ini (diagnosis). */
    public boolean covers(int ip) { return inSubnet(ip); }

    /** MAC yang sudah dikenal untuk IP ini lewat ARP, atau 0 bila belum ada jawaban (diagnosis). */
    public synchronized long macOf(int ip) {
        Long m = arp.get(ip);
        return m == null ? 0L : m;
    }

    /** Kirim satu ARP request untuk IP ini tanpa paket data (diagnosis: apakah node itu menjawab di jaringan ZeroTier). */
    public void probe(int ip) {
        final byte[] req = arpPacket(1, myMac, myIp, 0L, ip);
        sender.sendFrame(BROADCAST, myMac, ETH_ARP, req);
    }

    private static void flush(List<Runnable> out) { for (Runnable r : out) r.run(); }

    private static long mac(byte[] b, int off) {
        long v = 0;
        for (int i = 0; i < 6; i++) v = (v << 8) | (b[off + i] & 0xff);
        return v;
    }

    private static void putMac(byte[] b, int off, long m) {
        for (int i = 5; i >= 0; i--) { b[off + i] = (byte) m; m >>>= 8; }
    }

    private static void putIp(byte[] b, int off, int ip) {
        b[off] = (byte) (ip >>> 24); b[off + 1] = (byte) (ip >>> 16); b[off + 2] = (byte) (ip >>> 8); b[off + 3] = (byte) ip;
    }

    private static byte[] arpPacket(int oper, long sha, int spa, long tha, int tpa) {
        byte[] p = new byte[28];
        p[1] = 1;                 // hardware type: Ethernet
        p[2] = 0x08; p[3] = 0x00; // protocol: IPv4
        p[4] = 6; p[5] = 4;
        p[7] = (byte) oper;
        putMac(p, 8, sha); putIp(p, 14, spa);
        putMac(p, 18, tha); putIp(p, 24, tpa);
        return p;
    }
}
