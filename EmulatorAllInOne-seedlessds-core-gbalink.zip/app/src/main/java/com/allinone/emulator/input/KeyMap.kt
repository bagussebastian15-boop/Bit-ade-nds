package com.allinone.emulator.input

import android.content.Context
import android.view.KeyEvent

/**
 * Pintasan (hotkey) controller eksternal. Tombol controller TIDAK lagi dipetakan ulang ke D-pad/A/B dst.
 * (semua tombol game diteruskan apa adanya); sebaliknya, satu tombol fisik bisa dipasang ke sebuah PERINTAH aplikasi.
 * Tombol yang dipasang ke perintah tidak dikirim ke game.
 */
object KeyMap {
    enum class Action(val label: String, val default: Int?) {
        SAVE_STATE("Simpan state (slot 1)", null),
        LOAD_STATE("Muat state (slot 1)", null),
        SETTINGS("Buka pengaturan", null),
        LIBRARY("Kembali ke library", null),
        EXIT_APP("Keluar aplikasi", null),
        TRANSLATE("Terjemahkan layar", KeyEvent.KEYCODE_BUTTON_THUMBR)
    }

    private fun p(c: Context) = c.getSharedPreferences("hotkeys", Context.MODE_PRIVATE)

    private const val NONE = -1

    /** Tombol fisik yang sekarang dipasang ke [a]; null bila kosong. */
    fun keyFor(c: Context, a: Action): Int? {
        val prefs = p(c)
        val v = if (prefs.contains(a.name)) prefs.getInt(a.name, NONE) else (a.default ?: NONE)
        return if (v == NONE) null else v
    }

    /** Perintah yang dijalankan tombol fisik [keyCode]; null bila tombol itu bukan pintasan (diteruskan ke game). */
    fun actionFor(c: Context, keyCode: Int): Action? = Action.values().firstOrNull { keyFor(c, it) == keyCode }

    /** Pasang [keyCode] ke [a]; perintah lain yang memakai tombol yang sama dikosongkan. */
    fun bind(c: Context, a: Action, keyCode: Int) {
        val e = p(c).edit()
        Action.values().filter { it != a && keyFor(c, it) == keyCode }.forEach { e.putInt(it.name, NONE) }
        e.putInt(a.name, keyCode).apply()
    }

    fun unbind(c: Context, a: Action) { p(c).edit().putInt(a.name, NONE).apply() }

    /** Kembalikan semua pintasan ke bawaan. */
    fun clearAll(c: Context) = p(c).edit().clear().apply()
}
