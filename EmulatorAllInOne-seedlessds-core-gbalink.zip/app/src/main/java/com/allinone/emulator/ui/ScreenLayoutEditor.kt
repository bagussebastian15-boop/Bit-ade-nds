package com.allinone.emulator.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.RectF
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import com.allinone.emulator.data.SeedlessSettings
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Editor susunan layar NDS bebas (mirip DraStic). Menutupi seluruh layar game; game tetap berjalan di belakangnya
 * sehingga perubahan langsung terlihat.
 *
 *  - Seret di dalam layar        : pindahkan
 *  - Seret titik sudut           : ubah ukuran (rasio 4:3 terkunci, atau bebas bila kunci dimatikan)
 *  - Cubit dua jari              : perbesar / perkecil layar terpilih
 *  - Bilah tombol                : pilih layar, susunan awal, rasio, magnet, sembunyikan, tukar, lebar penuh
 *
 * Semua koordinat di sini dalam piksel view (sama dengan SeedlessGlView). Ke luar (pratinjau & hasil) dikirim dalam
 * pecahan ternormalisasi [x, y, lebar, tinggi, tersembunyi 0/1], format yang sama dengan SeedlessSettings.customScreen.
 */
class ScreenLayoutEditor(ctx: Context, private val cfg: SeedlessSettings) : FrameLayout(ctx) {

    /** Dipanggil pada setiap perubahan, untuk pratinjau langsung di layar game. Argumen: (atas, bawah). */
    var onPreview: ((FloatArray, FloatArray) -> Unit)? = null

    /** Dipanggil saat editor ditutup. Argumen: (simpan?, atas, bawah). */
    var onFinish: ((Boolean, FloatArray, FloatArray) -> Unit)? = null

    var isActive = false
        private set

    private val dp = ctx.resources.displayMetrics.density
    private val top = RectF()
    private val bot = RectF()
    private var topHide = false
    private var botHide = false
    private var sel = 1                         // 0 = layar atas NDS, 1 = layar bawah NDS (sentuh)
    private var pending: Pair<FloatArray, FloatArray>? = null

    private val board = Board(ctx)
    private val bar = LinearLayout(ctx)
    private val scroll = HorizontalScrollView(ctx)
    private var barOnTop = true

    private lateinit var btnSelect: Button
    private lateinit var btnLock: Button
    private lateinit var btnMagnet: Button
    private lateinit var btnHide: Button

    init {
        addView(board, LayoutParams(-1, -1))

        bar.orientation = LinearLayout.HORIZONTAL
        bar.setBackgroundColor(0xDD1E1E1E.toInt())
        bar.setPadding(px(6), px(4), px(6), px(4))
        scroll.isHorizontalScrollBarEnabled = false
        scroll.addView(bar, LayoutParams(-2, -2))
        addView(scroll, LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { topMargin = px(10) })

        button("Selesai") { finish(true) }
        button("Batal") { finish(false) }
        btnSelect = button("") { sel = 1 - sel; refresh(); board.invalidate() }
        button("Susunan awal") { choosePreset() }
        btnLock = button("") {
            cfg.customLockRatio = !cfg.customLockRatio
            if (cfg.customLockRatio) forceRatio(rectOf(sel))
            refresh(); changed()
        }
        btnMagnet = button("") { cfg.customMagnet = !cfg.customMagnet; refresh() }
        btnHide = button("") {
            if (isHidden(sel)) setHidden(sel, false)
            else if (isHidden(1 - sel)) Toast.makeText(context, "Minimal satu layar harus tampil", Toast.LENGTH_SHORT).show()
            else setHidden(sel, true)
            refresh(); changed()
        }
        button("Tukar posisi") {
            val t = RectF(top); top.set(bot); bot.set(t)
            val h = topHide; topHide = botHide; botHide = h
            refresh(); changed()
        }
        button("Lebar penuh") { fullWidth(rectOf(sel)); changed() }
        button("Bilah ↕") {
            barOnTop = !barOnTop
            scroll.layoutParams = LayoutParams(-2, -2, (if (barOnTop) Gravity.TOP else Gravity.BOTTOM) or Gravity.CENTER_HORIZONTAL)
                .apply { if (barOnTop) topMargin = px(10) else bottomMargin = px(10) }
        }
        refresh()
    }

    // ------------------------------------------------------------------ siklus

    /** Mulai mengedit dari susunan [t] (atas) dan [b] (bawah) ternormalisasi. */
    fun begin(t: FloatArray, b: FloatArray) {
        pending = t to b
        sel = 1
        visibility = VISIBLE
        if (width > 0 && height > 0) applyPending()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        if (pending != null && w > 0 && h > 0) applyPending()
        else if (isActive && ow > 0 && oh > 0 && (w != ow || h != oh)) finish(false)   // layar diputar: batalkan
    }

    private fun applyPending() {
        val (t, b) = pending ?: return
        pending = null
        val w = width.toFloat(); val h = height.toFloat()
        top.set(t[0] * w, t[1] * h, (t[0] + t[2]) * w, (t[1] + t[3]) * h); topHide = t[4] > 0.5f
        bot.set(b[0] * w, b[1] * h, (b[0] + b[2]) * w, (b[1] + b[3]) * h); botHide = b[4] > 0.5f
        isActive = true
        refresh()
        board.invalidate()
        changed(preview = true)
        Toast.makeText(context, "Seret layar untuk memindah · tarik sudut atau cubit untuk mengubah ukuran", Toast.LENGTH_LONG).show()
    }

    /** Tutup editor. Tombol Kembali memanggil finish(true). */
    fun finish(save: Boolean) {
        if (!isActive) return
        isActive = false
        visibility = GONE
        onFinish?.invoke(save, norm(top, topHide), norm(bot, botHide))
    }

    // ------------------------------------------------------------------ model

    private fun px(v: Int) = (v * dp).roundToInt()
    private fun rectOf(i: Int) = if (i == 0) top else bot
    private fun isHidden(i: Int) = if (i == 0) topHide else botHide
    private fun setHidden(i: Int, v: Boolean) { if (i == 0) topHide = v else botHide = v }

    private fun norm(r: RectF, hide: Boolean): FloatArray {
        val w = max(width, 1).toFloat(); val h = max(height, 1).toFloat()
        return floatArrayOf(r.left / w, r.top / h, r.width() / w, r.height() / h, if (hide) 1f else 0f)
    }

    private fun changed(preview: Boolean = true) {
        board.invalidate()
        if (preview) onPreview?.invoke(norm(top, topHide), norm(bot, botHide))
    }

    private val minW get() = 56f * dp
    private val maxW get() = 3f * width

    /** Jaga agar pusat layar tetap berada di dalam view (layar tidak bisa "hilang" sepenuhnya). */
    private fun clampCenter(r: RectF) {
        val cx = r.centerX().coerceIn(0f, width.toFloat())
        val cy = r.centerY().coerceIn(0f, height.toFloat())
        r.offset(cx - r.centerX(), cy - r.centerY())
    }

    private fun forceRatio(r: RectF) {
        val cx = r.centerX(); val cy = r.centerY()
        val w = r.width().coerceIn(minW, maxW); val h = w / ASPECT
        r.set(cx - w / 2f, cy - h / 2f, cx + w / 2f, cy + h / 2f)
        clampCenter(r)
    }

    private fun fullWidth(r: RectF) {
        val w = width.toFloat(); val h = w / ASPECT
        r.set(0f, r.top, w, r.top + h)
        clampCenter(r)
    }

    private fun fitIn(maxWidth: Float, maxHeight: Float): Pair<Float, Float> =
        if (maxWidth / maxHeight > ASPECT) Pair(maxHeight * ASPECT, maxHeight) else Pair(maxWidth, maxWidth / ASPECT)

    private fun choosePreset() {
        val items = arrayOf(
            "Atas-bawah",
            "Kiri-kanan",
            "Layar atas besar, layar bawah kecil di pojok",
            "Layar bawah besar, layar atas kecil di pojok"
        )
        AlertDialog.Builder(context).setTitle("Susunan awal").setItems(items) { _, i ->
            applyPreset(i)
        }.setNegativeButton("Batal", null).show()
    }

    private fun applyPreset(i: Int) {
        val w = width.toFloat(); val h = height.toFloat()
        topHide = false; botHide = false
        when (i) {
            0 -> {
                val (sw, sh) = fitIn(w, h / 2f)
                val x = (w - sw) / 2f
                val y = if (h > w) 0f else (h - 2f * sh) / 2f
                top.set(x, y, x + sw, y + sh); bot.set(x, y + sh, x + sw, y + 2f * sh)
            }
            1 -> {
                val (sw, sh) = fitIn(w / 2f, h)
                val y = (h - sh) / 2f
                val lx = (w / 2f - sw) / 2f; val rx = w / 2f + lx
                top.set(lx, y, lx + sw, y + sh); bot.set(rx, y, rx + sw, y + sh)
            }
            else -> {
                val (bw, bh) = fitIn(w, h)
                val bigL = (w - bw) / 2f; val bigT = (h - bh) / 2f
                val sw = min(w * 0.32f, bw * 0.4f); val sh = sw / ASPECT
                val sx = bigL + bw - sw; val sy = bigT + bh - sh
                val big = RectF(bigL, bigT, bigL + bw, bigT + bh)
                val small = RectF(sx, sy, sx + sw, sy + sh)
                if (i == 2) { top.set(big); bot.set(small); sel = 1 } else { bot.set(big); top.set(small); sel = 0 }
            }
        }
        refresh(); changed()
    }

    private fun refresh() {
        btnSelect.text = "Pilih: ${if (sel == 0) "ATAS" else "BAWAH"}"
        btnLock.text = if (cfg.customLockRatio) "Rasio 4:3: kunci" else "Rasio: bebas"
        btnMagnet.text = "Magnet: ${if (cfg.customMagnet) "ON" else "OFF"}"
        btnHide.text = if (isHidden(sel)) "Tampilkan" else "Sembunyikan"
    }

    private fun button(label: String, onClick: () -> Unit): Button {
        val b = Button(context)
        b.text = label
        b.isAllCaps = false
        b.textSize = 12f
        b.minWidth = 0; b.minimumWidth = 0; b.minHeight = 0; b.minimumHeight = 0
        b.setPadding(px(12), px(8), px(12), px(8))
        b.setOnClickListener { onClick() }
        bar.addView(b, LinearLayout.LayoutParams(-2, -2).apply { marginEnd = px(4) })
        return b
    }

    // ------------------------------------------------------------------ kanvas & sentuhan

    private enum class Mode { NONE, MOVE, RESIZE, PINCH }

    private inner class Board(ctx: Context) : View(ctx) {
        private val fill = Paint()
        private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
        private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0xFFFFFFFF.toInt(); textAlign = Paint.Align.CENTER
            setShadowLayer(4f * dp, 0f, 0f, 0xFF000000.toInt())
        }
        private val dash = DashPathEffect(floatArrayOf(10f * dp, 6f * dp), 0f)
        private val dot = Paint(Paint.ANTI_ALIAS_FLAG)
        private val guide = Paint().apply { color = 0xFFFF4081.toInt(); strokeWidth = 1.5f * dp }

        private var mode = Mode.NONE
        private var downX = 0f
        private var downY = 0f
        private val startRect = RectF()
        private var corner = 0                 // 0 kiri-atas, 1 kanan-atas, 2 kanan-bawah, 3 kiri-bawah
        private var grabDx = 0f
        private var grabDy = 0f
        private var pinchD0 = 1f
        private var guideX = -1f
        private var guideY = -1f

        override fun onDraw(c: Canvas) {
            drawScreen(c, 1 - sel)
            drawScreen(c, sel)
            if (guideX >= 0f) c.drawLine(guideX, 0f, guideX, height.toFloat(), guide)
            if (guideY >= 0f) c.drawLine(0f, guideY, width.toFloat(), guideY, guide)
        }

        private fun drawScreen(c: Canvas, i: Int) {
            val r = rectOf(i)
            val hid = isHidden(i)
            val selected = i == sel
            fill.color = when { hid -> 0x30000000; selected -> 0x442196F3; else -> 0x22FFFFFF }
            c.drawRect(r, fill)
            stroke.color = if (selected) 0xFF2196F3.toInt() else 0xCCFFFFFF.toInt()
            stroke.strokeWidth = (if (selected) 3f else 1.5f) * dp
            stroke.pathEffect = if (hid) dash else null
            c.drawRect(r, stroke)

            text.textSize = 16f * dp
            c.drawText(if (i == 0) "ATAS" else "BAWAH (sentuh)", r.centerX(), r.centerY(), text)
            text.textSize = 11f * dp
            val pct = (r.width() / max(width, 1) * 100f).roundToInt()
            c.drawText(if (hid) "tersembunyi · $pct% lebar" else "$pct% lebar", r.centerX(), r.centerY() + 16f * dp, text)

            if (selected) {
                for (k in 0..3) {
                    val (x, y) = cornerPoint(r, k)
                    dot.style = Paint.Style.FILL; dot.color = 0xFF2196F3.toInt()
                    c.drawCircle(x, y, 9f * dp, dot)
                    dot.style = Paint.Style.STROKE; dot.color = 0xFFFFFFFF.toInt(); dot.strokeWidth = 2f * dp
                    c.drawCircle(x, y, 9f * dp, dot)
                }
            }
        }

        private fun cornerPoint(r: RectF, k: Int): Pair<Float, Float> = when (k) {
            0 -> r.left to r.top
            1 -> r.right to r.top
            2 -> r.right to r.bottom
            else -> r.left to r.bottom
        }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> beginDrag(e.x, e.y)
                MotionEvent.ACTION_POINTER_DOWN -> if (e.pointerCount == 2) {
                    mode = Mode.PINCH
                    pinchD0 = max(hypot(e.getX(0) - e.getX(1), e.getY(0) - e.getY(1)), 1f)
                    startRect.set(rectOf(sel))
                    guideX = -1f; guideY = -1f
                }
                MotionEvent.ACTION_MOVE -> when (mode) {
                    Mode.MOVE -> doMove(e.x, e.y)
                    Mode.RESIZE -> doResize(e.x, e.y)
                    Mode.PINCH -> if (e.pointerCount >= 2) doPinch(hypot(e.getX(0) - e.getX(1), e.getY(0) - e.getY(1)))
                    Mode.NONE -> {}
                }
                MotionEvent.ACTION_POINTER_UP -> if (mode == Mode.PINCH) { mode = Mode.NONE }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    mode = Mode.NONE; guideX = -1f; guideY = -1f; invalidate()
                }
            }
            return true
        }

        private fun beginDrag(x: Float, y: Float) {
            mode = Mode.NONE
            downX = x; downY = y
            val r = rectOf(sel)
            val hit = 26f * dp
            var best = -1; var bestD = hit
            for (k in 0..3) {
                val (cx, cy) = cornerPoint(r, k)
                val d = hypot(x - cx, y - cy)
                if (d <= bestD) { best = k; bestD = d }
            }
            if (best >= 0) {
                val (cx, cy) = cornerPoint(r, best)
                corner = best; grabDx = x - cx; grabDy = y - cy
                startRect.set(r); mode = Mode.RESIZE
            } else if (r.contains(x, y)) {
                startRect.set(r); mode = Mode.MOVE
            } else if (rectOf(1 - sel).contains(x, y)) {
                sel = 1 - sel; refresh()
                startRect.set(rectOf(sel)); mode = Mode.MOVE
                invalidate()
            }
        }

        private fun doMove(x: Float, y: Float) {
            val r = rectOf(sel)
            r.set(startRect); r.offset(x - downX, y - downY)
            guideX = -1f; guideY = -1f
            if (cfg.customMagnet) {
                val o = rectOf(1 - sel)
                val ox = if (isHidden(1 - sel)) floatArrayOf() else floatArrayOf(o.left, o.right, o.centerX())
                val oy = if (isHidden(1 - sel)) floatArrayOf() else floatArrayOf(o.top, o.bottom, o.centerY())
                snapAxis(floatArrayOf(r.left, r.right, r.centerX()), targets(width.toFloat(), ox))?.let { (d, line) ->
                    r.offset(d, 0f); guideX = line
                }
                snapAxis(floatArrayOf(r.top, r.bottom, r.centerY()), targets(height.toFloat(), oy))?.let { (d, line) ->
                    r.offset(0f, d); guideY = line
                }
            }
            clampCenter(r)
            changed()
        }

        private fun targets(size: Float, extra: FloatArray): FloatArray =
            floatArrayOf(0f, size / 2f, size) + extra

        /** Garis target terdekat dalam jarak magnet: (selisih geser, posisi garis), atau null. */
        private fun snapAxis(edges: FloatArray, targets: FloatArray): Pair<Float, Float>? {
            val limit = 10f * dp
            var best: Pair<Float, Float>? = null
            for (e in edges) for (t in targets) {
                val d = t - e
                if (abs(d) <= limit && (best == null || abs(d) < abs(best.first))) best = d to t
            }
            return best
        }

        private fun snapValue(v: Float, targets: FloatArray): Pair<Float, Float>? {
            val limit = 10f * dp
            var best: Pair<Float, Float>? = null
            for (t in targets) {
                val d = t - v
                if (abs(d) <= limit && (best == null || abs(d) < abs(best.first))) best = d to t
            }
            return best
        }

        private fun doResize(x: Float, y: Float) {
            val s = startRect
            val rightSide = corner == 1 || corner == 2
            val bottomSide = corner == 2 || corner == 3
            val ax = if (rightSide) s.left else s.right        // sudut berlawanan tetap diam
            val ay = if (bottomSide) s.top else s.bottom
            var cx = x - grabDx
            var cy = y - grabDy
            guideX = -1f; guideY = -1f
            if (cfg.customMagnet) {
                val o = rectOf(1 - sel)
                val ox = if (isHidden(1 - sel)) floatArrayOf() else floatArrayOf(o.left, o.right, o.centerX())
                val oy = if (isHidden(1 - sel)) floatArrayOf() else floatArrayOf(o.top, o.bottom, o.centerY())
                snapValue(cx, targets(width.toFloat(), ox))?.let { (d, line) -> cx += d; guideX = line }
                snapValue(cy, targets(height.toFloat(), oy))?.let { (d, line) -> cy += d; guideY = line }
            }
            cx = if (rightSide) max(cx, ax + minW) else min(cx, ax - minW)
            cy = if (bottomSide) max(cy, ay + 1f) else min(cy, ay - 1f)

            var w = abs(cx - ax)
            var h = abs(cy - ay)
            if (cfg.customLockRatio) {
                if (w / ASPECT >= h) h = w / ASPECT else w = h * ASPECT      // ikut sisi yang lebih ditarik
                w = w.coerceIn(minW, maxW); h = w / ASPECT
            } else {
                w = w.coerceIn(minW, maxW)
                h = h.coerceIn(minW / ASPECT, 3f * height)
            }
            val left = if (rightSide) ax else ax - w
            val topY = if (bottomSide) ay else ay - h
            val r = rectOf(sel)
            r.set(left, topY, left + w, topY + h)
            clampCenter(r)
            changed()
        }

        private fun doPinch(d: Float) {
            val k = (d / pinchD0).coerceIn(minW / max(startRect.width(), 1f), maxW / max(startRect.width(), 1f))
            val w = startRect.width() * k; val h = startRect.height() * k
            val cx = startRect.centerX(); val cy = startRect.centerY()
            val r = rectOf(sel)
            r.set(cx - w / 2f, cy - h / 2f, cx + w / 2f, cy + h / 2f)
            clampCenter(r)
            changed()
        }
    }

    private companion object {
        /** Rasio layar NDS asli (256 x 192). */
        const val ASPECT = 256f / 192f
    }
}
