package com.allinone.emulator.ui

import android.app.Activity
import android.content.Context
import android.hardware.display.DisplayManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Surface
import com.swordfish.libretrodroid.GLRetroView

/**
 * Menjaga layar tetap ~60 Hz SELAMA netplay. Penguncian 60 Hz saat game dimulai (EmulatorActivity) hanya sekali;
 * bila sistem menaikkan layar ke 90/120 Hz lagi (mis. saat disentuh), kecepatan game kedua HP jadi tidak sama dan
 * netplay harus menahan frame / rollback berulang. Di sini: (1) pilih mode 60 Hz yang resolusinya sama,
 * (2) beri tahu sistem bahwa konten bersumber tetap 60 fps (Android 11+), (3) pasang ulang bila layar berubah.
 * Semua dibungkus try/catch: bila perangkat menolak, game dan netplay jalan seperti biasa.
 */
object NetplayRefresh {
    private var listener: DisplayManager.DisplayListener? = null

    fun hold(act: Activity, retro: GLRetroView) {
        act.runOnUiThread {
            try {
                apply(act, retro)
                if (listener == null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    val dm = act.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
                    val l = object : DisplayManager.DisplayListener {
                        override fun onDisplayAdded(displayId: Int) {}
                        override fun onDisplayRemoved(displayId: Int) {}
                        @Suppress("DEPRECATION")
                        override fun onDisplayChanged(displayId: Int) {
                            try { if (act.windowManager.defaultDisplay.refreshRate > 65f) apply(act, retro) } catch (_: Exception) {}
                        }
                    }
                    listener = l
                    dm.registerDisplayListener(l, Handler(Looper.getMainLooper()))
                }
            } catch (_: Exception) {}
        }
    }

    fun release(act: Activity) {
        act.runOnUiThread {
            try {
                listener?.let { (act.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager).unregisterDisplayListener(it) }
            } catch (_: Exception) {}
            listener = null
        }
    }

    @Suppress("DEPRECATION")
    private fun apply(act: Activity, retro: GLRetroView) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val disp = act.windowManager.defaultDisplay
            val cur = disp.mode
            val target = disp.supportedModes
                .filter { it.physicalWidth == cur.physicalWidth && it.physicalHeight == cur.physicalHeight && Math.abs(it.refreshRate - 60f) < 1.5f }
                .minByOrNull { Math.abs(it.refreshRate - 60f) }
            if (target != null && act.window.attributes.preferredDisplayModeId != target.modeId) {
                act.window.attributes = act.window.attributes.apply { preferredDisplayModeId = target.modeId }
            }
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val s = retro.holder.surface
            if (s != null && s.isValid) s.setFrameRate(60f, Surface.FRAME_RATE_COMPATIBILITY_FIXED_SOURCE)
        }
    }
}
