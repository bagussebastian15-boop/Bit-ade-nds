package com.allinone.emulator.ui

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.GestureDetector
import android.view.HapticFeedbackConstants
import android.view.ViewConfiguration
import android.content.Context
import android.hardware.input.InputManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.lifecycleScope
import com.allinone.emulator.R
import com.allinone.emulator.data.Paths
import com.allinone.emulator.data.Settings
import com.allinone.emulator.data.SeedlessSettings
import com.allinone.emulator.input.VirtualPadView
import com.allinone.emulator.translate.FrameCapture
import com.allinone.emulator.translate.TranslationEngine
import com.allinone.emulator.translate.TranslationOverlayView
import com.seedlessds.app.SeedlessBridge
import com.seedlessds.app.filesystem.PathCache
import com.seedlessds.core.SeedlessCore
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.abs

/**
 * Game NDS dengan core SeedlessDS (SeedlessCoreDS) yang ditanam di APK. Tidak memakai LibretroDroid:
 * core punya EGL/OpenGL dan audio OpenSL ES sendiri; activity ini hanya menyajikan dua layar, meneruskan tombol/sentuhan,
 * dan menyediakan menu (simpan/muat state, reset, keluar).
 */
class SeedlessNdsActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_ROM = "rom"
        private const val TAG = "SeedlessNds"
        /** attachSurface (nds_create) cukup sekali per proses, sama seperti SeedlessDS. */
        @Volatile private var inited = false
        /** Thread emulasi game sebelumnya: game baru menunggunya selesai dulu sebelum menyentuh core. */
        @Volatile private var lastEmu: Thread? = null
        /** true bila game sebelumnya ditutup sebelum thread emulasinya selesai: release()+attach ulang dikerjakan saat game berikutnya. */
        @Volatile private var pendingRelease = false
        private const val SWAP_BTN_DP = 44
    }

    /** Pengaturan khusus SeedlessDS (terpisah dari Settings emulator lain). */
    private lateinit var cfg: SeedlessSettings
    private var fpsView: TextView? = null
    private val uiHandler = Handler(Looper.getMainLooper())
    private var lastFrames = 0L
    private var lastFpsAt = 0L
    private val fpsTick = object : Runnable {
        override fun run() {
            val now = System.nanoTime()
            val frames = glView.framesPresented
            val dt = (now - lastFpsAt) / 1e9
            if (dt > 0.0) fpsView?.text = "${Math.round((frames - lastFrames) / dt)} FPS"
            lastFrames = frames; lastFpsAt = now
            if (cfg.showFps) uiHandler.postDelayed(this, 1000)
        }
    }

    private val stateSlot get() = cfg.stateSlot

    private lateinit var glView: SeedlessGlView
    private lateinit var pad: VirtualPadView
    private lateinit var layoutEditor: ScreenLayoutEditor
    private lateinit var padEditorBar: View
    /** true saat mengatur tata letak kontrol; game tetap dijeda sampai Simpan/Batal. */
    private var padEditing = false
    /** Tombol melayang untuk menukar layar atas/bawah seketika saat game berjalan. */
    private lateinit var swapBtn: TextView
    private var comboBackup: Pair<String, String>? = null
    private var emuThread: Thread? = null
    /** true setelah core ditutup (atau sedang ditutup); sesudah itu tidak ada lagi panggilan ke core dari activity ini. */
    @Volatile private var coreClosed = false
    private val closeLock = Any()
    /** true saat menutup core di latar belakang menuju library; masukan diabaikan. */
    @Volatile private var closing = false
    private var menuOpen = false
    /** Jumlah dialog pilihan (mesin/jenis/mode terjemahan, dll.) yang sedang terbuka; game dijeda selama > 0. */
    private var dialogCount = 0

    // ---- terjemahan (mesin yang sama dengan emulator lain) + fast forward
    /** Pengaturan bersama (terjemahan, kunci Groq, dll.): sama dengan yang dipakai emulator lain, jadi pilihan mesin ikut. */
    private val appSettings by lazy { Settings(this) }
    private val translator = TranslationEngine()
    private lateinit var tOverlay: TranslationOverlayView
    /** Gambar beku layar yang ditangkap: tampil di bawah teks terjemahan selama game dijeda. */
    private lateinit var freezeView: ImageView
    private lateinit var toolBar: View
    private lateinit var ffView: ImageView
    private lateinit var trView: ImageView
    private var tJob: Job? = null
    private var preJob: Job? = null          // tangkap layar + jeda seketika saat tombol terjemahan disentuh
    private var liveJob: Job? = null         // live translate: pemindaian dialog otomatis berkelanjutan
    private var tPre = false                 // layar sudah ditangkap dan game dijeda, menunggu ketukan selesai
    private var tFrame: Bitmap? = null
    private var tPaused = false              // game dijeda oleh terjemahan
    private var tActive = false              // terjemahan sedang diproses / tampil
    private var tHasResult = false
    private var tShowingOriginal = false
    private var tToast: Toast? = null
    private var hatX = 0
    private var hatY = 0

    // ---- gamepad eksternal: layar utama otomatis fullscreen, layar kecil di atasnya
    private val inputManager by lazy { getSystemService(Context.INPUT_SERVICE) as InputManager }
    private val deviceListener = object : InputManager.InputDeviceListener {
        override fun onInputDeviceAdded(deviceId: Int) = refreshGamepad()
        override fun onInputDeviceRemoved(deviceId: Int) = refreshGamepad()
        override fun onInputDeviceChanged(deviceId: Int) = refreshGamepad()
    }

    /**
     * Gamepad fisik = bukan perangkat virtual, melaporkan sumber gamepad/joystick, DAN benar-benar punya tombol gamepad.
     * Pemeriksaan tombol mencegah perangkat bawaan HP yang salah lapor (sensor, tombol fisik, dll.) dianggap controller,
     * yang sebelumnya membuat layar fullscreen dan kontrol virtual hilang padahal tidak ada controller terpasang.
     */
    private fun isRealController(d: InputDevice): Boolean {
        if (d.isVirtual) return false
        val s = d.sources
        val padLike = (s and InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD ||
            (s and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK
        if (!padLike) return false
        val has = d.hasKeys(
            KeyEvent.KEYCODE_BUTTON_A, KeyEvent.KEYCODE_BUTTON_B, KeyEvent.KEYCODE_BUTTON_X,
            KeyEvent.KEYCODE_BUTTON_Y, KeyEvent.KEYCODE_BUTTON_START
        )
        return has.any { it }
    }

    private fun hasExternalGamepad(): Boolean = InputDevice.getDeviceIds().any { id ->
        val d = InputDevice.getDevice(id) ?: return@any false
        isRealController(d)
    }

    /** Aktifkan/matikan mode gamepad sesuai ada tidaknya gamepad fisik dan pengaturan. Aman dipanggil dari thread mana pun. */
    private fun refreshGamepad() {
        runOnUiThread {
            if (!::glView.isInitialized || !::pad.isInitialized) return@runOnUiThread
            val on = cfg.gamepadFullscreen && hasExternalGamepad()
            glView.setGamepadMode(on)
            pad.hideControls = on
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        enterImmersive()

        cfg = SeedlessSettings(this)
        val romPath = intent.getStringExtra(EXTRA_ROM)
        if (romPath == null || !File(romPath).isFile || !SeedlessSupport.available) { finish(); return }

        // Game sebelumnya (kalau ada) harus sudah benar-benar berhenti sebelum core dipakai lagi.
        lastEmu?.let { t -> if (t.isAlive) runCatching { t.join(4000) } }
        if (pendingRelease && lastEmu?.isAlive != true) {
            try { SeedlessCore.release() } catch (_: Throwable) {}
            inited = false; pendingRelease = false
        }
        SeedlessGate.open()

        try {
            SeedlessSupport.ensureInstalled(this)
            PathCache.setAppContext(applicationContext)
            PathCache.changeRom(romPath, romPath, File(romPath).name)
            if (!inited) {
                SeedlessCore.attachSurface(this, 1, Build.VERSION.SDK_INT)
                inited = true
            }
        } catch (t: Throwable) {
            fail("Gagal menyiapkan core SeedlessDS: ${t.javaClass.simpleName}: ${t.message}")
            return
        }

        glView = SeedlessGlView(this)
        pad = VirtualPadView(this).apply {
            opacity = cfg.padOpacity
            haptics = cfg.haptics
            ndsLayout = true
            snesLayout = true
            // Tombol kombo NDS (dipakai bersama emulator NDS lain, sama seperti tata letak tombolnya).
            Settings(this@SeedlessNdsActivity).let { combo1Spec = it.ndsCombo1; combo2Spec = it.ndsCombo2 }
            onComboEdit = { slot -> showComboDialog(slot) }
            onKey = { key, down -> keyToBit(key).let { if (it >= 0) glView.setButton(it, down) } }
            onScreenTouch = { action, x, y ->
                glView.touch(action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_MOVE, x, y)
            }
        }
        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        root.addView(glView, FrameLayout.LayoutParams(-1, -1, Gravity.CENTER))
        // Gambar beku + lapisan terjemahan: di atas layar game, di bawah kontrol virtual (sentuhan tetap sampai ke kontrol).
        freezeView = ImageView(this).apply { scaleType = ImageView.ScaleType.FIT_XY; visibility = View.GONE }
        root.addView(freezeView, FrameLayout.LayoutParams(-1, -1))
        tOverlay = TranslationOverlayView(this)
        root.addView(tOverlay, FrameLayout.LayoutParams(-1, -1))
        root.addView(pad, FrameLayout.LayoutParams(-1, -1))
        fpsView = TextView(this).apply {
            setTextColor(Color.WHITE); setShadowLayer(4f, 0f, 0f, Color.BLACK)
            textSize = 12f; setPadding(16, 8, 16, 8); visibility = View.GONE
        }
        root.addView(fpsView, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.START).apply { topMargin = dp(52) })   // di bawah ikon fast forward
        swapBtn = buildSwapButton()
        root.addView(swapBtn, FrameLayout.LayoutParams(dp(SWAP_BTN_DP), dp(SWAP_BTN_DP), Gravity.TOP or Gravity.START))
        // Tombol terjemahan + fast forward di pojok kanan atas, sama seperti emulator lain.
        toolBar = buildToolButtons()
        root.addView(toolBar, FrameLayout.LayoutParams(-1, -1))   // lapisan transparan: sentuhan di luar ikon diteruskan ke kontrol
        root.addOnLayoutChangeListener { _, l, t, r, b, ol, ot, orr, ob ->
            if (r - l != orr - ol || b - t != ob - ot) {
                placeSwapButton()
                placeToolButtons()
                if (tActive) closeTranslation()   // ukuran/orientasi berubah: posisi teks terjemahan tidak berlaku lagi
            }
        }
        // Editor susunan layar kustom: menutupi game saat aktif, game tetap berjalan di belakangnya.
        layoutEditor = ScreenLayoutEditor(this, cfg).apply {
            visibility = View.GONE
            onPreview = { t, b -> glView.previewLayout(t, b) }
            onFinish = { save, t, b -> finishLayoutEdit(save, t, b) }
        }
        root.addView(layoutEditor, FrameLayout.LayoutParams(-1, -1))
        padEditorBar = buildPadEditorBar().apply { visibility = View.GONE }
        root.addView(padEditorBar, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL))
        setContentView(root)
        applyUi()   // inti belum berjalan di sini, jadi hanya bagian tampilan
        inputManager.registerInputDeviceListener(deviceListener, uiHandler)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    tActive -> closeTranslation()
                    padEditing -> finishPadEdit(false)
                    ::layoutEditor.isInitialized && layoutEditor.isActive -> layoutEditor.finish(true)
                    else -> showMenu()
                }
            }
        })

        startEmulation(romPath)
    }

    private fun startEmulation(romPath: String) {
        val t = Thread {
            try {
                SeedlessCore.firmwareUser(cfg.nickname, SeedlessSupport.firmwarePacked(cfg))
                SeedlessCore.autosaveInterval(0)
                SeedlessCore.audioVolume(cfg.volume)
                SeedlessBridge.resetMemory()
                val ok = SeedlessCore.loadRom(romPath, -1, SeedlessSupport.configBits(cfg), 0, false, -1L)
                if (!ok) runOnUiThread { fail("Core SeedlessDS menolak game ini (format tidak dikenali atau ROM rusak).") }
            } catch (e: Throwable) {
                runOnUiThread { fail("Core SeedlessDS gagal berjalan: ${e.javaClass.simpleName}: ${e.message}") }
            }
        }
        t.name = "seedless-emu"; t.priority = Thread.MAX_PRIORITY
        emuThread = t; lastEmu = t; t.start()
    }

    private fun fail(msg: String) {
        if (isFinishing || isDestroyed) return
        AlertDialog.Builder(this).setTitle("NDS (SeedlessDS)").setMessage(msg)
            .setPositiveButton("OK") { _, _ -> finish() }
            .setOnCancelListener { finish() }
            .show()
    }

    // ---------------------------------------------------------------- menu

    private fun setPaused(p: Boolean) {
        if (coreClosed || closing) return
        try { SeedlessCore.pause(if (p) 1 else 0) } catch (_: Throwable) {}
    }

    private fun showMenu() {
        if (menuOpen || (::layoutEditor.isInitialized && layoutEditor.isActive)) return
        menuOpen = true
        setPaused(true)
        val slot = stateSlot
        val items = arrayOf("Lanjut", "Simpan state (slot $slot)", "Muat state (slot $slot)", "Reset game",
            "Atur tata letak kontrol", "Pengaturan SeedlessDS", "Terjemahan…", "Keluar ke library")
        AlertDialog.Builder(this).setTitle("NDS · SeedlessDS").setItems(items) { _, i ->
            when (i) {
                1 -> stateOp("Simpan") { SeedlessCore.stateSave(slot, false) }
                2 -> stateOp("Muat") { SeedlessCore.stateLoad(slot) }
                3 -> try { SeedlessCore.reset() } catch (_: Throwable) {}
                4 -> { startPadEdit(); return@setItems }
                5 -> {
                    // Game tetap dijeda selama pengaturan terbuka; perubahan diterapkan langsung, lalu game lanjut saat ditutup.
                    SeedlessSettingsMenu.show(this, cfg, onChange = { applyLive() }, onClosed = { closeMenu(resume = true) },
                        onEditLayout = { startLayoutEdit() })
                    return@setItems
                }
                6 -> { showTranslationMenu(); return@setItems }
                7 -> { closeMenu(resume = false); exitToLibrary(); return@setItems }
            }
            closeMenu(resume = true)
        }.setOnCancelListener { closeMenu(resume = true) }.show()
    }

    // ---------------------------------------------------------------- tata letak kontrol virtual

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    /** Mulai mengatur tombol: seret = pindah, ketuk = nonaktif/aktif, ukuran lewat bilah. Game tetap dijeda. */
    private fun startPadEdit() {
        comboBackup = pad.combo1Spec to pad.combo2Spec
        padEditing = true
        pad.editMode = true
        toolBar.visibility = View.GONE
        padEditorBar.visibility = View.VISIBLE
    }

    private fun finishPadEdit(save: Boolean) {
        if (!padEditing) return
        if (save) {
            Settings(this).let { it.ndsCombo1 = pad.combo1Spec; it.ndsCombo2 = pad.combo2Spec }
            pad.saveLayout()
        } else {
            comboBackup?.let { pad.combo1Spec = it.first; pad.combo2Spec = it.second }
            pad.reloadLayout()
        }
        comboBackup = null
        pad.editMode = false
        padEditing = false
        padEditorBar.visibility = View.GONE
        applyUi()
        closeMenu(resume = true)
        if (save) Toast.makeText(this, "Tata letak kontrol disimpan", Toast.LENGTH_SHORT).show()
    }

    /** Pilih tombol apa saja yang ditekan sekaligus oleh slot kombo [slot] (0 atau 1). Tanpa pilihan = tombol disembunyikan. */
    private fun showComboDialog(slot: Int) {
        val tokens = VirtualPadView.SNES_COMBO_KEYS
        val names = arrayOf("A", "B", "X", "Y", "L", "R", "Select", "Start", "↑ Atas", "↓ Bawah", "← Kiri", "→ Kanan")
        val have = (if (slot == 0) pad.combo1Spec else pad.combo2Spec).split('+').map { it.trim() }.toSet()
        val checked = BooleanArray(tokens.size) { tokens[it] in have }
        fun setSpec(spec: String) { if (slot == 0) pad.combo1Spec = spec else pad.combo2Spec = spec }
        AlertDialog.Builder(this)
            .setTitle("Tombol kombo ${slot + 1}")
            .setMultiChoiceItems(names, checked) { _, i, v -> checked[i] = v }
            .setPositiveButton("Simpan") { _, _ -> setSpec(tokens.filterIndexed { i, _ -> checked[i] }.joinToString("+")) }
            .setNeutralButton("Kosongkan") { _, _ -> setSpec("") }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun buildPadEditorBar(): View {
        fun btn(label: String, onClick: () -> Unit) = Button(this).apply {
            text = label; isAllCaps = false; textSize = 13f
            minWidth = 0; minimumWidth = 0
            setPadding(dp(10), dp(4), dp(10), dp(4))
            setOnClickListener { onClick() }
        }
        fun label(t: String) = TextView(this).apply {
            text = t; setTextColor(Color.WHITE); textSize = 12f; setPadding(dp(8), 0, dp(2), 0)
        }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            addView(label("Arah"))
            addView(btn("−") { pad.changeDirScale(-0.1f) })
            addView(btn("+") { pad.changeDirScale(0.1f) })
            addView(label("Tombol"))
            addView(btn("−") { pad.changeScale(-0.1f) })
            addView(btn("+") { pad.changeScale(0.1f) })
            addView(btn("Reset") { pad.resetLayout() })
            addView(btn("Batal") { finishPadEdit(false) })
            addView(btn("Simpan") { finishPadEdit(true) })
        }
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setBackgroundColor(0xAA000000.toInt())
            setPadding(dp(8), dp(4), dp(8), dp(4))
            addView(TextView(context).apply {
                text = "Seret tombol = pindah.  Ketuk = nonaktif/aktif.  Arah = ukuran D-pad, Tombol = ukuran tombol lain.  " +
                    "Ketuk \"+ Kombo\" = buat tombol kombo"
                setTextColor(Color.WHITE); textSize = 12f
            })
            addView(row)
        }
    }

    /** Buka editor susunan layar kustom (dipanggil dari menu pengaturan; menu itu menutup dan game lanjut berjalan). */
    private fun startLayoutEdit() {
        val rects = glView.rectsForEditing()
        if (rects == null) {
            Toast.makeText(this, "Layar belum siap, coba lagi sebentar lagi", Toast.LENGTH_SHORT).show()
            return
        }
        pad.releaseTouches()
        layoutEditor.begin(rects.first, rects.second)
    }

    private fun finishLayoutEdit(save: Boolean, top: FloatArray, bot: FloatArray) {
        if (save) {
            val portrait = glView.height > glView.width
            cfg.setCustomScreen(portrait, true, top)
            cfg.setCustomScreen(portrait, false, bot)
            cfg.layoutMode = SeedlessSettings.MODE_CUSTOM
            cfg.swapScreens = false   // editor mulai dari tampilan yang terlihat, jadi tukar sudah tercermin di posisi
            Toast.makeText(this, "Susunan layar kustom disimpan (${if (portrait) "potret" else "lanskap"})", Toast.LENGTH_SHORT).show()
        }
        glView.previewLayout(null, null)
        glView.applyDisplay()
    }

    /** Terapkan pengaturan SeedlessDS yang bisa berlaku langsung (tanpa memulai ulang game). */
    private fun applyLive() {
        if (!coreClosed && !closing) try {
            SeedlessCore.audioVolume(cfg.volume)
            SeedlessCore.applyConfig(SeedlessSupport.configBits(cfg))
        } catch (_: Throwable) {}
        applyUi()
    }

    /** Bagian pengaturan yang hanya menyangkut tampilan Android (layar, kontrol, FPS). */
    private fun applyUi() {
        if (::glView.isInitialized) glView.applyDisplay()
        refreshGamepad()
        if (::tOverlay.isInitialized && tActive) closeTranslation()   // susunan layar bisa berubah: terjemahan lama tidak pas lagi
        if (::toolBar.isInitialized && !padEditing) toolBar.visibility = if (cfg.showToolButtons) View.VISIBLE else View.GONE
        if (::pad.isInitialized) { pad.opacity = cfg.padOpacity; pad.haptics = cfg.haptics }
        if (::swapBtn.isInitialized) {
            swapBtn.visibility = if (cfg.showSwapButton) View.VISIBLE else View.GONE
            swapBtn.alpha = (cfg.padOpacity / 100f).coerceIn(0.35f, 1f)
            placeSwapButton()
        }
        uiHandler.removeCallbacks(fpsTick)
        fpsView?.visibility = if (cfg.showFps) View.VISIBLE else View.GONE
        if (cfg.showFps && ::glView.isInitialized) {
            lastFrames = glView.framesPresented; lastFpsAt = System.nanoTime()
            uiHandler.postDelayed(fpsTick, 1000)
        }
    }

    // ---------------------------------------------------------------- tukar layar seketika

    /** Tukar layar atas/bawah saat ini juga, game tidak dijeda. Dipakai tombol melayang dan tombol L3/R3 gamepad. */
    private fun swapScreensNow(feedbackView: View? = null) {
        if (!::glView.isInitialized || menuOpen || padEditing || (::layoutEditor.isInitialized && layoutEditor.isActive)) return
        if (tActive && liveJob?.isActive != true) closeTranslation()
        glView.toggleSwap()
        if (cfg.haptics) (feedbackView ?: glView).performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
    }

    /** Tombol bulat kecil \u21C4: ketuk = tukar layar, seret = pindahkan (posisi tersimpan). */
    private fun buildSwapButton(): TextView {
        val slop = ViewConfiguration.get(this).scaledTouchSlop
        return TextView(this).apply {
            text = "\u21C4"
            setTextColor(Color.WHITE)
            textSize = 20f
            gravity = Gravity.CENTER
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0x99202530.toInt()); setStroke(dp(1), 0x66FFFFFF) }
            elevation = dp(4).toFloat()
            var downX = 0f; var downY = 0f; var startTx = 0f; var startTy = 0f; var dragging = false
            setOnTouchListener { v, e ->
                val parent = v.parent as? View
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        downX = e.rawX; downY = e.rawY; startTx = v.translationX; startTy = v.translationY; dragging = false
                        v.parent?.requestDisallowInterceptTouchEvent(true)
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = e.rawX - downX; val dy = e.rawY - downY
                        if (!dragging && (kotlin.math.abs(dx) > slop * 2 || kotlin.math.abs(dy) > slop * 2)) dragging = true
                        if (dragging && parent != null) {
                            val maxX = (parent.width - v.width).coerceAtLeast(0).toFloat()
                            val maxY = (parent.height - v.height).coerceAtLeast(0).toFloat()
                            v.translationX = (startTx + dx).coerceIn(0f, maxX)
                            v.translationY = (startTy + dy).coerceIn(0f, maxY)
                        }
                    }
                    MotionEvent.ACTION_UP -> {
                        if (dragging && parent != null) {
                            val maxX = (parent.width - v.width).coerceAtLeast(1).toFloat()
                            val maxY = (parent.height - v.height).coerceAtLeast(1).toFloat()
                            cfg.swapButtonX = (v.translationX / maxX).coerceIn(0f, 1f)
                            cfg.swapButtonY = (v.translationY / maxY).coerceIn(0f, 1f)
                        } else swapScreensNow(v)
                    }
                }
                true
            }
        }
    }

    /** Letakkan tombol sesuai posisi tersimpan (bawaan: sesuai orientasi, lihat di bawah). */
    private fun placeSwapButton() {
        if (!::swapBtn.isInitialized) return
        val parent = swapBtn.parent as? View ?: return
        val maxX = (parent.width - dp(SWAP_BTN_DP)).coerceAtLeast(0).toFloat()
        val maxY = (parent.height - dp(SWAP_BTN_DP)).coerceAtLeast(0).toFloat()
        // Bawaan (belum pernah digeser) diukur dari screenshot pengguna: potret di tengah bawah layar game,
        // lanskap di tepi kanan di sebelah tombol X.
        val portrait = parent.height > parent.width
        val fx = cfg.swapButtonX.let { if (it < 0f) (if (portrait) 0.4725f else 0.9859f) else it }
        val fy = cfg.swapButtonY.let { if (it < 0f) (if (portrait) 0.8862f else 0.7199f) else it }
        swapBtn.translationX = (fx * maxX).coerceIn(0f, maxX)
        swapBtn.translationY = (fy * maxY).coerceIn(0f, maxY)
    }

    private fun closeMenu(resume: Boolean) {
        menuOpen = false
        if (resume) updatePause()
    }

    /** Game dijeda selama ada menu, dialog pilihan, atau terjemahan (mode dengan jeda) yang aktif. */
    private fun updatePause() = setPaused(menuOpen || dialogCount > 0 || tPaused)

    /** Dialog yang menjeda game selama terbuka. */
    private fun dlg(b: AlertDialog.Builder) {
        dialogCount++
        updatePause()
        b.setOnDismissListener { dialogCount--; updatePause() }
        b.show()
    }

    private fun stateOp(label: String, op: () -> Boolean) {
        Thread {
            val ok = try { op() } catch (_: Throwable) { false }
            runOnUiThread { Toast.makeText(this, if (ok) "$label state: berhasil" else "$label state: gagal", Toast.LENGTH_SHORT).show() }
        }.start()
    }

    // ---------------------------------------------------------------- tombol terjemahan + fast forward

    /** Dua ikon di pojok kanan atas: terjemahan (A/文) dan fast forward (panah ganda). Gambar sama dengan emulator lain. */
    private fun buildToolButtons(): View {
        ffView = ImageView(this).apply {
            setImageResource(R.drawable.ic_fast_forward)
            scaleType = ImageView.ScaleType.FIT_CENTER
            setPadding(dp(6), dp(8), dp(6), dp(8))
            layoutParams = FrameLayout.LayoutParams(dp(64), dp(46), Gravity.TOP or Gravity.START)   // pojok kiri atas
            alpha = 0.7f
            setOnClickListener { toggleFastForward() }
        }
        return FrameLayout(this).apply {
            alpha = 0.55f
            trView = ImageView(this@SeedlessNdsActivity).apply {
                setImageResource(R.drawable.ic_translate)
                scaleType = ImageView.ScaleType.FIT_CENTER
                setPadding(dp(8), dp(8), dp(8), dp(8))
                layoutParams = FrameLayout.LayoutParams(dp(46), dp(46), Gravity.TOP or Gravity.END)   // pojok kanan atas
                // Ketuk 1x = terjemahkan / tutup terjemahan. Ketuk 2x cepat = pilih mesin. Tahan 3 detik = pilih jenis teks.
                val gd = GestureDetector(this@SeedlessNdsActivity, object : GestureDetector.SimpleOnGestureListener() {
                    override fun onDown(e: MotionEvent) = true
                    override fun onSingleTapConfirmed(e: MotionEvent): Boolean { toggleTranslation(); return true }
                    override fun onDoubleTap(e: MotionEvent): Boolean { showTranslateEngineChooser(); cancelPreCapture(); return true }
                })
                val holdHandler = Handler(Looper.getMainLooper())
                var held = false
                var downX = 0f
                var downY = 0f
                val slop = ViewConfiguration.get(this@SeedlessNdsActivity).scaledTouchSlop
                val holdRun = Runnable {
                    held = true
                    performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                    showTranslateKindChooser()
                    cancelPreCapture()
                }
                @Suppress("ClickableViewAccessibility")
                setOnTouchListener { v, ev ->
                    when (ev.actionMasked) {
                        MotionEvent.ACTION_DOWN -> {
                            held = false; downX = ev.x; downY = ev.y
                            holdHandler.postDelayed(holdRun, 3000L)
                            preCaptureForPause()    // mode dengan jeda: tangkap layar lalu jeda game SEKARANG
                        }
                        MotionEvent.ACTION_MOVE ->
                            if (abs(ev.x - downX) > slop || abs(ev.y - downY) > slop) {
                                holdHandler.removeCallbacks(holdRun)
                                cancelPreCapture()
                            }
                        MotionEvent.ACTION_UP -> holdHandler.removeCallbacks(holdRun)
                        MotionEvent.ACTION_CANCEL -> { holdHandler.removeCallbacks(holdRun); cancelPreCapture() }
                    }
                    val handled = if (held) true else gd.onTouchEvent(ev)
                    if (ev.actionMasked == MotionEvent.ACTION_UP && !held) v.performClick()
                    handled
                }
            }
            addView(trView)
            addView(ffView)
        }
    }

    /**
     * Posisi ikon mengikuti orientasi. Lanskap: fast forward di pojok kiri atas, terjemahan di pojok kanan atas.
     * Potret: fast forward di pojok kiri bawah, terjemahan di pojok kanan bawah.
     */
    private fun placeToolButtons() {
        if (!::ffView.isInitialized || !::trView.isInitialized) return
        val parent = toolBar.parent as? View ?: return
        val portrait = parent.height > parent.width
        val vert = if (portrait) Gravity.BOTTOM else Gravity.TOP
        val m = if (portrait) dp(6) else 0
        // Lanskap: ikon lebih kecil dan rapat ke tepi atas supaya tidak menimpa tombol L (kiri) dan R (kanan).
        val ffW = if (portrait) 64 else 48; val ffH = if (portrait) 46 else 34
        val trS = if (portrait) 46 else 34
        val pd = if (portrait) 8 else 4
        (ffView.layoutParams as FrameLayout.LayoutParams).apply {
            gravity = vert or Gravity.START; bottomMargin = m; width = dp(ffW); height = dp(ffH)
        }
        (trView.layoutParams as FrameLayout.LayoutParams).apply {
            gravity = vert or Gravity.END; bottomMargin = m; width = dp(trS); height = dp(trS)
        }
        ffView.setPadding(dp(pd - 2), dp(pd), dp(pd - 2), dp(pd))
        trView.setPadding(dp(pd), dp(pd), dp(pd), dp(pd))
        ffView.requestLayout(); trView.requestLayout()
        // Penghitung FPS di kiri atas: turun sedikit hanya saat ikon fast forward juga di atas (lanskap).
        (fpsView?.layoutParams as? FrameLayout.LayoutParams)?.let { it.topMargin = if (portrait) 0 else dp(52); fpsView?.requestLayout() }
    }

    // ---------------------------------------------------------------- fast forward

    /** Hidupkan/matikan fast forward lewat bit konfigurasi core (kecepatan dari Pengaturan > Performa). */
    private fun toggleFastForward(force: Boolean? = null) {
        if (!::glView.isInitialized || coreClosed || closing) return
        val on = force ?: !cfg.fastForwardActive
        cfg.fastForwardActive = on
        try { SeedlessCore.applyConfig(SeedlessSupport.configBits(cfg)) } catch (_: Throwable) {}
        ffView.alpha = if (on) 1f else 0.7f
        ffView.scaleX = if (on) 1.15f else 1f
        ffView.scaleY = if (on) 1.15f else 1f
        status(if (on) "Fast forward ${SeedlessSettings.ffwdLabel(cfg.ffwdSpeed)}" else "Fast forward mati")
    }

    // ---------------------------------------------------------------- terjemahan

    /** Pesan singkat (toast) supaya layar game tidak tertutup panel apa pun. */
    private fun status(msg: String, long: Boolean = false) {
        tToast?.cancel()
        tToast = Toast.makeText(this, msg, if (long) Toast.LENGTH_LONG else Toast.LENGTH_SHORT).also { it.show() }
    }

    /** Ganti bitmap tangkapan; gambar beku dilepas dulu supaya tidak memakai bitmap yang sudah didaur ulang. */
    private fun setFrame(b: Bitmap?) {
        if (::freezeView.isInitialized) freezeView.setImageDrawable(null)
        tFrame?.recycle()
        tFrame = b
    }

    private fun pauseForOverlay() {
        if (tPaused) return
        tPaused = true
        tFrame?.takeIf { !it.isRecycled }?.let { freezeView.setImageBitmap(it); freezeView.visibility = View.VISIBLE }
        updatePause()
    }

    private fun releaseOverlayPause() {
        if (!tPaused) return
        tPaused = false
        freezeView.visibility = View.GONE
        freezeView.setImageDrawable(null)
        updatePause()
    }

    private fun configureTranslator() {
        translator.online = appSettings.translateOnline
        translator.onlineEngine = appSettings.onlineEngine
        translator.groqKey = appSettings.groqKey
        translator.groqModel = appSettings.groqModel
        translator.jaGlossaryFile = Paths.glossaryJa(this)
        translator.glyphFile = Paths.glyphBank(this)
    }

    /** Tahan 3 detik logo terjemahan: pilih jenis teks. */
    private fun showTranslateKindChooser() {
        val items = arrayOf(
            "Dialog: balon/kotak dialog saat bermain",
            "Menu awal game: tulisan Start, Option, Load, Save, dll. satu per satu"
        )
        dlg(AlertDialog.Builder(this)
            .setTitle("Jenis teks yang diterjemahkan")
            .setSingleChoiceItems(items, appSettings.translateKind) { d, which ->
                val changed = appSettings.translateKind != which
                appSettings.translateKind = which
                d.dismiss()
                status("Jenis teks: ${if (which == 1) "Menu awal game" else "Dialog"}")
                if (changed && tActive && tHasResult) startTranslation(thorough = false, reuse = true)
            }
            .setNegativeButton("Batal", null))
    }

    /** Ketuk 2x logo terjemahan: pilih mesin terjemahan. */
    private fun showTranslateEngineChooser() {
        val items = arrayOf(
            "Online (Google Translate): lebih akurat, wajib internet",
            "Online (Groq): terjemahan AI, wajib internet + API key Groq",
            "Offline (ML Kit): tanpa internet, kurang akurat"
        )
        val cur = if (!appSettings.translateOnline) 2 else if (appSettings.onlineEngine == 1) 1 else 0
        fun applyEngine(which: Int) {
            val changed = which != cur
            appSettings.translateOnline = which != 2
            if (which != 2) appSettings.onlineEngine = which
            status("Mesin terjemahan: " + when (which) { 0 -> "Online (Google)"; 1 -> "Online (Groq)"; else -> "Offline (ML Kit)" })
            if (changed && tActive && tHasResult) startTranslation(thorough = false, reuse = true)
        }
        dlg(AlertDialog.Builder(this)
            .setTitle("Mesin terjemahan")
            .setSingleChoiceItems(items, cur) { d, which ->
                d.dismiss()
                if (which == 1 && appSettings.groqKey.isEmpty()) {
                    Menus.askGroqKey(this, appSettings, show = { dlg(it) }) { applyEngine(1) }
                } else applyEngine(which)
            }
            .setNegativeButton("Batal", null))
    }

    /** Mode terjemahan: dengan jeda (game berhenti selama terjemahan tampil) atau tanpa jeda. */
    private fun showTranslateModeChooser() {
        val items = arrayOf(
            "Dengan jeda: game berhenti selama terjemahan tampil, teks tidak bergeser",
            "Tanpa jeda: game tetap berjalan saat terjemahan tampil"
        )
        dlg(AlertDialog.Builder(this)
            .setTitle("Mode terjemahan")
            .setSingleChoiceItems(items, if (appSettings.translateLive) 1 else 0) { d, which ->
                val live = which == 1
                val changed = appSettings.translateLive != live
                appSettings.translateLive = live
                d.dismiss()
                status("Mode terjemahan: ${if (live) "tanpa jeda" else "dengan jeda"}")
                if (changed && tActive) {
                    if (live) releaseOverlayPause() else pauseForOverlay()
                }
            }
            .setNegativeButton("Batal", null))
    }

    /**
     * Mode dengan jeda: begitu tombol terjemahan disentuh, layar langsung ditangkap lalu game dijeda, tanpa menunggu
     * ketukan selesai. Yang diterjemahkan persis tulisan yang ada di layar saat tombol disentuh.
     */
    private fun preCaptureForPause() {
        if (tActive || tPre || tPaused || padEditing || menuOpen || appSettings.translateAuto || appSettings.translateLive) return
        tPre = true
        preJob = lifecycleScope.launch {
            val f = FrameCapture.grab(glView)   // ditangkap sebelum jeda
            if (f != null) {
                setFrame(f)
                pauseForOverlay()
            } else tPre = false
        }
    }

    /** Sentuhan ternyata bukan ketukan terjemahan (ketuk 2x, tahan, atau jari bergeser): lepaskan jeda dan buang tangkapan. */
    private fun cancelPreCapture() {
        preJob?.cancel(); preJob = null
        if (!tPre) return
        tPre = false
        if (tActive) return
        releaseOverlayPause()
        setFrame(null)
    }

    private fun toggleTranslation() {
        if (padEditing || menuOpen) return
        if (tActive) { closeTranslation(); return }
        if (appSettings.translateAuto) { cancelPreCapture(); startLive(); return }
        if (tPre && tPaused && tFrame != null) {
            tPre = false
            startTranslation(thorough = false, reuse = true)    // pakai tangkapan saat disentuh; game sudah berhenti
        } else {
            cancelPreCapture()
            startTranslation(thorough = false, reuse = false)
        }
    }

    /**
     * Live translate (khusus dialog): game tetap berjalan, seluruh layar dipantau terus. Dialog baru ditampilkan setelah
     * kalimatnya utuh (layar diam dua pemeriksaan + hasil baca sama dua kali berturut-turut).
     */
    private fun startLive() {
        if (liveJob?.isActive == true) return
        tJob?.cancel()
        tActive = true
        tHasResult = false
        tShowingOriginal = false
        tOverlay.clear()
        tOverlay.visibility = View.VISIBLE
        status("Live translate dialog aktif (seluruh layar). Ketuk logo terjemahan lagi untuk berhenti.")
        liveJob = lifecycleScope.launch {
            var lastSig = ""
            var pendingSig = ""
            var pendingCount = 0
            try {
                while (isActive) {
                    delay(if (pendingSig.isEmpty()) 600 else 450)
                    if (menuOpen || dialogCount > 0 || padEditing || tShowingOriginal) continue
                    var f = FrameCapture.grab(glView) ?: continue
                    val shown = tFrame
                    if (pendingSig.isEmpty() && shown != null && FrameCapture.frameDiff(shown, f) <= 0.0005f) { f.recycle(); continue }
                    var calmRun = 0
                    var tries = 0
                    while (calmRun < 2 && tries < 8) {
                        delay(200)
                        val g = FrameCapture.grab(glView) ?: break
                        calmRun = if (FrameCapture.frameDiff(f, g) <= 0.0005f) calmRun + 1 else 0
                        f.recycle(); f = g
                        tries++
                    }
                    configureTranslator()
                    translator.menuMode = false
                    val result = translator.run(f, appSettings.translateSource, false, false, Paths.glossary(this@SeedlessNdsActivity), null) { msg ->
                        withContext(Dispatchers.Main.immediate) {
                            if (msg.isEmpty()) tToast?.cancel() else status(msg, true)
                        }
                    }
                    setFrame(f)                                   // pembanding berikutnya
                    val shownBlocks = result?.blocks?.filter { it.box != null }.orEmpty()
                    if (shownBlocks.isEmpty()) {
                        if (tHasResult) { tOverlay.clear(); tHasResult = false }
                        lastSig = ""; pendingSig = ""; pendingCount = 0
                    } else {
                        val sig = shownBlocks.joinToString("|") { it.original }.filterNot { it.isWhitespace() }
                        when {
                            sig == lastSig && tHasResult -> { pendingSig = ""; pendingCount = 0 }
                            sig == pendingSig || pendingCount >= 3 -> {
                                tOverlay.show(
                                    result!!.blocks, result.frameW, result.frameH,
                                    glView.left.toFloat(), glView.top.toFloat(), null,
                                    appSettings.translateFontMin, appSettings.translateFontMax
                                )
                                tHasResult = true
                                lastSig = sig; pendingSig = ""; pendingCount = 0
                            }
                            else -> {
                                if (tHasResult) { tOverlay.clear(); tHasResult = false; lastSig = "" }
                                pendingSig = sig; pendingCount++
                            }
                        }
                    }
                    if (pendingSig.isEmpty()) delay(700)
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                status(
                    if (appSettings.translateOnline) "Live translate berhenti: ${e.message ?: e.javaClass.simpleName}."
                    else "Live translate berhenti: ${e.message ?: e.javaClass.simpleName}. Model offline butuh internet saat pertama dipakai.",
                    true
                )
                closeTranslation()
            }
        }
    }

    private fun startTranslation(thorough: Boolean, reuse: Boolean) {
        if (liveJob?.isActive == true) return
        tJob?.cancel()
        tJob = lifecycleScope.launch {
            var frame = if (reuse) tFrame else null
            if (frame == null) {
                frame = FrameCapture.grabStable(glView)      // ditangkap saat game masih berjalan, setelah teks selesai muncul
                if (frame == null) {
                    status(if (FrameCapture.supported()) "Gagal menangkap layar game" else "Terjemahan butuh Android 7.0 ke atas")
                    return@launch
                }
                setFrame(frame)
            }
            tActive = true
            tHasResult = false
            tShowingOriginal = false
            if (!appSettings.translateLive) pauseForOverlay()   // mode tanpa jeda: game tetap berjalan
            tOverlay.clear()
            tOverlay.visibility = View.VISIBLE
            try {
                configureTranslator()
                translator.menuMode = appSettings.translateKind == 1
                val result = translator.run(frame, appSettings.translateSource, false, thorough, Paths.glossary(this@SeedlessNdsActivity), null) { msg ->
                    withContext(Dispatchers.Main.immediate) {
                        if (msg.isEmpty()) tToast?.cancel() else status(msg, true)
                    }
                }
                when {
                    result == null -> {
                        status("${if (appSettings.translateKind == 1) "Menu" else "Teks"} tidak terbaca ${translator.debugSummary()}", true)
                        closeTranslation()
                    }
                    result.blocks.none { it.box != null } && result.failed > 0 -> {
                        status("Teks terbaca acak/tidak jelas, jadi tidak ditimpa. Coba lagi saat dialog sudah tampil penuh, atau pakai \"Baca ulang terjemahan (mode teliti)\".", true)
                        closeTranslation()
                    }
                    result.blocks.none { it.box != null } -> {
                        status("Tidak ada teks yang perlu diterjemahkan (sudah berbahasa Indonesia, atau hanya nama/angka).", true)
                        closeTranslation()
                    }
                    else -> {
                        tOverlay.show(
                            result.blocks, result.frameW, result.frameH,
                            glView.left.toFloat(), glView.top.toFloat(), null,
                            appSettings.translateFontMin, appSettings.translateFontMax
                        )
                        tHasResult = true
                        tToast?.cancel()
                    }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                status(
                    if (appSettings.translateOnline) "Gagal: ${e.message ?: e.javaClass.simpleName}."
                    else "Gagal: ${e.message ?: e.javaClass.simpleName}. Model terjemahan offline diunduh sekali saat pertama dipakai, jadi butuh internet.",
                    true
                )
                closeTranslation()
            }
        }
    }

    private fun closeTranslation() {
        tJob?.cancel()
        preJob?.cancel(); preJob = null
        liveJob?.cancel(); liveJob = null
        tActive = false
        tPre = false
        tHasResult = false
        tShowingOriginal = false
        tOverlay.clear()
        tOverlay.visibility = View.VISIBLE
        releaseOverlayPause()
        setFrame(null)
    }

    /** Menu "Terjemahan…" di menu jeda: semua pilihan terjemahan di satu tempat (selain gestur pada ikon). */
    private fun showTranslationMenu() {
        val rows = ArrayList<Pair<String, () -> Unit>>()
        fun row(label: String, action: () -> Unit) { rows.add(label to action) }
        row("Mesin terjemahan…") { showTranslateEngineChooser() }
        row("Jenis teks (dialog / menu awal game)…") { showTranslateKindChooser() }
        row("Mode terjemahan: ${if (appSettings.translateLive) "tanpa jeda" else "dengan jeda"} (ketuk untuk ganti)") { showTranslateModeChooser() }
        row("Live translate dialog: ${if (appSettings.translateAuto) "aktif" else "mati"} (ketuk untuk ganti)") {
            appSettings.translateAuto = !appSettings.translateAuto
            if (appSettings.translateAuto) {
                if (tActive) closeTranslation()
                // dimulai setelah menu ditutup (game lanjut berjalan)
                uiHandler.post { startLive() }
            } else {
                if (liveJob?.isActive == true) closeTranslation()
                status("Live translate dialog mati")
            }
        }
        if (tActive && tHasResult && liveJob?.isActive != true) {
            row("Teks di layar: ${if (tShowingOriginal) "asli" else "terjemahan"} (ketuk untuk ganti)") {
                tShowingOriginal = !tShowingOriginal
                tOverlay.visibility = if (tShowingOriginal) View.GONE else View.VISIBLE
            }
            row("Baca ulang terjemahan (mode teliti)") { startTranslation(thorough = true, reuse = true) }
        }
        row("Diagnosis: apa yang dibaca OCR terakhir") {
            dlg(AlertDialog.Builder(this)
                .setTitle("Hasil baca OCR terakhir")
                .setMessage(translator.lastDebug.ifBlank { "(belum ada hasil baca)" })
                .setPositiveButton("Tutup", null))
        }
        AlertDialog.Builder(this).setTitle("Terjemahan")
            .setItems(rows.map { it.first }.toTypedArray()) { _, i ->
                rows[i].second()
                closeMenu(resume = true)
            }
            .setNegativeButton("Kembali") { _, _ -> closeMenu(resume = true) }
            .setOnCancelListener { closeMenu(resume = true) }
            .show()
    }

    // ---------------------------------------------------------------- input

    /** Tombol Android (dari pad layar maupun gamepad fisik) ke bit core; -1 = bukan tombol game. */
    private fun keyToBit(code: Int): Int = when (code) {
        KeyEvent.KEYCODE_DPAD_UP -> 0
        KeyEvent.KEYCODE_DPAD_DOWN -> 1
        KeyEvent.KEYCODE_DPAD_LEFT -> 2
        KeyEvent.KEYCODE_DPAD_RIGHT -> 3
        KeyEvent.KEYCODE_BUTTON_A -> 4
        KeyEvent.KEYCODE_BUTTON_B -> 5
        KeyEvent.KEYCODE_BUTTON_X -> 6
        KeyEvent.KEYCODE_BUTTON_Y -> 7
        KeyEvent.KEYCODE_BUTTON_L1 -> 8
        KeyEvent.KEYCODE_BUTTON_R1 -> 9
        KeyEvent.KEYCODE_BUTTON_START -> 10
        KeyEvent.KEYCODE_BUTTON_SELECT -> 11
        else -> -1
    }

    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        val bit = keyToBit(e.keyCode)
        if (bit >= 0 && e.device?.isVirtual == false && e.repeatCount == 0 && ::glView.isInitialized) {
            glView.setButton(bit, e.action == KeyEvent.ACTION_DOWN)
            return true
        }
        if ((e.keyCode == KeyEvent.KEYCODE_BUTTON_THUMBL || e.keyCode == KeyEvent.KEYCODE_BUTTON_THUMBR) &&
            e.device?.isVirtual == false) {
            if (e.action == KeyEvent.ACTION_DOWN && e.repeatCount == 0) swapScreensNow()
            return true
        }
        // R2 = fast forward (hidup/mati), L2 = terjemahkan layar / tutup terjemahan
        if ((e.keyCode == KeyEvent.KEYCODE_BUTTON_R2 || e.keyCode == KeyEvent.KEYCODE_BUTTON_L2) && e.device?.isVirtual == false) {
            if (e.action == KeyEvent.ACTION_DOWN && e.repeatCount == 0 && !menuOpen && !padEditing) {
                if (e.keyCode == KeyEvent.KEYCODE_BUTTON_R2) toggleFastForward() else toggleTranslation()
            }
            return true
        }
        if (e.keyCode == KeyEvent.KEYCODE_BUTTON_MODE && e.action == KeyEvent.ACTION_DOWN) { showMenu(); return true }
        return super.dispatchKeyEvent(e)
    }

    override fun onGenericMotionEvent(e: MotionEvent): Boolean {
        if (::glView.isInitialized && e.source and InputDevice.SOURCE_JOYSTICK != 0 && e.action == MotionEvent.ACTION_MOVE) {
            val x = e.getAxisValue(MotionEvent.AXIS_HAT_X).let { if (it == 0f) e.getAxisValue(MotionEvent.AXIS_X) else it }
            val y = e.getAxisValue(MotionEvent.AXIS_HAT_Y).let { if (it == 0f) e.getAxisValue(MotionEvent.AXIS_Y) else it }
            val nx = if (x < -0.5f) -1 else if (x > 0.5f) 1 else 0
            val ny = if (y < -0.5f) -1 else if (y > 0.5f) 1 else 0
            if (nx != hatX) { glView.setButton(2, nx < 0); glView.setButton(3, nx > 0); hatX = nx }
            if (ny != hatY) { glView.setButton(0, ny < 0); glView.setButton(1, ny > 0); hatY = ny }
            return true
        }
        return super.onGenericMotionEvent(e)
    }

    // ---------------------------------------------------------------- lifecycle

    private fun enterImmersive() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) enterImmersive()
    }

    override fun onPause() {
        super.onPause()
        if (!::glView.isInitialized) return
        glView.releaseAll()
        if (tActive) closeTranslation()
        setPaused(true)
        glView.onPause()
    }

    override fun onResume() {
        super.onResume()
        if (!::glView.isInitialized) return
        glView.onResume()
        refreshGamepad()
        updatePause()
    }

    override fun onDestroy() {
        runCatching { inputManager.unregisterInputDeviceListener(deviceListener) }
        uiHandler.removeCallbacks(fpsTick)
        tJob?.cancel(); preJob?.cancel(); liveJob?.cancel()
        if (::freezeView.isInitialized) freezeView.setImageDrawable(null)
        runCatching { translator.close() }
        if (::glView.isInitialized) closeCore(renderMs = 400, emuMs = 3500)
        super.onDestroy()
    }

    // ---------------------------------------------------------------- penutupan core

    /**
     * Keluar ke library tanpa menutup aplikasi. Penutupan core (menunggu thread render dan thread emulasi) dikerjakan di
     * latar belakang supaya layar tidak macet; activity baru di-finish setelah core benar-benar berhenti.
     */
    private fun exitToLibrary() {
        if (closing) return
        if (!::glView.isInitialized) { finish(); return }
        closing = true
        uiHandler.removeCallbacks(fpsTick)
        Toast.makeText(this, "Menutup game…", Toast.LENGTH_SHORT).show()
        Thread {
            closeCore(renderMs = 800, emuMs = 5000)
            runOnUiThread { if (!isFinishing) finish() }
        }.apply { name = "seedless-close"; start() }
    }

    /**
     * Tutup core dengan urutan yang aman (idempotent):
     * 1) lepaskan thread render dari core, 2) tutup [SeedlessGate] supaya tidak ada lagi panggilan layar,
     * 3) minta core berhenti dan tunggu thread emulasi selesai, 4) baru lepaskan sumber daya core.
     * Core menghancurkan mutex layar saat game berhenti; memanggil signalScreen()/waitScreen() sesudahnya membuat proses
     * ter-abort (SIGABRT 134), itulah penyebab aplikasi tertutup saat keluar ke library.
     */
    private fun closeCore(renderMs: Long, emuMs: Long) {
        synchronized(closeLock) {
            if (coreClosed) return
            closing = true
            runCatching { glView.releaseAll() }
            runCatching { glView.detachCore(renderMs) }
            SeedlessGate.close()
            val t = emuThread
            var ended = t == null || !t.isAlive
            if (!ended) {
                try { SeedlessCore.quit() } catch (_: Throwable) {}
                val deadline = System.currentTimeMillis() + emuMs
                var requeued = false
                while (t!!.isAlive && System.currentTimeMillis() < deadline) {
                    runCatching { t.join(100) }
                    // Permintaan berhenti bisa hilang bila game baru mulai memuat; ulangi sekali saja (jangan berulang: audio core
                    // sudah dibongkar saat game berhenti).
                    if (!requeued && t.isAlive && System.currentTimeMillis() > deadline - emuMs / 2) {
                        requeued = true
                        try { SeedlessCore.quit() } catch (_: Throwable) {}
                    }
                }
                ended = !t.isAlive
            }
            if (ended) {
                // Core sudah membongkar audio/layarnya sendiri; release() aman (dijaga flag di core). Game berikutnya wajib
                // membuat ulang konteks layar lewat attachSurface karena mutex-nya sudah dihancurkan.
                try { SeedlessCore.release() } catch (_: Throwable) {}
                inited = false
            }
            // Bila thread belum selesai: jangan release (bisa abort); game berikutnya menunggu thread ini lewat [lastEmu].
            else pendingRelease = true
            coreClosed = true
        }
    }
}
