/*
 * mgba_link: core libretro GBA dengan LINK CABLE untuk 2 pemain.
 *
 * Isi: DUA GBA virtual (instance mGBA A dan B) dalam satu core, dihubungkan oleh driver SIO buatan sendiri
 * (satu thread, deterministik). Tiap frame: A dan B masing-masing menjalankan satu frame, tombol port 0 -> A,
 * port 1 -> B. Layar/suara yang keluar hanya milik pemain lokal (opsi "mgba_link_view": 0 = A, 1 = B).
 * Netplay rollback bawaan aplikasi dipakai apa adanya: kedua HP menjalankan A dan B yang identik dari input yang
 * sama, jadi state yang diserialisasi = A + B + state driver link.
 *
 * Dibuat terhadap mGBA 0.10.x (lihat scripts/build_mgba_link_core.sh). Bagian yang memakai API internal mGBA
 * ditandai "API-INTERNAL": kalau build gagal, kemungkinan besar di situ.
 */
#define _GNU_SOURCE
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <time.h>
#include <unistd.h>
#include <sched.h>
#include <dlfcn.h>
#include <stdint.h>
#include <sys/resource.h>
#include <sys/syscall.h>
#include <pthread.h>
#include <stdatomic.h>
#include "libretro.h"

#include <mgba/core/core.h>
#include <mgba/core/timing.h>
#include <mgba/core/blip_buf.h>
#include <mgba/gba/core.h>
#include <mgba/internal/gba/gba.h>
#include <mgba/internal/gba/io.h>
#include <mgba/internal/gba/sio.h>
#include <mgba-util/vfs.h>

#define W 240
#define H 160
#define SAMPLES 1024
#define SAVE_MAX 0x20010

/* offset register I/O GBA */
#define R_SIOMULTI0 0x120
#define R_SIOCNT    0x128
#define R_SIOSEND   0x12A   /* SIOMLT_SEND = SIODATA8 */
#define R_RCNT      0x134

static retro_environment_t env_cb;
static retro_video_refresh_t video_cb;
static retro_audio_sample_batch_t audio_cb;
static retro_input_poll_t poll_cb;
static retro_input_state_t input_cb;

typedef struct Node {
    struct GBASIODriver d;          /* harus pertama: dipakai sebagai driver */
    struct mTimingEvent done;       /* transfer selesai */
    int id;                         /* 0 = parent (A), 1 = child (B) */
    struct Node* peer;
    struct mCore* core;
    int pending;                    /* transfer sedang berjalan (diserialisasi) */
    int startReq, startMode;        /* parent minta mulai transfer; dijalankan di akhir frame (selalu 0 saat savestate) */
    uint16_t latch[3];              /* data yang dikirim parent saat start: SIODATA8, SIOMULTI0, SIOMULTI1 */
} Node;

typedef struct {
    struct mCore* core;
    Node node;
    color_t video[W * H];
    uint8_t save[SAVE_MAX];
    void* rom;                      /* salinan ROM milik instance ini (tidak dibagi) */
    int hasRom;
} Inst;

static void boost_release(void);
static void worker_start(void);
static void worker_stop(void);
static Inst inst[2];
static int view = 0;
static int useThreads;               /* variabel core "mgba_link_threads" = 1 -> GBA 1 dan 2 paralel; bawaan 0 (berurutan, seperti v6) */
static int netMode;                 /* 1 setelah savestate pertama dipakai (= netplay) */
static void* romData; static size_t romSize;
static int loading;                 /* >0 saat loadState: mGBA memutar ulang penulisan register, jangan memicu transfer */
static int16_t audioBuf[SAMPLES * 2];
static char saveDir[1024], romName[256];


/* Log langkah ke <save_dir>/mgba_link_debug.txt supaya crash native bisa dilacak sampai langkah terakhir. */
static void dbg(const char* msg, int a) {
    char p[1400]; snprintf(p, sizeof p, "%s/mgba_link_debug.txt", saveDir[0] ? saveDir : ".");
    FILE* f = fopen(p, "ab"); if (!f) return;
    fprintf(f, "%s %d\n", msg, a); fclose(f);
}

static int siolog_n;
static int last[2][3][3], rep[2][3], seen[2][3];
/* Catatan SIO tanpa pengulangan: baris yang sama persis dengan sebelumnya (per GBA & jenis) tidak ditulis lagi, hanya dihitung. */
static pthread_mutex_t logMu = PTHREAD_MUTEX_INITIALIZER;   /* siolog dipanggil dari thread GBA 1 dan GBA 2 */
static void siolog_impl(const char* what, int id, int a, int b, int c) {
    if (loading || id < 0 || id > 1) return;
    int k = (what[0] == 'w') ? 0 : (what[0] == 's') ? 1 : 2;
    if (seen[id][k] && last[id][k][0] == a && last[id][k][1] == b && last[id][k][2] == c) { rep[id][k]++; return; }
    if (siolog_n >= 400) return;
    char p[1400]; snprintf(p, sizeof p, "%s/mgba_link_debug.txt", saveDir[0] ? saveDir : ".");
    FILE* f = fopen(p, "ab"); if (!f) return;
    if (rep[id][k] > 0) fprintf(f, "   ^ (%d kali lagi, gba=%d)\n", rep[id][k], id);
    fprintf(f, "SIO %s gba=%d a=0x%X b=0x%X c=%d\n", what, id, a, b, c); fclose(f);
    siolog_n++; last[id][k][0] = a; last[id][k][1] = b; last[id][k][2] = c; rep[id][k] = 0; seen[id][k] = 1;
}

static void siolog(const char* what, int id, int a, int b, int c) { pthread_mutex_lock(&logMu); siolog_impl(what, id, a, b, c); pthread_mutex_unlock(&logMu); }

/* Log isi data yang dipertukarkan (tanpa duplikat berurutan, maksimal 150 baris) untuk membandingkan kedua HP. */
static int xlog_n; static char xlog_last[96];
static void xlog_impl(int mode, int sa, int sb, int peerOk) {
    if (loading || xlog_n >= 150) return;
    char line[96]; snprintf(line, sizeof line, "XFER mode=%d parent=0x%X child=0x%X ok=%d", mode, sa, sb, peerOk);
    if (!strcmp(line, xlog_last)) return;
    snprintf(xlog_last, sizeof xlog_last, "%s", line);
    char p[1400]; snprintf(p, sizeof p, "%s/mgba_link_debug.txt", saveDir[0] ? saveDir : ".");
    FILE* f = fopen(p, "ab"); if (!f) return;
    fprintf(f, "%s\n", line); fclose(f); xlog_n++;
}

static void xlog(int mode, int sa, int sb, int peerOk) { pthread_mutex_lock(&logMu); xlog_impl(mode, sa, sb, peerOk); pthread_mutex_unlock(&logMu); }

static struct GBA* gbaOf(Node* n) { return (struct GBA*) n->core->board; }              /* API-INTERNAL */
static uint16_t* io(Node* n) { return gbaOf(n)->memory.io; }                            /* API-INTERNAL */

/* ---- driver SIO: Multi-Player (mode 2) dan Normal (8/32-bit), pertukaran data langsung antar dua instance ---- */

static void finish(struct mTiming* t, void* ctx, uint32_t late) {
    Node* n = ctx; (void) t;
    struct GBASIO* sio = &gbaOf(n)->sio;            /* API-INTERNAL: game membaca SIOCNT dari sio->siocnt, bukan dari memory.io */
    siolog("finish", n->id, sio->siocnt, 0, 0);
    sio->siocnt &= ~0x0080;                         /* bit start/busy = 0 */
    n->pending = 0;
    if (sio->siocnt & 0x4000) GBARaiseIRQ(gbaOf(n), GBA_IRQ_SIO, late);   /* API-INTERNAL */
}

static void schedule(Node* n, int32_t cycles) {
    mTimingDeschedule(&gbaOf(n)->timing, &n->done);
    mTimingSchedule(&gbaOf(n)->timing, &n->done, cycles);
    n->pending = 1;
}

/* Lama satu transfer Multi-Player (siklus CPU), menurut baud (SIOCNT bit 0-1) dan jumlah GBA yang terhubung (1 atau 2).
   Nilai mengikuti tabel GBASIOCyclesPerTransfer milik mGBA; sebelumnya 1600 siklus, terlalu cepat dibanding GBA asli,
   sehingga game yang menghitung waktu bisa menganggap kabel tidak terpasang. */
static const int32_t kMultiCycles[4][2] = { {31976, 63427}, {8378, 16241}, {5750, 10998}, {3140, 5565} };

/* Mulai transfer dari parent (id 0). Child ikut sibuk sampai transfer selesai. */
static void begin_transfer(Node* n, int mode) {
    Node* c = n->peer;
    uint16_t* a = io(n);
    uint16_t* b = io(c);
    struct GBASIO* sc = &gbaOf(c)->sio;
    int peerOk = ((int) sc->mode == mode);          /* child belum di mode yang sama = dianggap tidak terhubung */
    siolog("start", n->id, mode, (int) sc->mode, peerOk);
    if (mode == 2) {                                /* Multi-Player */
        int32_t cyc = kMultiCycles[gbaOf(n)->sio.siocnt & 3][peerOk ? 1 : 0];
        uint16_t sa = n->latch[0], sb = peerOk ? b[R_SIOSEND >> 1] : 0xFFFF;
        xlog(2, sa, sb, peerOk);
        a[R_SIOMULTI0 >> 1] = sa;               a[(R_SIOMULTI0 >> 1) + 1] = sb;
        a[(R_SIOMULTI0 >> 1) + 2] = 0xFFFF;     a[(R_SIOMULTI0 >> 1) + 3] = 0xFFFF;
        if (peerOk) {
            b[R_SIOMULTI0 >> 1] = sa;           b[(R_SIOMULTI0 >> 1) + 1] = sb;
            b[(R_SIOMULTI0 >> 1) + 2] = 0xFFFF; b[(R_SIOMULTI0 >> 1) + 3] = 0xFFFF;
            sc->siocnt = (sc->siocnt & ~0x0030) | (1 << 4) | 0x0080;     /* ID child = 1, busy */
            schedule(c, cyc);
        }
        schedule(n, cyc);
    } else {                                        /* Normal 8/32-bit: tukar register data */
        int w32 = (mode == 1);
        if (peerOk) {
            uint16_t t0 = n->latch[1], t1 = n->latch[2];
            uint16_t u0 = b[R_SIOMULTI0 >> 1], u1 = b[(R_SIOMULTI0 >> 1) + 1];
            if (w32) { a[R_SIOMULTI0 >> 1] = u0; a[(R_SIOMULTI0 >> 1) + 1] = u1; b[R_SIOMULTI0 >> 1] = t0; b[(R_SIOMULTI0 >> 1) + 1] = t1; }
            else     { uint16_t x = n->latch[0], y = b[R_SIOSEND >> 1]; a[R_SIOSEND >> 1] = y; b[R_SIOSEND >> 1] = x; }
            sc->siocnt |= 0x0080;
            schedule(c, w32 ? 4096 : 1024);
        }
        schedule(n, w32 ? 4096 : 1024);
    }
}

static uint16_t drv_write(struct GBASIODriver* d, uint32_t address, uint16_t value) {
    Node* n = (Node*) d;
    if (address != R_SIOCNT) return value;
    struct GBASIO* sio = d->p;
    int mode = (int) sio->mode;                     /* sudah di-update mGBA sebelum driver dipanggil */
    int start = (value & 0x0080) != 0;
    siolog("write", n->id, value, mode, n->pending);
    if (mode == 2) {
        /* Bit hanya-baca pada mode Multi-Player: SI (bit2), SD (bit3), ID (bit4-5). Tanpa SD=1 game menganggap kabel tidak terpasang.
           Dibentuk SELALU, termasuk saat loadState (mGBA menulis ulang SIOCNT), supaya bit-bit ini tidak hilang setelah rollback. */
        uint16_t id = loading ? (value & 0x0030) : (sio->siocnt & 0x0030);
        value &= ~0x003C;
        value |= 0x0008;                            /* SD = 1: semua GBA siap */
        if (n->id) value |= 0x0004;                 /* SI = 1 pada child */
        value |= id;                                /* ID dipertahankan (diisi setelah transfer pertama) */
    }
    if (loading) return value;                      /* saat loadState: jangan picu transfer / ubah status sibuk */
    if (n->id != 0) {                               /* child tidak bisa memulai transfer sendiri */
        value = (value & ~0x0080) | (n->pending ? 0x0080 : 0);
    } else if (n->pending || n->startReq) {
        value |= 0x0080;                            /* masih sibuk */
    } else if (start && (mode == 0 || mode == 1 || mode == 2)) {
        /* Dua GBA dijalankan bergantian per FRAME (A penuh dulu, lalu B), bukan serempak. Kalau transfer dimulai di tengah
           frame A, B masih berada di akhir frame sebelumnya: data kirim B basi dan waktu selesai transfer B meleset, sehingga
           game melihat pertukaran yang tidak masuk akal (Communication Error). Karena itu data dikunci sekarang, tetapi
           transfer baru dimulai di batas frame, saat A dan B sudah menjalani waktu virtual yang sama. */
        uint16_t* a = io(n);
        n->latch[0] = a[R_SIOSEND >> 1]; n->latch[1] = a[R_SIOMULTI0 >> 1]; n->latch[2] = a[(R_SIOMULTI0 >> 1) + 1];
        n->startReq = 1; n->startMode = mode;
        value |= 0x0080;
    }
    return value;
}

static bool drv_init(struct GBASIODriver* d) { Node* n = (Node*) d; n->done.context = n; n->done.name = "link"; n->done.callback = finish; n->done.priority = 0x80; return true; }
static void drv_deinit(struct GBASIODriver* d) { (void) d; }
static bool drv_load(struct GBASIODriver* d) { (void) d; return true; }
static bool drv_unload(struct GBASIODriver* d) { (void) d; return true; }

static void attach(int i) {
    Node* n = &inst[i].node;
    memset(&n->d, 0, sizeof(n->d));
    n->core = inst[i].core; n->id = i; n->peer = &inst[1 - i].node;
    n->d.init = drv_init; n->d.deinit = drv_deinit;   /* 0.10.3: tidak ada member 'reset' */
    n->d.load = drv_load; n->d.unload = drv_unload; n->d.writeRegister = drv_write;
    GBASIOSetDriver(&gbaOf(n)->sio, &n->d, 2);   /* mode 2 = Multi-Player (API-INTERNAL, 0.10: butuh mode) */
    GBASIOSetDriver(&gbaOf(n)->sio, &n->d, 0);   /* mode 0 = Normal (slot yang sama dipakai Normal 8 & 32-bit) */
}

/* ---- libretro ---- */

static void load_var(void) {
    struct retro_variable v = { "mgba_link_view", NULL };
    if (env_cb(RETRO_ENVIRONMENT_GET_VARIABLE, &v) && v.value) view = (v.value[0] == '1');
    struct retro_variable t = { "mgba_link_threads", NULL };
    if (env_cb(RETRO_ENVIRONMENT_GET_VARIABLE, &t) && t.value) useThreads = (t.value[0] == '1');
}

void retro_set_environment(retro_environment_t cb) {
    env_cb = cb;
    static const struct retro_variable vars[] = {
        { "mgba_link_view", "Layar yang tampil; 0|1" }, { "mgba_link_threads", "Thread paralel; 0|1" }, { "mgba_frameskip", "Frameskip; 0" }, { NULL, NULL } };
    cb(RETRO_ENVIRONMENT_SET_VARIABLES, (void*) vars);
}
void retro_set_video_refresh(retro_video_refresh_t cb) { video_cb = cb; }
void retro_set_audio_sample(retro_audio_sample_t cb) { (void) cb; }
void retro_set_audio_sample_batch(retro_audio_sample_batch_t cb) { audio_cb = cb; }
void retro_set_input_poll(retro_input_poll_t cb) { poll_cb = cb; }
void retro_set_input_state(retro_input_state_t cb) { input_cb = cb; }
unsigned retro_api_version(void) { return RETRO_API_VERSION; }
void retro_init(void) {}
void retro_deinit(void) {}
void retro_set_controller_port_device(unsigned p, unsigned d) { (void) p; (void) d; }

void retro_get_system_info(struct retro_system_info* i) {
    memset(i, 0, sizeof(*i));
    i->library_name = "mGBA Link"; i->library_version = "0.10-link"; i->valid_extensions = "gba"; i->need_fullpath = false;
}
void retro_get_system_av_info(struct retro_system_av_info* i) {
    memset(i, 0, sizeof(*i));
    i->geometry.base_width = i->geometry.max_width = W; i->geometry.base_height = i->geometry.max_height = H;
    i->geometry.aspect_ratio = 3.0f / 2.0f; i->timing.fps = 59.7275; i->timing.sample_rate = 32768;
}

static void open_inst(int i) {
    dbg("open_inst: mulai", i);
    struct mCore* c = GBACoreCreate();
    if (!c) { dbg("GBACoreCreate NULL", i); return; }
    c->init(c);
    dbg("init ok", i);
    mCoreInitConfig(c, NULL);                      /* seperti port libretro resmi: config harus diinisialisasi */
    dbg("config ok", i);
    c->setVideoBuffer(c, inst[i].video, W);
    c->setAudioBufferSize(c, SAMPLES);
    blip_t* bl = c->getAudioChannel(c, 0); blip_t* br = c->getAudioChannel(c, 1);
    if (bl && br) {
        blip_set_rates(bl, c->frequency(c), 32768);                                     /* API-INTERNAL (0.10) */
        blip_set_rates(br, c->frequency(c), 32768);
    } else dbg("audio channel NULL", i);
    dbg("audio ok", i);
    inst[i].rom = malloc(romSize);
    if (!inst[i].rom) { dbg("malloc rom gagal", i); return; }
    memcpy(inst[i].rom, romData, romSize);
    if (!c->loadROM(c, VFileFromMemory(inst[i].rom, romSize))) dbg("loadROM GAGAL", i);
    dbg("loadROM ok", i);
    memset(inst[i].save, 0xFF, SAVE_MAX);
    if (i == 1) {                                  /* GBA 2 punya file save sendiri: <rom>.link2.sav */
        char p[1400]; snprintf(p, sizeof p, "%s/%s.link2.sav", saveDir, romName);
        FILE* f = fopen(p, "rb"); if (f) { size_t rd = fread(inst[i].save, 1, SAVE_MAX, f); (void) rd; fclose(f); }
    }
    c->loadSave(c, VFileFromMemory(inst[i].save, SAVE_MAX));
    dbg("loadSave ok", i);
    inst[i].core = c;
}

bool retro_load_game(const struct retro_game_info* g) {
    enum retro_pixel_format fmt = RETRO_PIXEL_FORMAT_XRGB8888;
    if (!g || !g->data || !env_cb(RETRO_ENVIRONMENT_SET_PIXEL_FORMAT, &fmt)) return false;
    romData = malloc(g->size); memcpy(romData, g->data, g->size); romSize = g->size;
    const char* sd = NULL; env_cb(RETRO_ENVIRONMENT_GET_SAVE_DIRECTORY, &sd);
    snprintf(saveDir, sizeof saveDir, "%s", sd ? sd : ".");
    const char* b = g->path ? strrchr(g->path, '/') : NULL; b = b ? b + 1 : (g->path ? g->path : "game");
    snprintf(romName, sizeof romName, "%s", b); char* dot = strrchr(romName, '.'); if (dot) *dot = 0;
    { char lp[1400]; snprintf(lp, sizeof lp, "%s/mgba_link_debug.txt", saveDir); FILE* lf = fopen(lp, "wb"); if (lf) fclose(lf); }   /* kosongkan log lama */
    xlog_n = 0; xlog_last[0] = 0; siolog_n = 0; memset(last, 0, sizeof last); memset(rep, 0, sizeof rep); memset(seen, 0, sizeof seen);
    dbg("VERSI CORE LOG: v8-thread-opsional (kalau baris ini tidak ada, APK masih build lama)", 4);
    dbg("retro_load_game: mulai, rom bytes", (int) romSize);
    for (int i = 0; i < 2; i++) open_inst(i);
    if (!inst[0].core || !inst[1].core) { dbg("open_inst gagal", 0); return false; }
    for (int i = 0; i < 2; i++) { attach(i); dbg("attach ok", i); }
    for (int i = 0; i < 2; i++) { inst[i].core->reset(inst[i].core); dbg("reset ok", i); }
    load_var();
    worker_start();
    dbg("retro_load_game: selesai", 0);
    return true;
}
bool retro_load_game_special(unsigned t, const struct retro_game_info* g, size_t n) { (void) t; (void) g; (void) n; return false; }

void retro_unload_game(void) {
    worker_stop();
    boost_release();
    if (inst[1].core) {                            /* simpan save GBA 2 */
        char p[1400]; snprintf(p, sizeof p, "%s/%s.link2.sav", saveDir, romName);
        FILE* f = fopen(p, "wb"); if (f) { fwrite(inst[1].save, 1, 0x20000, f); fclose(f); }
    }
    for (int i = 0; i < 2; i++) if (inst[i].core) { mCoreConfigDeinit(&inst[i].core->config); inst[i].core->deinit(inst[i].core); inst[i].core = NULL; }
    for (int i = 0; i < 2; i++) { free(inst[i].rom); inst[i].rom = NULL; }
    free(romData); romData = NULL;
}

static uint32_t keys_for(unsigned port) {
    static const unsigned map[10] = { RETRO_DEVICE_ID_JOYPAD_A, RETRO_DEVICE_ID_JOYPAD_B, RETRO_DEVICE_ID_JOYPAD_SELECT,
        RETRO_DEVICE_ID_JOYPAD_START, RETRO_DEVICE_ID_JOYPAD_RIGHT, RETRO_DEVICE_ID_JOYPAD_LEFT, RETRO_DEVICE_ID_JOYPAD_UP,
        RETRO_DEVICE_ID_JOYPAD_DOWN, RETRO_DEVICE_ID_JOYPAD_R, RETRO_DEVICE_ID_JOYPAD_L };
    uint32_t k = 0;
    for (int b = 0; b < 10; b++) if (input_cb(port, RETRO_DEVICE_JOYPAD, 0, map[b])) k |= 1u << b;   /* urutan bit GBA */
    return k;
}

static uint64_t now_us(void) { struct timespec t; clock_gettime(CLOCK_MONOTONIC, &t); return (uint64_t) t.tv_sec * 1000000u + (uint64_t) t.tv_nsec / 1000u; }
/* ---- Dorongan performa thread emulasi (HANYA core GBA Link; tidak menyentuh state emulasi, jadi aman untuk netplay) ----
   Beban core ~2-8 ms dari jatah 16,6 ms, jadi thread sering "tidur" dan scheduler Android menurunkan frekuensi CPU atau
   memindahkannya ke inti kecil; frame yang berat lalu lewat jatah = patah-patah. Tiga langkah, semuanya boleh gagal diam-diam:
   1) prioritas thread dinaikkan, 2) thread dikunci ke inti besar/menengah saja, 3) Android Performance Hint (API 33+) diberi tahu
   durasi kerja nyata per frame supaya frekuensi CPU dinaikkan tepat waktu. */
#define BURST_GAP_US 1500           /* jeda lebih dari ini antar pemanggilan core = frame baru (thread menunggu vsync) */
#define FRAME_BUDGET_US 16600
typedef void* (*hint_mgr_fn)(void);
typedef void* (*hint_create_fn)(void*, const int32_t*, size_t, int64_t);
typedef int   (*hint_report_fn)(void*, int64_t);
typedef void  (*hint_close_fn)(void*);
static int boostTid, boostPrio, boostAff, boostNcpu; static long boostTop;
static void* hintSession; static hint_report_fn hintReport; static hint_close_fn hintClose;
static uint64_t burstStart, lastEnd, burstMax, burstOver, burstTotal;
static uint64_t ser_us, unser_us, ser_n, unser_n;

static cpu_set_t workMask; static atomic_int maskGen;          /* inti yang dipilih; thread pekerja memakainya juga */
static char boostSrc = '-';

static long read_long(const char* path) {
    long v = 0; FILE* f = fopen(path, "r");
    if (f) { if (fscanf(f, "%ld", &v) != 1) v = 0; fclose(f); }
    return v;
}

static void boost_affinity(int tid) {
    long ncpu = sysconf(_SC_NPROCESSORS_CONF);
    if (ncpu < 2 || ncpu > 32) return;
    boostNcpu = (int) ncpu;
    long cap[32], fr[32], capTop = 0, capLow = 0, frTop = 0;
    int capOk = 1;
    for (int c = 0; c < ncpu; c++) {
        char p[96];
        snprintf(p, sizeof p, "/sys/devices/system/cpu/cpu%d/cpu_capacity", c); cap[c] = read_long(p);
        snprintf(p, sizeof p, "/sys/devices/system/cpu/cpu%d/cpufreq/cpuinfo_max_freq", c); fr[c] = read_long(p);
        if (cap[c] <= 0) capOk = 0;
        if (cap[c] > capTop) capTop = cap[c];
        if (fr[c] > frTop) frTop = fr[c];
    }
    for (int c = 0; c < ncpu; c++) if (c == 0 || cap[c] < capLow) capLow = cap[c];
    /* Kapasitas relatif (cpu_capacity) mencerminkan jenis inti + frekuensi; ada HP yang frekuensi maksimum inti kecilnya hampir sama
       dengan inti besar tetapi jauh lebih lambat per siklus (terlihat di log: inti 6-7 ~40% lebih cepat). Frekuensi hanya cadangan. */
    long* v = (capOk && capTop > capLow) ? cap : fr;
    long top = (v == cap) ? capTop : frTop;
    boostSrc = (v == cap) ? 'k' : 'f'; boostTop = top;
    if (top <= 0) { boostSrc = '-'; return; }       /* tidak terbaca (dibatasi sistem): inti tidak dikunci */
    cpu_set_t set; CPU_ZERO(&set); int n = 0;
    for (int c = 0; c < ncpu; c++) if (v[c] * 10 >= top * 7) { CPU_SET(c, &set); n++; }   /* inti >= 70% inti tercepat */
    if (n < 2) {                                    /* dua thread (GBA 1 dan 2) butuh minimal dua inti */
        for (int k = 0; k < 2; k++) {
            int best = -1; for (int c = 0; c < ncpu; c++) if (!CPU_ISSET(c, &set) && (best < 0 || v[c] > v[best])) best = c;
            if (best >= 0) { CPU_SET(best, &set); n++; }
        }
    }
    if (n == 0 || n >= ncpu) return;                /* semua inti setara: tidak ada yang perlu dipilih */
    workMask = set; atomic_fetch_add(&maskGen, 1);
    if (sched_setaffinity(tid, sizeof set, &set) == 0) boostAff = n;
}

static void boost_release(void) {
    if (hintSession && hintClose) hintClose(hintSession);
    hintSession = NULL; boostTid = 0;
}

static void boost_thread(int tid) {
    boost_release();
    boostTid = tid;
    boostPrio = (setpriority(PRIO_PROCESS, (id_t) tid, -8) == 0);
    boost_affinity(tid);
    void* h = dlopen("libandroid.so", RTLD_NOW);
    if (!h) return;
    hint_mgr_fn gm = (hint_mgr_fn) dlsym(h, "APerformanceHint_getManager");
    hint_create_fn cs = (hint_create_fn) dlsym(h, "APerformanceHint_createSession");
    hintReport = (hint_report_fn) dlsym(h, "APerformanceHint_reportActualWorkDuration");
    hintClose = (hint_close_fn) dlsym(h, "APerformanceHint_closeSession");
    if (!gm || !cs || !hintReport) return;          /* Android < 13: tanpa Performance Hint */
    void* m = gm();
    int32_t t = tid;
    if (m) hintSession = cs(m, &t, 1, 16000000LL);  /* target 16 ms per frame */
}

/* Dipanggil di awal retro_run / serialize / unserialize; work_end di akhirnya. Satu "burst" = semua kerja core dalam satu frame
   tampil, termasuk simpan state dan rollback (yang tidak terukur oleh PERF lama). */
static uint64_t work_begin(void) {
    uint64_t t = now_us();
    int tid = (int) syscall(__NR_gettid);
    if (tid != boostTid) { boost_thread(tid); burstStart = 0; }
    if (!burstStart) burstStart = t;
    else if (t - lastEnd > BURST_GAP_US) {          /* burst sebelumnya selesai: laporkan */
        uint64_t d = lastEnd - burstStart;
        burstTotal++; if (d > burstMax) burstMax = d; if (d > FRAME_BUDGET_US) burstOver++;
        if (hintSession && hintReport) hintReport(hintSession, (int64_t) d * 1000);
        burstStart = t;
    }
    return t;
}
static void work_end(void) { lastEnd = now_us(); }

/* ---- Thread pekerja: GBA 2 dijalankan paralel dengan GBA 1 ----
   Selama satu frame, tiap GBA hanya menyentuh state-nya sendiri (register, memori, event timing, driver SIO miliknya). Satu-satunya
   titik yang menyentuh KEDUANYA (begin_transfer) dan semua pembacaan input/gambar/suara tetap di thread utama setelah kedua frame
   selesai (join), jadi hasil emulasi identik dengan urutan A-lalu-B lama: deterministik, aman untuk rollback. Log SIO diberi mutex.
   Hanya aktif bila variabel mgba_link_threads = 1; kalau thread gagal dibuat, core jalan berurutan seperti sebelumnya. */
static pthread_t wThread; static int wStarted;
static pthread_mutex_t wMu = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t wCvGo = PTHREAD_COND_INITIALIZER, wCvDone = PTHREAD_COND_INITIALIZER;
static int wGo, wQuit; static atomic_int wDone; static uint64_t wDt, waitSum;

static void* worker_main(void* arg) {
    (void) arg;
    int tid = (int) syscall(__NR_gettid), gen = 0;
    setpriority(PRIO_PROCESS, (id_t) tid, -8);
    for (;;) {
        pthread_mutex_lock(&wMu);
        while (!wGo && !wQuit) pthread_cond_wait(&wCvGo, &wMu);
        if (wQuit) { pthread_mutex_unlock(&wMu); break; }
        wGo = 0; pthread_mutex_unlock(&wMu);
        int g = atomic_load(&maskGen);
        if (g != gen) { gen = g; sched_setaffinity(tid, sizeof workMask, &workMask); }
        uint64_t t0 = now_us(); inst[1].core->runFrame(inst[1].core); wDt = now_us() - t0;
        atomic_store(&wDone, 1);
        pthread_mutex_lock(&wMu); pthread_cond_signal(&wCvDone); pthread_mutex_unlock(&wMu);
    }
    return NULL;
}

static void worker_start(void) {
    if (!useThreads) { dbg("mode thread: mati (berurutan)", 0); return; }
    if (sysconf(_SC_NPROCESSORS_ONLN) < 2) { dbg("mode thread: tidak (hanya 1 inti)", 0); return; }
    wGo = wQuit = 0; atomic_store(&wDone, 0);
    if (pthread_create(&wThread, NULL, worker_main, NULL) != 0) { dbg("mode thread: gagal dibuat, berurutan", 0); return; }
    wStarted = 1; dbg("mode thread: GBA 1 dan GBA 2 paralel", 1);
}

static void worker_stop(void) {
    if (!wStarted) return;
    pthread_mutex_lock(&wMu); wQuit = 1; pthread_cond_signal(&wCvGo); pthread_mutex_unlock(&wMu);
    pthread_join(wThread, NULL); wStarted = 0;
}

/* Diagnosa lonjakan: di inti CPU mana retro_run berjalan, dan apakah lonjakan = kerja nyata (waktu CPU thread ikut naik)
   atau thread ditunda/dipindah (waktu dinding naik, waktu CPU tidak). */
static uint64_t cpu_us(void) { struct timespec t; clock_gettime(CLOCK_THREAD_CPUTIME_ID, &t); return (uint64_t) t.tv_sec * 1000000u + (uint64_t) t.tv_nsec / 1000u; }
static int cur_cpu(void) { unsigned c = 0; if (syscall(__NR_getcpu, &c, NULL, NULL) != 0 || c >= 32) return -1; return (int) c; }
#define SPIKE_US 14000
static uint64_t cpuN[32], cpuSum[32], spikeCpuN[32], amax, bmax, spikeN, spikeWall, spikeCpuT;

/* Pencatat waktu: rata-rata dan terlama (mikrodetik) per retro_run, porsi runFrame A/B, serta total waktu per frame tampil (burst),
   ditulis tiap 300 panggilan ke log. */
static uint64_t perf_sum, perf_max, perf_a, perf_b, perf_wall0; static int perf_n, perf_lines;
static void perf_note(uint64_t total, uint64_t ta, uint64_t tb, uint64_t cpu_t, int cpu) {
    if (cpu >= 0) { cpuN[cpu]++; cpuSum[cpu] += total; }
    if (total > SPIKE_US) { spikeN++; spikeWall += total; spikeCpuT += cpu_t; if (cpu >= 0) spikeCpuN[cpu]++; }
    perf_sum += total; perf_a += ta; perf_b += tb; if (total > perf_max) perf_max = total;
    if (++perf_n < 300) return;
    uint64_t now = now_us(); uint64_t wall = perf_wall0 ? now - perf_wall0 : 0; perf_wall0 = now;
    if (perf_lines < 60) {
        char p[1400]; snprintf(p, sizeof p, "%s/mgba_link_debug.txt", saveDir[0] ? saveDir : ".");
        FILE* f = fopen(p, "ab");
        if (f) {
            fprintf(f, "PERF 300 panggilan: rata-rata %u us, terlama %u us, GBA A %u us, GBA B %u us, jeda antar panggilan %u us, netplay=%d"
                       " | frame-tampil %u, terlama %u us, lewat-jatah %u, simpan %u kali %u us, load %u kali %u us, boost prio=%d inti=%d/%d sumber=%c top=%ld hint=%d thread=%d tunggu-B=%u us"
                       " | A-terlama %u us, B-terlama %u us, lonjakan(>%dus) %u kali, rata2 dinding %u us vs waktu-CPU %u us, inti:",
                    (unsigned) (perf_sum / 300), (unsigned) perf_max, (unsigned) (perf_a / 300), (unsigned) (perf_b / 300),
                    (unsigned) (wall / 300), netMode,
                    (unsigned) burstTotal, (unsigned) burstMax, (unsigned) burstOver,
                    (unsigned) ser_n, (unsigned) ser_us, (unsigned) unser_n, (unsigned) unser_us,
                    boostPrio, boostAff, boostNcpu, boostSrc, boostTop, hintSession ? 1 : 0, wStarted, (unsigned) (waitSum / 300),
                    (unsigned) amax, (unsigned) bmax, SPIKE_US, (unsigned) spikeN,
                    (unsigned) (spikeN ? spikeWall / spikeN : 0), (unsigned) (spikeN ? spikeCpuT / spikeN : 0));
            for (int c = 0; c < 32; c++) if (cpuN[c]) fprintf(f, " %d=%ux%uus(lonjakan %u)", c, (unsigned) cpuN[c], (unsigned) (cpuSum[c] / cpuN[c]), (unsigned) spikeCpuN[c]);
            fprintf(f, "\n");
            fclose(f); perf_lines++;
        }
    }
    perf_sum = perf_max = perf_a = perf_b = 0; perf_n = 0;
    burstMax = burstOver = burstTotal = ser_us = unser_us = ser_n = unser_n = 0;
    waitSum = 0; amax = bmax = spikeN = spikeWall = spikeCpuT = 0; memset(cpuN, 0, sizeof cpuN); memset(cpuSum, 0, sizeof cpuSum); memset(spikeCpuN, 0, sizeof spikeCpuN);
}

void retro_run(void) {
    uint64_t t_start = work_begin(), t_a = 0, t_b = 0, c_start = cpu_us();
    bool upd = false;
    if (env_cb(RETRO_ENVIRONMENT_GET_VARIABLE_UPDATE, &upd) && upd) load_var();
    poll_cb();
    /* Layar GBA yang tidak ditampilkan tidak perlu digambar: lewati rendering-nya (hemat CPU besar, state emulasi tidak berubah). */
    for (int i = 0; i < 2; i++) ((struct GBA*) inst[i].core->board)->video.frameskip = (i == view) ? 0 : 59;   /* API-INTERNAL */
    for (int i = 0; i < 2; i++) inst[i].core->setKeys(inst[i].core, keys_for(i));   /* input selalu dibaca di thread utama */
    if (wStarted) {
        pthread_mutex_lock(&wMu); atomic_store(&wDone, 0); wGo = 1; pthread_cond_signal(&wCvGo); pthread_mutex_unlock(&wMu);
        uint64_t t0 = now_us(); inst[0].core->runFrame(inst[0].core); t_a = now_us() - t0;       /* GBA 1 di sini, GBA 2 di thread pekerja */
        uint64_t w0 = now_us();
        while (!atomic_load(&wDone) && now_us() - w0 < 200) { }                                 /* tunggu singkat tanpa tidur */
        if (!atomic_load(&wDone)) { pthread_mutex_lock(&wMu); while (!atomic_load(&wDone)) pthread_cond_wait(&wCvDone, &wMu); pthread_mutex_unlock(&wMu); }
        waitSum += now_us() - w0; t_b = wDt;
    } else {
        for (int i = 0; i < 2; i++) {
            uint64_t t0 = now_us(); inst[i].core->runFrame(inst[i].core); uint64_t dt = now_us() - t0;
            if (i == 0) t_a = dt; else t_b = dt;
        }
    }
    if (t_a > amax) amax = t_a; if (t_b > bmax) bmax = t_b;
    { Node* pn = &inst[0].node;                    /* batas frame: mulai transfer yang diminta parent selama frame ini */
      if (pn->startReq) { pn->startReq = 0; if (!pn->pending) begin_transfer(pn, pn->startMode); } }
    video_cb(inst[view].video, W, H, W * sizeof(color_t));
    struct mCore* c = inst[view].core;
    blip_t* l = c->getAudioChannel(c, 0); blip_t* r = c->getAudioChannel(c, 1);
    int n = blip_samples_avail(l); if (n > SAMPLES) n = SAMPLES;
    blip_read_samples(l, audioBuf, n, 1); blip_read_samples(r, audioBuf + 1, n, 1);
    audio_cb(audioBuf, n);
    for (int i = 0; i < 2; i++) if (i != view) { blip_clear(inst[i].core->getAudioChannel(inst[i].core, 0)); blip_clear(inst[i].core->getAudioChannel(inst[i].core, 1)); }
    perf_note(now_us() - t_start, t_a, t_b, cpu_us() - c_start, cur_cpu());
    work_end();
}

void retro_reset(void) { for (int i = 0; i < 2; i++) { inst[i].core->reset(inst[i].core); inst[i].node.pending = 0; inst[i].node.startReq = 0; } xlog_n = 0; xlog_last[0] = 0; }

/* Mode netplay terdeteksi saat savestate pertama dipakai (netplay memanggil serialize/unserialize setiap frame, main sendiri tidak).
   Hanya di mode ini optimasi idle-loop mGBA dimatikan: statusnya tidak ikut savestate, jadi HP yang baru rollback bisa beda dari HP
   lain. Main sendiri tetap memakai optimasi itu supaya lebih ringan. API-INTERNAL: kalau build gagal di baris ini, hapus baris ini. */
static void enter_net_mode(void) {
    if (netMode) return;
    netMode = 1;
    for (int i = 0; i < 2; i++) if (inst[i].core) ((struct GBA*) inst[i].core->board)->idleOptimization = -1;
    dbg("mode netplay: optimasi idle-loop dimatikan", 1);
}

/* Serialisasi: [A][B][sisa siklus event link A,B]. Event timing custom tidak ikut savestate mGBA, jadi dijadwalkan ulang setelah load
   (penting untuk rollback netplay: tanpa ini HP yang rollback kehilangan event dan kedua HP DESYNC). */
size_t retro_serialize_size(void) { return inst[0].core->stateSize(inst[0].core) * 2 + 8; }
static bool serialize_impl(void* data, size_t size) {
    enter_net_mode();
    size_t s = inst[0].core->stateSize(inst[0].core); uint8_t* p = data;
    if (size < s * 2 + 8) return false;
    inst[0].core->saveState(inst[0].core, p); inst[1].core->saveState(inst[1].core, p + s);
    int32_t rem[2];
    for (int i = 0; i < 2; i++) rem[i] = inst[i].node.pending ? mTimingUntil(&gbaOf(&inst[i].node)->timing, &inst[i].node.done) : -1;
    memcpy(p + 2 * s, rem, 8);
    return true;
}
static bool unserialize_impl(const void* data, size_t size) {
    enter_net_mode();
    size_t s = inst[0].core->stateSize(inst[0].core); const uint8_t* p = data;
    if (size < s * 2 + 8) return false;
    int32_t rem[2]; memcpy(rem, p + 2 * s, 8);
    for (int i = 0; i < 2; i++) {                  /* buang status sisa sebelum load, supaya hasil tidak bergantung keadaan lama */
        Node* n = &inst[i].node;
        mTimingDeschedule(&gbaOf(n)->timing, &n->done);
        n->pending = 0; n->startReq = 0;
    }
    { static int un; if (un < 5) { un++; dbg("rollback: loadState ke-", un); } }
    loading++;
    bool ok0 = inst[0].core->loadState(inst[0].core, p);
    bool ok1 = inst[1].core->loadState(inst[1].core, p + s);
    loading--;
    for (int i = 0; i < 2; i++) {
        Node* n = &inst[i].node;
        mTimingDeschedule(&gbaOf(n)->timing, &n->done);
        n->pending = 0;
        if (rem[i] >= 0) schedule(n, rem[i] > 0 ? rem[i] : 1);
    }
    return ok0 && ok1;
}

/* Pembungkus: hanya menambah pengukuran waktu dan pencatatan burst; isi serialisasi tidak berubah. */
bool retro_serialize(void* data, size_t size) {
    uint64_t t0 = work_begin(); bool ok = serialize_impl(data, size);
    ser_us += now_us() - t0; ser_n++; work_end(); return ok;
}
bool retro_unserialize(const void* data, size_t size) {
    uint64_t t0 = work_begin(); bool ok = unserialize_impl(data, size);
    unser_us += now_us() - t0; unser_n++; work_end(); return ok;
}

/* Save RAM yang dilihat aplikasi = GBA 1 (A). Save GBA 2 ditulis ke <rom>.link2.sav saat game ditutup. */
void* retro_get_memory_data(unsigned id) { return id == RETRO_MEMORY_SAVE_RAM ? inst[0].save : NULL; }
size_t retro_get_memory_size(unsigned id) { return id == RETRO_MEMORY_SAVE_RAM ? 0x20000 : 0; }

void retro_cheat_reset(void) {}
void retro_cheat_set(unsigned i, bool e, const char* c) { (void) i; (void) e; (void) c; }
unsigned retro_get_region(void) { return RETRO_REGION_NTSC; }
