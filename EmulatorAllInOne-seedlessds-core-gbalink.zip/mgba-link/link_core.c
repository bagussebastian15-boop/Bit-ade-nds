/*
 * mgba_link: core libretro GBA dengan LINK CABLE untuk 2 pemain.
 *
 * Isi: DUA GBA virtual (instance mGBA A dan B) dalam satu core, dihubungkan oleh driver SIO buatan sendiri
 * (satu thread, deterministik). Tiap frame: A dan B masing-masing menjalankan satu frame, tombol port 0 -> A,
 * port 1 -> B. Layar/suara yang keluar hanya milik pemain lokal (opsi "mgba_link_view": 0 = A, 1 = B).
 * Netplay rollback bawaan aplikasi dipakai apa adanya: kedua HP menjalankan A dan B yang identik dari input yang
 * sama, jadi state yang diserialisasi = A + B + state driver link.
 *
 * Dibuat terhadap mGBA 0.10.x (lihat scripts/build_mgba_link_core.sh). Bagian yang memakai API internal mGBA
 * ditandai "API-INTERNAL": kalau build gagal, kemungkinan besar di situ.
 */
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "libretro.h"

#include <mgba/core/core.h>
#include <mgba/core/timing.h>
#include <mgba/core/blip_buf.h>
#include <mgba/gba/core.h>
#include <mgba/internal/gba/gba.h>
#include <mgba/internal/gba/io.h>
#include <mgba/internal/gba/sio.h>
#include <mgba-util/vfs.h>

#define W 240
#define H 160
#define SAMPLES 1024
#define SAVE_MAX 0x20010

/* offset register I/O GBA */
#define R_SIOMULTI0 0x120
#define R_SIOCNT    0x128
#define R_SIOSEND   0x12A   /* SIOMLT_SEND = SIODATA8 */
#define R_RCNT      0x134

static retro_environment_t env_cb;
static retro_video_refresh_t video_cb;
static retro_audio_sample_batch_t audio_cb;
static retro_input_poll_t poll_cb;
static retro_input_state_t input_cb;

typedef struct Node {
    struct GBASIODriver d;          /* harus pertama: dipakai sebagai driver */
    struct mTimingEvent done;       /* transfer selesai */
    int id;                         /* 0 = parent (A), 1 = child (B) */
    struct Node* peer;
    struct mCore* core;
    int pending;                    /* transfer sedang berjalan (diserialisasi) */
} Node;

typedef struct {
    struct mCore* core;
    Node node;
    color_t video[W * H];
    uint8_t save[SAVE_MAX];
    void* rom;                      /* salinan ROM milik instance ini (tidak dibagi) */
    int hasRom;
} Inst;

static Inst inst[2];
static int view = 0;
static void* romData; static size_t romSize;
static int loading;                 /* >0 saat loadState: mGBA memutar ulang penulisan register, jangan memicu transfer */
static int16_t audioBuf[SAMPLES * 2];
static char saveDir[1024], romName[256];


/* Log langkah ke <save_dir>/mgba_link_debug.txt supaya crash native bisa dilacak sampai langkah terakhir. */
static void dbg(const char* msg, int a) {
    char p[1400]; snprintf(p, sizeof p, "%s/mgba_link_debug.txt", saveDir[0] ? saveDir : ".");
    FILE* f = fopen(p, "ab"); if (!f) return;
    fprintf(f, "%s %d\n", msg, a); fclose(f);
}

static int siolog_n;
static int last[2][3][3], rep[2][3], seen[2][3];
/* Catatan SIO tanpa pengulangan: baris yang sama persis dengan sebelumnya (per GBA & jenis) tidak ditulis lagi, hanya dihitung. */
static void siolog(const char* what, int id, int a, int b, int c) {
    if (loading || id < 0 || id > 1) return;
    int k = (what[0] == 'w') ? 0 : (what[0] == 's') ? 1 : 2;
    if (seen[id][k] && last[id][k][0] == a && last[id][k][1] == b && last[id][k][2] == c) { rep[id][k]++; return; }
    if (siolog_n >= 400) return;
    char p[1400]; snprintf(p, sizeof p, "%s/mgba_link_debug.txt", saveDir[0] ? saveDir : ".");
    FILE* f = fopen(p, "ab"); if (!f) return;
    if (rep[id][k] > 0) fprintf(f, "   ^ (%d kali lagi, gba=%d)\n", rep[id][k], id);
    fprintf(f, "SIO %s gba=%d a=0x%X b=0x%X c=%d\n", what, id, a, b, c); fclose(f);
    siolog_n++; last[id][k][0] = a; last[id][k][1] = b; last[id][k][2] = c; rep[id][k] = 0; seen[id][k] = 1;
}

static struct GBA* gbaOf(Node* n) { return (struct GBA*) n->core->board; }              /* API-INTERNAL */
static uint16_t* io(Node* n) { return gbaOf(n)->memory.io; }                            /* API-INTERNAL */

/* ---- driver SIO: Multi-Player (mode 2) dan Normal (8/32-bit), pertukaran data langsung antar dua instance ---- */

static void finish(struct mTiming* t, void* ctx, uint32_t late) {
    Node* n = ctx; (void) t;
    struct GBASIO* sio = &gbaOf(n)->sio;            /* API-INTERNAL: game membaca SIOCNT dari sio->siocnt, bukan dari memory.io */
    siolog("finish", n->id, sio->siocnt, 0, 0);
    sio->siocnt &= ~0x0080;                         /* bit start/busy = 0 */
    n->pending = 0;
    if (sio->siocnt & 0x4000) GBARaiseIRQ(gbaOf(n), GBA_IRQ_SIO, late);   /* API-INTERNAL */
}

static void schedule(Node* n, int32_t cycles) {
    mTimingDeschedule(&gbaOf(n)->timing, &n->done);
    mTimingSchedule(&gbaOf(n)->timing, &n->done, cycles);
    n->pending = 1;
}

/* Mulai transfer dari parent (id 0). Child ikut sibuk sampai transfer selesai. */
static void begin_transfer(Node* n, int mode) {
    Node* c = n->peer;
    uint16_t* a = io(n);
    uint16_t* b = io(c);
    struct GBASIO* sc = &gbaOf(c)->sio;
    int peerOk = ((int) sc->mode == mode);          /* child belum di mode yang sama = dianggap tidak terhubung */
    siolog("start", n->id, mode, (int) sc->mode, peerOk);
    if (mode == 2) {                                /* Multi-Player */
        uint16_t sa = a[R_SIOSEND >> 1], sb = peerOk ? b[R_SIOSEND >> 1] : 0xFFFF;
        a[R_SIOMULTI0 >> 1] = sa;               a[(R_SIOMULTI0 >> 1) + 1] = sb;
        a[(R_SIOMULTI0 >> 1) + 2] = 0xFFFF;     a[(R_SIOMULTI0 >> 1) + 3] = 0xFFFF;
        if (peerOk) {
            b[R_SIOMULTI0 >> 1] = sa;           b[(R_SIOMULTI0 >> 1) + 1] = sb;
            b[(R_SIOMULTI0 >> 1) + 2] = 0xFFFF; b[(R_SIOMULTI0 >> 1) + 3] = 0xFFFF;
            sc->siocnt = (sc->siocnt & ~0x0030) | (1 << 4) | 0x0080;     /* ID child = 1, busy */
            schedule(c, 1600);
        }
        schedule(n, 1600);
    } else {                                        /* Normal 8/32-bit: tukar register data */
        int w32 = (mode == 1);
        if (peerOk) {
            uint16_t t0 = a[R_SIOMULTI0 >> 1], t1 = a[(R_SIOMULTI0 >> 1) + 1];
            uint16_t u0 = b[R_SIOMULTI0 >> 1], u1 = b[(R_SIOMULTI0 >> 1) + 1];
            if (w32) { a[R_SIOMULTI0 >> 1] = u0; a[(R_SIOMULTI0 >> 1) + 1] = u1; b[R_SIOMULTI0 >> 1] = t0; b[(R_SIOMULTI0 >> 1) + 1] = t1; }
            else     { uint16_t x = a[R_SIOSEND >> 1], y = b[R_SIOSEND >> 1]; a[R_SIOSEND >> 1] = y; b[R_SIOSEND >> 1] = x; }
            sc->siocnt |= 0x0080;
            schedule(c, w32 ? 4096 : 1024);
        }
        schedule(n, w32 ? 4096 : 1024);
    }
}

static uint16_t drv_write(struct GBASIODriver* d, uint32_t address, uint16_t value) {
    Node* n = (Node*) d;
    if (address != R_SIOCNT) return value;
    struct GBASIO* sio = d->p;
    int mode = (int) sio->mode;                     /* sudah di-update mGBA sebelum driver dipanggil */
    int start = (value & 0x0080) != 0;
    siolog("write", n->id, value, mode, n->pending);
    if (mode == 2) {
        /* Bit hanya-baca pada mode Multi-Player: SI (bit2), SD (bit3), ID (bit4-5). Tanpa SD=1 game menganggap kabel tidak terpasang.
           Dibentuk SELALU, termasuk saat loadState (mGBA menulis ulang SIOCNT), supaya bit-bit ini tidak hilang setelah rollback. */
        uint16_t id = loading ? (value & 0x0030) : (sio->siocnt & 0x0030);
        value &= ~0x003C;
        value |= 0x0008;                            /* SD = 1: semua GBA siap */
        if (n->id) value |= 0x0004;                 /* SI = 1 pada child */
        value |= id;                                /* ID dipertahankan (diisi setelah transfer pertama) */
    }
    if (loading) return value;                      /* saat loadState: jangan picu transfer / ubah status sibuk */
    if (n->id != 0) {                               /* child tidak bisa memulai transfer sendiri */
        value = (value & ~0x0080) | (n->pending ? 0x0080 : 0);
    } else if (n->pending) {
        value |= 0x0080;                            /* masih sibuk */
    } else if (start && (mode == 0 || mode == 1 || mode == 2)) {
        begin_transfer(n, mode);
    }
    return value;
}

static bool drv_init(struct GBASIODriver* d) { Node* n = (Node*) d; n->done.context = n; n->done.name = "link"; n->done.callback = finish; n->done.priority = 0x80; return true; }
static void drv_deinit(struct GBASIODriver* d) { (void) d; }
static bool drv_load(struct GBASIODriver* d) { (void) d; return true; }
static bool drv_unload(struct GBASIODriver* d) { (void) d; return true; }

static void attach(int i) {
    Node* n = &inst[i].node;
    memset(&n->d, 0, sizeof(n->d));
    n->core = inst[i].core; n->id = i; n->peer = &inst[1 - i].node;
    n->d.init = drv_init; n->d.deinit = drv_deinit;   /* 0.10.3: tidak ada member 'reset' */
    n->d.load = drv_load; n->d.unload = drv_unload; n->d.writeRegister = drv_write;
    GBASIOSetDriver(&gbaOf(n)->sio, &n->d, 2);   /* mode 2 = Multi-Player (API-INTERNAL, 0.10: butuh mode) */
    GBASIOSetDriver(&gbaOf(n)->sio, &n->d, 0);   /* mode 0 = Normal (slot yang sama dipakai Normal 8 & 32-bit) */
}

/* ---- libretro ---- */

static void load_var(void) {
    struct retro_variable v = { "mgba_link_view", NULL };
    if (env_cb(RETRO_ENVIRONMENT_GET_VARIABLE, &v) && v.value) view = (v.value[0] == '1');
}

void retro_set_environment(retro_environment_t cb) {
    env_cb = cb;
    static const struct retro_variable vars[] = {
        { "mgba_link_view", "Layar yang tampil; 0|1" }, { "mgba_frameskip", "Frameskip; 0" }, { NULL, NULL } };
    cb(RETRO_ENVIRONMENT_SET_VARIABLES, (void*) vars);
}
void retro_set_video_refresh(retro_video_refresh_t cb) { video_cb = cb; }
void retro_set_audio_sample(retro_audio_sample_t cb) { (void) cb; }
void retro_set_audio_sample_batch(retro_audio_sample_batch_t cb) { audio_cb = cb; }
void retro_set_input_poll(retro_input_poll_t cb) { poll_cb = cb; }
void retro_set_input_state(retro_input_state_t cb) { input_cb = cb; }
unsigned retro_api_version(void) { return RETRO_API_VERSION; }
void retro_init(void) {}
void retro_deinit(void) {}
void retro_set_controller_port_device(unsigned p, unsigned d) { (void) p; (void) d; }

void retro_get_system_info(struct retro_system_info* i) {
    memset(i, 0, sizeof(*i));
    i->library_name = "mGBA Link"; i->library_version = "0.10-link"; i->valid_extensions = "gba"; i->need_fullpath = false;
}
void retro_get_system_av_info(struct retro_system_av_info* i) {
    memset(i, 0, sizeof(*i));
    i->geometry.base_width = i->geometry.max_width = W; i->geometry.base_height = i->geometry.max_height = H;
    i->geometry.aspect_ratio = 3.0f / 2.0f; i->timing.fps = 59.7275; i->timing.sample_rate = 32768;
}

static void open_inst(int i) {
    dbg("open_inst: mulai", i);
    struct mCore* c = GBACoreCreate();
    if (!c) { dbg("GBACoreCreate NULL", i); return; }
    c->init(c);
    dbg("init ok", i);
    mCoreInitConfig(c, NULL);                      /* seperti port libretro resmi: config harus diinisialisasi */
    dbg("config ok", i);
    c->setVideoBuffer(c, inst[i].video, W);
    c->setAudioBufferSize(c, SAMPLES);
    blip_t* bl = c->getAudioChannel(c, 0); blip_t* br = c->getAudioChannel(c, 1);
    if (bl && br) {
        blip_set_rates(bl, c->frequency(c), 32768);                                     /* API-INTERNAL (0.10) */
        blip_set_rates(br, c->frequency(c), 32768);
    } else dbg("audio channel NULL", i);
    dbg("audio ok", i);
    inst[i].rom = malloc(romSize);
    if (!inst[i].rom) { dbg("malloc rom gagal", i); return; }
    memcpy(inst[i].rom, romData, romSize);
    if (!c->loadROM(c, VFileFromMemory(inst[i].rom, romSize))) dbg("loadROM GAGAL", i);
    dbg("loadROM ok", i);
    memset(inst[i].save, 0xFF, SAVE_MAX);
    if (i == 1) {                                  /* GBA 2 punya file save sendiri: <rom>.link2.sav */
        char p[1400]; snprintf(p, sizeof p, "%s/%s.link2.sav", saveDir, romName);
        FILE* f = fopen(p, "rb"); if (f) { size_t rd = fread(inst[i].save, 1, SAVE_MAX, f); (void) rd; fclose(f); }
    }
    c->loadSave(c, VFileFromMemory(inst[i].save, SAVE_MAX));
    dbg("loadSave ok", i);
    inst[i].core = c;
}

bool retro_load_game(const struct retro_game_info* g) {
    enum retro_pixel_format fmt = RETRO_PIXEL_FORMAT_XRGB8888;
    if (!g || !g->data || !env_cb(RETRO_ENVIRONMENT_SET_PIXEL_FORMAT, &fmt)) return false;
    romData = malloc(g->size); memcpy(romData, g->data, g->size); romSize = g->size;
    const char* sd = NULL; env_cb(RETRO_ENVIRONMENT_GET_SAVE_DIRECTORY, &sd);
    snprintf(saveDir, sizeof saveDir, "%s", sd ? sd : ".");
    const char* b = g->path ? strrchr(g->path, '/') : NULL; b = b ? b + 1 : (g->path ? g->path : "game");
    snprintf(romName, sizeof romName, "%s", b); char* dot = strrchr(romName, '.'); if (dot) *dot = 0;
    { char lp[1400]; snprintf(lp, sizeof lp, "%s/mgba_link_debug.txt", saveDir); FILE* lf = fopen(lp, "wb"); if (lf) fclose(lf); }   /* kosongkan log lama */
    siolog_n = 0; memset(last, 0, sizeof last); memset(rep, 0, sizeof rep); memset(seen, 0, sizeof seen);
    dbg("VERSI CORE LOG: v4-dedupe (kalau baris ini tidak ada, APK masih build lama)", 4);
    dbg("retro_load_game: mulai, rom bytes", (int) romSize);
    for (int i = 0; i < 2; i++) open_inst(i);
    if (!inst[0].core || !inst[1].core) { dbg("open_inst gagal", 0); return false; }
    for (int i = 0; i < 2; i++) { attach(i); dbg("attach ok", i); }
    for (int i = 0; i < 2; i++) { inst[i].core->reset(inst[i].core); dbg("reset ok", i); }
    load_var();
    dbg("retro_load_game: selesai", 0);
    return true;
}
bool retro_load_game_special(unsigned t, const struct retro_game_info* g, size_t n) { (void) t; (void) g; (void) n; return false; }

void retro_unload_game(void) {
    if (inst[1].core) {                            /* simpan save GBA 2 */
        char p[1400]; snprintf(p, sizeof p, "%s/%s.link2.sav", saveDir, romName);
        FILE* f = fopen(p, "wb"); if (f) { fwrite(inst[1].save, 1, 0x20000, f); fclose(f); }
    }
    for (int i = 0; i < 2; i++) if (inst[i].core) { mCoreConfigDeinit(&inst[i].core->config); inst[i].core->deinit(inst[i].core); inst[i].core = NULL; }
    for (int i = 0; i < 2; i++) { free(inst[i].rom); inst[i].rom = NULL; }
    free(romData); romData = NULL;
}

static uint32_t keys_for(unsigned port) {
    static const unsigned map[10] = { RETRO_DEVICE_ID_JOYPAD_A, RETRO_DEVICE_ID_JOYPAD_B, RETRO_DEVICE_ID_JOYPAD_SELECT,
        RETRO_DEVICE_ID_JOYPAD_START, RETRO_DEVICE_ID_JOYPAD_RIGHT, RETRO_DEVICE_ID_JOYPAD_LEFT, RETRO_DEVICE_ID_JOYPAD_UP,
        RETRO_DEVICE_ID_JOYPAD_DOWN, RETRO_DEVICE_ID_JOYPAD_R, RETRO_DEVICE_ID_JOYPAD_L };
    uint32_t k = 0;
    for (int b = 0; b < 10; b++) if (input_cb(port, RETRO_DEVICE_JOYPAD, 0, map[b])) k |= 1u << b;   /* urutan bit GBA */
    return k;
}

void retro_run(void) {
    bool upd = false;
    if (env_cb(RETRO_ENVIRONMENT_GET_VARIABLE_UPDATE, &upd) && upd) load_var();
    poll_cb();
    for (int i = 0; i < 2; i++) { inst[i].core->setKeys(inst[i].core, keys_for(i)); inst[i].core->runFrame(inst[i].core); }
    video_cb(inst[view].video, W, H, W * sizeof(color_t));
    struct mCore* c = inst[view].core;
    blip_t* l = c->getAudioChannel(c, 0); blip_t* r = c->getAudioChannel(c, 1);
    int n = blip_samples_avail(l); if (n > SAMPLES) n = SAMPLES;
    blip_read_samples(l, audioBuf, n, 1); blip_read_samples(r, audioBuf + 1, n, 1);
    audio_cb(audioBuf, n);
    for (int i = 0; i < 2; i++) if (i != view) { blip_clear(inst[i].core->getAudioChannel(inst[i].core, 0)); blip_clear(inst[i].core->getAudioChannel(inst[i].core, 1)); }
}

void retro_reset(void) { for (int i = 0; i < 2; i++) { inst[i].core->reset(inst[i].core); inst[i].node.pending = 0; } }

/* Serialisasi: [A][B][sisa siklus event link A,B]. Event timing custom tidak ikut savestate mGBA, jadi dijadwalkan ulang setelah load
   (penting untuk rollback netplay: tanpa ini HP yang rollback kehilangan event dan kedua HP DESYNC). */
size_t retro_serialize_size(void) { return inst[0].core->stateSize(inst[0].core) * 2 + 8; }
bool retro_serialize(void* data, size_t size) {
    size_t s = inst[0].core->stateSize(inst[0].core); uint8_t* p = data;
    if (size < s * 2 + 8) return false;
    inst[0].core->saveState(inst[0].core, p); inst[1].core->saveState(inst[1].core, p + s);
    int32_t rem[2];
    for (int i = 0; i < 2; i++) rem[i] = inst[i].node.pending ? mTimingUntil(&gbaOf(&inst[i].node)->timing, &inst[i].node.done) : -1;
    memcpy(p + 2 * s, rem, 8);
    return true;
}
bool retro_unserialize(const void* data, size_t size) {
    size_t s = inst[0].core->stateSize(inst[0].core); const uint8_t* p = data;
    if (size < s * 2 + 8) return false;
    int32_t rem[2]; memcpy(rem, p + 2 * s, 8);
    for (int i = 0; i < 2; i++) {                  /* buang status sisa sebelum load, supaya hasil tidak bergantung keadaan lama */
        Node* n = &inst[i].node;
        mTimingDeschedule(&gbaOf(n)->timing, &n->done);
        n->pending = 0;
    }
    { static int un; if (un < 5) { un++; dbg("rollback: loadState ke-", un); } }
    loading++;
    bool ok0 = inst[0].core->loadState(inst[0].core, p);
    bool ok1 = inst[1].core->loadState(inst[1].core, p + s);
    loading--;
    for (int i = 0; i < 2; i++) {
        Node* n = &inst[i].node;
        mTimingDeschedule(&gbaOf(n)->timing, &n->done);
        n->pending = 0;
        if (rem[i] >= 0) schedule(n, rem[i] > 0 ? rem[i] : 1);
    }
    return ok0 && ok1;
}

/* Save RAM yang dilihat aplikasi = GBA 1 (A). Save GBA 2 ditulis ke <rom>.link2.sav saat game ditutup. */
void* retro_get_memory_data(unsigned id) { return id == RETRO_MEMORY_SAVE_RAM ? inst[0].save : NULL; }
size_t retro_get_memory_size(unsigned id) { return id == RETRO_MEMORY_SAVE_RAM ? 0x20000 : 0; }

void retro_cheat_reset(void) {}
void retro_cheat_set(unsigned i, bool e, const char* c) { (void) i; (void) e; (void) c; }
unsigned retro_get_region(void) { return RETRO_REGION_NTSC; }
