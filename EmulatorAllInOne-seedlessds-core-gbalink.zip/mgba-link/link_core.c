/*
 * mgba_link: core libretro GBA dengan LINK CABLE untuk 2 pemain.
 *
 * Isi: DUA GBA virtual (instance mGBA A dan B) dalam satu core, dihubungkan oleh driver SIO buatan sendiri
 * (satu thread, deterministik). Tiap frame: A dan B masing-masing menjalankan satu frame, tombol port 0 -> A,
 * port 1 -> B. Layar/suara yang keluar hanya milik pemain lokal (opsi "mgba_link_view": 0 = A, 1 = B).
 * Netplay rollback bawaan aplikasi dipakai apa adanya: kedua HP menjalankan A dan B yang identik dari input yang
 * sama, jadi state yang diserialisasi = A + B + state driver link.
 *
 * Dibuat terhadap mGBA 0.10.x (lihat scripts/build_mgba_link_core.sh). Bagian yang memakai API internal mGBA
 * ditandai "API-INTERNAL": kalau build gagal, kemungkinan besar di situ.
 */
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "libretro.h"

#include <mgba/core/core.h>
#include <mgba/core/timing.h>
#include <mgba/core/blip_buf.h>
#include <mgba/gba/core.h>
#include <mgba/internal/gba/gba.h>
#include <mgba/internal/gba/io.h>
#include <mgba/internal/gba/sio.h>
#include <mgba-util/vfs.h>

#define W 240
#define H 160
#define SAMPLES 1024
#define SAVE_MAX 0x20010

/* offset register I/O GBA */
#define R_SIOMULTI0 0x120
#define R_SIOCNT    0x128
#define R_SIOSEND   0x12A   /* SIOMLT_SEND = SIODATA8 */
#define R_RCNT      0x134

static retro_environment_t env_cb;
static retro_video_refresh_t video_cb;
static retro_audio_sample_batch_t audio_cb;
static retro_input_poll_t poll_cb;
static retro_input_state_t input_cb;

typedef struct Node {
    struct GBASIODriver d;          /* harus pertama: dipakai sebagai driver */
    struct mTimingEvent done;       /* transfer selesai */
    int id;                         /* 0 = parent (A), 1 = child (B) */
    struct Node* peer;
    struct mCore* core;
    int pending;                    /* transfer sedang berjalan (diserialisasi) */
} Node;

typedef struct {
    struct mCore* core;
    Node node;
    color_t video[W * H];
    uint8_t save[SAVE_MAX];
    int hasRom;
} Inst;

static Inst inst[2];
static int view = 0;
static void* romData; static size_t romSize;
static int16_t audioBuf[SAMPLES * 2];
static char saveDir[1024], romName[256];

static struct GBA* gbaOf(Node* n) { return (struct GBA*) n->core->board; }              /* API-INTERNAL */
static uint16_t* io(Node* n) { return gbaOf(n)->memory.io; }                            /* API-INTERNAL */

/* ---- driver SIO: Multi-Player (mode 2) dan Normal (8/32-bit), pertukaran data langsung antar dua instance ---- */

static void finish(struct mTiming* t, void* ctx, uint32_t late) {
    Node* n = ctx; (void) t;
    uint16_t* r = io(n);
    r[R_SIOCNT >> 1] &= ~0x0080;                    /* bit start/busy = 0 */
    n->pending = 0;
    if (r[R_SIOCNT >> 1] & 0x4000) GBARaiseIRQ(gbaOf(n), GBA_IRQ_SIO, late);   /* API-INTERNAL */
}

static void schedule(Node* n, int32_t cycles) {
    mTimingDeschedule(&gbaOf(n)->timing, &n->done);
    mTimingSchedule(&gbaOf(n)->timing, &n->done, cycles);
    n->pending = 1;
}

static uint16_t drv_write(struct GBASIODriver* d, uint32_t address, uint16_t value) {
    Node* n = (Node*) d;
    if (address != R_SIOCNT) return value;
    int mode = (value >> 12) & 3;
    int start = value & 0x0080;
    if (start && n->id == 0 && !n->pending) {       /* hanya parent memulai transfer */
        uint16_t* a = io(n);
        uint16_t* b = io(n->peer);
        if (mode == 2) {                            /* Multi-Player */
            uint16_t sa = a[R_SIOSEND >> 1], sb = b[R_SIOSEND >> 1];
            a[R_SIOMULTI0 >> 1] = b[R_SIOMULTI0 >> 1] = sa;
            a[(R_SIOMULTI0 >> 1) + 1] = b[(R_SIOMULTI0 >> 1) + 1] = sb;
            a[(R_SIOMULTI0 >> 1) + 2] = b[(R_SIOMULTI0 >> 1) + 2] = 0xFFFF;
            a[(R_SIOMULTI0 >> 1) + 3] = b[(R_SIOMULTI0 >> 1) + 3] = 0xFFFF;
            b[R_SIOCNT >> 1] = (b[R_SIOCNT >> 1] & ~0x0030) | (1 << 4);       /* id child = 1 */
            schedule(n, 1600);
            schedule(n->peer, 1600);
        } else {                                    /* Normal 8/32-bit: tukar register data */
            int w32 = mode == 1;
            uint16_t t0 = a[R_SIOMULTI0 >> 1], t1 = a[(R_SIOMULTI0 >> 1) + 1];
            uint16_t u0 = b[R_SIOMULTI0 >> 1], u1 = b[(R_SIOMULTI0 >> 1) + 1];
            if (w32) { a[R_SIOMULTI0 >> 1] = u0; a[(R_SIOMULTI0 >> 1) + 1] = u1; b[R_SIOMULTI0 >> 1] = t0; b[(R_SIOMULTI0 >> 1) + 1] = t1; }
            else     { uint16_t x = a[R_SIOSEND >> 1], y = b[R_SIOSEND >> 1]; a[R_SIOSEND >> 1] = y; b[R_SIOSEND >> 1] = x; }
            schedule(n, w32 ? 4096 : 1024);
            schedule(n->peer, w32 ? 4096 : 1024);
        }
    }
    return value;
}

static bool drv_init(struct GBASIODriver* d) { Node* n = (Node*) d; n->done.context = n; n->done.name = "link"; n->done.callback = finish; n->done.priority = 0x80; return true; }
static void drv_deinit(struct GBASIODriver* d) { (void) d; }
static bool drv_load(struct GBASIODriver* d) { (void) d; return true; }
static bool drv_unload(struct GBASIODriver* d) { (void) d; return true; }

static void attach(int i) {
    Node* n = &inst[i].node;
    memset(&n->d, 0, sizeof(n->d));
    n->core = inst[i].core; n->id = i; n->peer = &inst[1 - i].node;
    n->d.init = drv_init; n->d.deinit = drv_deinit;   /* 0.10.3: tidak ada member 'reset' */
    n->d.load = drv_load; n->d.unload = drv_unload; n->d.writeRegister = drv_write;
    GBASIOSetDriver(&gbaOf(n)->sio, &n->d, 2);   /* mode 2 = Multi-Player (API-INTERNAL, 0.10: butuh mode) */
    GBASIOSetDriver(&gbaOf(n)->sio, &n->d, 0);   /* mode 0 = Normal (slot yang sama dipakai Normal 8 & 32-bit) */
}

/* ---- libretro ---- */

static void load_var(void) {
    struct retro_variable v = { "mgba_link_view", NULL };
    if (env_cb(RETRO_ENVIRONMENT_GET_VARIABLE, &v) && v.value) view = (v.value[0] == '1');
}

void retro_set_environment(retro_environment_t cb) {
    env_cb = cb;
    static const struct retro_variable vars[] = {
        { "mgba_link_view", "Layar yang tampil; 0|1" }, { "mgba_frameskip", "Frameskip; 0" }, { NULL, NULL } };
    cb(RETRO_ENVIRONMENT_SET_VARIABLES, (void*) vars);
}
void retro_set_video_refresh(retro_video_refresh_t cb) { video_cb = cb; }
void retro_set_audio_sample(retro_audio_sample_t cb) { (void) cb; }
void retro_set_audio_sample_batch(retro_audio_sample_batch_t cb) { audio_cb = cb; }
void retro_set_input_poll(retro_input_poll_t cb) { poll_cb = cb; }
void retro_set_input_state(retro_input_state_t cb) { input_cb = cb; }
unsigned retro_api_version(void) { return RETRO_API_VERSION; }
void retro_init(void) {}
void retro_deinit(void) {}
void retro_set_controller_port_device(unsigned p, unsigned d) { (void) p; (void) d; }

void retro_get_system_info(struct retro_system_info* i) {
    memset(i, 0, sizeof(*i));
    i->library_name = "mGBA Link"; i->library_version = "0.10-link"; i->valid_extensions = "gba"; i->need_fullpath = false;
}
void retro_get_system_av_info(struct retro_system_av_info* i) {
    memset(i, 0, sizeof(*i));
    i->geometry.base_width = i->geometry.max_width = W; i->geometry.base_height = i->geometry.max_height = H;
    i->geometry.aspect_ratio = 3.0f / 2.0f; i->timing.fps = 59.7275; i->timing.sample_rate = 32768;
}

static void open_inst(int i) {
    struct mCore* c = GBACoreCreate();
    c->init(c);
    c->setVideoBuffer(c, inst[i].video, W);
    c->setAudioBufferSize(c, SAMPLES);
    blip_set_rates(c->getAudioChannel(c, 0), c->frequency(c), 32768);                   /* API-INTERNAL (0.10) */
    blip_set_rates(c->getAudioChannel(c, 1), c->frequency(c), 32768);
    c->loadROM(c, VFileFromMemory(romData, romSize));
    memset(inst[i].save, 0xFF, SAVE_MAX);
    if (i == 1) {                                  /* GBA 2 punya file save sendiri: <rom>.link2.sav */
        char p[1400]; snprintf(p, sizeof p, "%s/%s.link2.sav", saveDir, romName);
        FILE* f = fopen(p, "rb"); if (f) { fread(inst[i].save, 1, SAVE_MAX, f); fclose(f); }
    }
    c->loadSave(c, VFileFromMemory(inst[i].save, SAVE_MAX));
    inst[i].core = c;
}

bool retro_load_game(const struct retro_game_info* g) {
    enum retro_pixel_format fmt = RETRO_PIXEL_FORMAT_XRGB8888;
    if (!g || !g->data || !env_cb(RETRO_ENVIRONMENT_SET_PIXEL_FORMAT, &fmt)) return false;
    romData = malloc(g->size); memcpy(romData, g->data, g->size); romSize = g->size;
    const char* sd = NULL; env_cb(RETRO_ENVIRONMENT_GET_SAVE_DIRECTORY, &sd);
    snprintf(saveDir, sizeof saveDir, "%s", sd ? sd : ".");
    const char* b = g->path ? strrchr(g->path, '/') : NULL; b = b ? b + 1 : (g->path ? g->path : "game");
    snprintf(romName, sizeof romName, "%s", b); char* dot = strrchr(romName, '.'); if (dot) *dot = 0;
    for (int i = 0; i < 2; i++) open_inst(i);
    for (int i = 0; i < 2; i++) attach(i);
    for (int i = 0; i < 2; i++) inst[i].core->reset(inst[i].core);
    load_var();
    return true;
}
bool retro_load_game_special(unsigned t, const struct retro_game_info* g, size_t n) { (void) t; (void) g; (void) n; return false; }

void retro_unload_game(void) {
    if (inst[1].core) {                            /* simpan save GBA 2 */
        char p[1400]; snprintf(p, sizeof p, "%s/%s.link2.sav", saveDir, romName);
        FILE* f = fopen(p, "wb"); if (f) { fwrite(inst[1].save, 1, 0x20000, f); fclose(f); }
    }
    for (int i = 0; i < 2; i++) if (inst[i].core) { inst[i].core->deinit(inst[i].core); inst[i].core = NULL; }
    free(romData); romData = NULL;
}

static uint32_t keys_for(unsigned port) {
    static const unsigned map[10] = { RETRO_DEVICE_ID_JOYPAD_A, RETRO_DEVICE_ID_JOYPAD_B, RETRO_DEVICE_ID_JOYPAD_SELECT,
        RETRO_DEVICE_ID_JOYPAD_START, RETRO_DEVICE_ID_JOYPAD_RIGHT, RETRO_DEVICE_ID_JOYPAD_LEFT, RETRO_DEVICE_ID_JOYPAD_UP,
        RETRO_DEVICE_ID_JOYPAD_DOWN, RETRO_DEVICE_ID_JOYPAD_R, RETRO_DEVICE_ID_JOYPAD_L };
    uint32_t k = 0;
    for (int b = 0; b < 10; b++) if (input_cb(port, RETRO_DEVICE_JOYPAD, 0, map[b])) k |= 1u << b;   /* urutan bit GBA */
    return k;
}

void retro_run(void) {
    bool upd = false;
    if (env_cb(RETRO_ENVIRONMENT_GET_VARIABLE_UPDATE, &upd) && upd) load_var();
    poll_cb();
    for (int i = 0; i < 2; i++) { inst[i].core->setKeys(inst[i].core, keys_for(i)); inst[i].core->runFrame(inst[i].core); }
    video_cb(inst[view].video, W, H, W * sizeof(color_t));
    struct mCore* c = inst[view].core;
    blip_t* l = c->getAudioChannel(c, 0); blip_t* r = c->getAudioChannel(c, 1);
    int n = blip_samples_avail(l); if (n > SAMPLES) n = SAMPLES;
    blip_read_samples(l, audioBuf, n, 1); blip_read_samples(r, audioBuf + 1, n, 1);
    audio_cb(audioBuf, n);
    for (int i = 0; i < 2; i++) if (i != view) { blip_clear(inst[i].core->getAudioChannel(inst[i].core, 0)); blip_clear(inst[i].core->getAudioChannel(inst[i].core, 1)); }
}

void retro_reset(void) { for (int i = 0; i < 2; i++) { inst[i].core->reset(inst[i].core); inst[i].node.pending = 0; } }

/* Serialisasi: [A][B][pending A,B]. Dipakai netplay rollback (dan hash sinkron antar HP). */
size_t retro_serialize_size(void) { return inst[0].core->stateSize(inst[0].core) * 2 + 8; }
bool retro_serialize(void* data, size_t size) {
    size_t s = inst[0].core->stateSize(inst[0].core); uint8_t* p = data;
    if (size < s * 2 + 8) return false;
    inst[0].core->saveState(inst[0].core, p); inst[1].core->saveState(inst[1].core, p + s);
    int32_t pend[2] = { inst[0].node.pending, inst[1].node.pending }; memcpy(p + 2 * s, pend, 8);
    return true;
}
bool retro_unserialize(const void* data, size_t size) {
    size_t s = inst[0].core->stateSize(inst[0].core); const uint8_t* p = data;
    if (size < s * 2 + 8) return false;
    inst[0].core->loadState(inst[0].core, p); inst[1].core->loadState(inst[1].core, p + s);
    int32_t pend[2]; memcpy(pend, p + 2 * s, 8); inst[0].node.pending = pend[0]; inst[1].node.pending = pend[1];
    return true;
}

/* Save RAM yang dilihat aplikasi = GBA 1 (A). Save GBA 2 ditulis ke <rom>.link2.sav saat game ditutup. */
void* retro_get_memory_data(unsigned id) { return id == RETRO_MEMORY_SAVE_RAM ? inst[0].save : NULL; }
size_t retro_get_memory_size(unsigned id) { return id == RETRO_MEMORY_SAVE_RAM ? 0x20000 : 0; }

void retro_cheat_reset(void) {}
void retro_cheat_set(unsigned i, bool e, const char* c) { (void) i; (void) e; (void) c; }
unsigned retro_get_region(void) { return RETRO_REGION_NTSC; }
