# Core libretro "mgba_link" (GBA Link Cable, 2 instance). Dibangun terpisah dari core mGBA biasa; hasilnya
# libmgba_link_libretro_android.so. Dipanggil oleh scripts/build_mgba_link_core.sh (NDK + sumber mGBA 0.10.x).
cmake_minimum_required(VERSION 3.16)
project(mgba_link C)

set(MGBA_SRC "" CACHE PATH "Folder sumber mGBA")
if(NOT MGBA_SRC)
  message(FATAL_ERROR "Isi -DMGBA_SRC=<folder sumber mGBA>")
endif()

# mGBA: hanya inti GBA, statis, tanpa dependensi opsional.
foreach(opt BUILD_QT BUILD_SDL BUILD_GL BUILD_GLES2 BUILD_GLES3 BUILD_SHARED BUILD_LIBRETRO BUILD_PERF BUILD_TEST
            BUILD_EXAMPLE BUILD_SUITE BUILD_UPDATER BUILD_HEADLESS USE_FFMPEG USE_PNG USE_LIBZIP USE_MINIZIP USE_SQLITE3 USE_ELF
            USE_LUA USE_DISCORD_RPC USE_EDITLINE USE_ZLIB USE_LZMA USE_EPOXY M_CORE_GB ENABLE_SCRIPTING ENABLE_GDB_STUB)
  set(${opt} OFF CACHE BOOL "" FORCE)
endforeach()
set(BUILD_STATIC ON CACHE BOOL "" FORCE)
set(M_CORE_GBA ON CACHE BOOL "" FORCE)
set(DISABLE_DEPS ON CACHE BOOL "" FORCE)
set(SKIP_LIBRARY OFF CACHE BOOL "" FORCE)

# NDK (API 21+) sudah mendeklarasikan strtof_l sebagai static inline, jadi check_function_exists mGBA gagal
# menemukannya (tidak ada simbol link) lalu formatting.c mendefinisikannya lagi -> "redefinition of 'strtof_l'".
# Paksa HAVE_STRTOF_L supaya mGBA memakai versi bawaan NDK. (Dipasang SEBELUM add_subdirectory.)
set(HAVE_STRTOF_L ON CACHE BOOL "" FORCE)
add_compile_definitions(HAVE_STRTOF_L)

add_subdirectory(${MGBA_SRC} mgba EXCLUDE_FROM_ALL)

add_library(mgba_link_libretro SHARED link_core.c)
set_target_properties(mgba_link_libretro PROPERTIES OUTPUT_NAME mgba_link_libretro_android)   # -> libmgba_link_libretro_android.so
target_include_directories(mgba_link_libretro PRIVATE
  ${CMAKE_CURRENT_SOURCE_DIR}/third_party
  ${MGBA_SRC}/include ${MGBA_SRC}/src
  ${CMAKE_BINARY_DIR}/mgba ${CMAKE_BINARY_DIR}/mgba/include)
if(TARGET mgba-static)
  target_link_libraries(mgba_link_libretro PRIVATE mgba-static)
elseif(TARGET mgba)
  target_link_libraries(mgba_link_libretro PRIVATE mgba)
else()
  message(FATAL_ERROR "Target pustaka mGBA tidak ditemukan")
endif()
target_link_libraries(mgba_link_libretro PRIVATE m log)
target_link_options(mgba_link_libretro PRIVATE -Wl,--exclude-libs,ALL -Wl,-z,max-page-size=16384)
