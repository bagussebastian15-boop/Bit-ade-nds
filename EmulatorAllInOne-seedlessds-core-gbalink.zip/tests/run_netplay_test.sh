#!/usr/bin/env bash
# Uji logika rollback di komputer (tanpa Android): game palsu + simulasi lag/packet loss lewat loopback.
set -euo pipefail
cd "$(dirname "$0")/.."
CPP=libretrodroid-netplay/overlay/libretrodroid/src/main/cpp
g++ -std=c++17 -O1 -Wall -pthread -I"$CPP" "$CPP/netplay.cpp" tests/netplay_test.cpp -o /tmp/netplay_test
/tmp/netplay_test
