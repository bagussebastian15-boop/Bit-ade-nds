#include "netplay.h"
#include <atomic>
#include <cstdio>
#include <cstring>
#include <thread>
#include <vector>
#include <unistd.h>
using namespace libretrodroid;

struct Game { uint64_t s = 12345; uint32_t frame = 0; uint8_t pad[4096 - 16] = {0}; };

struct Side {
    Game g; std::vector<uint64_t> hist = std::vector<uint64_t>(5000, 0);
    int runs = 0, resims = 0; Netplay* np = nullptr; int player = 0;
    Netplay::CoreHooks hooks() {
        Netplay::CoreHooks h;
        h.stateSize = [] { return sizeof(Game); };
        h.save = [this](void* d, size_t n) { memcpy(d, &g, n); return true; };
        h.load = [this](const void* d, size_t n) { memcpy(&g, d, n); return true; };
        h.run = [this](bool visible) {
            uint64_t m[2] = {0, 0};
            for (int p = 0; p < 2; p++) for (int id = 0; id < 16; id++) m[p] |= (uint64_t)(np->coreInput(p, id) & 1) << id;
            g.s = g.s * 6364136223846793005ULL + m[0] * 1315423911ULL + m[1] * 2654435761ULL + 1442695040888963407ULL;
            g.frame++; hist[g.frame] = g.s; if (visible) runs++; else resims++;
        };
        return h;
    }
};

static uint16_t script(int player, int f) { return (uint16_t)((((f / 5) + 1) * (player ? 2246822519u : 2654435761u)) >> 7); }

static int runCase(const char* name, uint16_t port, int latency, int loss, int target) {
    Side a, b; a.player = 0; b.player = 1;
    Netplay host(a.hooks(), port, 0xABCD, 2), guest(b.hooks(), port, 0xABCD, 2);
    a.np = &host; b.np = &guest;
    host.debugLatencyMs = guest.debugLatencyMs = latency;
    host.debugLossPercent = guest.debugLossPercent = loss;
    if (!host.startHost()) { printf("host gagal\n"); return 1; }
    if (!guest.startJoin("127.0.0.1")) { printf("join gagal\n"); return 1; }
    std::atomic<bool> stop{false};
    auto loop = [&](Netplay& np) {
        while (!stop) {
            // sebelum RUNNING: local game berjalan normal (di sini: tidak ada), jadi tick saja
            np.tick(script(np.localPlayer(), np.currentFrame()));
            usleep(5000);
        }
    };
    std::thread t1(loop, std::ref(host)), t2(loop, std::ref(guest));
    for (int i = 0; i < 4000 && !(host.currentFrame() >= target && guest.currentFrame() >= target); i++) usleep(5000);
    int ca = host.currentFrame(), cb = guest.currentFrame();
    stop = true; t1.join(); t2.join();

    // referensi
    std::vector<uint64_t> ref(target + 2); uint64_t s = 12345;
    for (int f = 0; f < target + 1; f++) {
        auto in = [&](int p) { return f < 2 ? 0 : script(p, f - 2); };
        s = s * 6364136223846793005ULL + (uint64_t)in(0) * 1315423911ULL + (uint64_t)in(1) * 2654435761ULL + 1442695040888963407ULL;
        ref[f + 1] = s;
    }
    int verified = std::min(host.verifiedFrame(), guest.verifiedFrame());
    int bad = 0;
    for (int f = 1; f <= verified && f <= target; f++) if (a.hist[f] != ref[f] || b.hist[f] != ref[f]) bad++;
    printf("[%s] frame host=%d guest=%d verified=%d resim(host/guest)=%d/%d ping=%d desync=%d/%d status=%d/%d err=%d/%d -> %s\n",
        name, ca, cb, verified, a.resims, b.resims, host.pingMs(), host.desync(), guest.desync(),
        host.status(), guest.status(), host.error(), guest.error(),
        (bad == 0 && verified >= target - 12 && !host.desync() && !guest.desync()) ? "OK" : "GAGAL");
    return (bad == 0 && verified >= target - 12 && !host.desync() && !guest.desync()) ? 0 : 1;
}

int main() {
    int fail = 0;
    fail += runCase("tanpa lag", 41001, 0, 0, 600);
    fail += runCase("lag 20ms + loss 5%", 41002, 20, 5, 600);
    fail += runCase("lag 40ms + loss 10%", 41003, 40, 10, 600);
    // game berbeda harus ditolak
    {
        Side a, b; Netplay host(a.hooks(), 41004, 1, 2), guest(b.hooks(), 41004, 2, 2);
        a.np = &host; b.np = &guest; host.startHost(); guest.startJoin("127.0.0.1");
        for (int i = 0; i < 200 && guest.status() != Netplay::ENDED; i++) usleep(10000);
        bool ok = guest.error() == Netplay::ERR_GAME_MISMATCH;
        printf("[game beda] guest err=%d -> %s\n", guest.error(), ok ? "OK" : "GAGAL"); fail += ok ? 0 : 1;
    }
    printf(fail ? "ADA YANG GAGAL\n" : "SEMUA LULUS\n");
    return fail;
}
