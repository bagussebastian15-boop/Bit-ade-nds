package com.allinone.emulator.net;

import java.io.File;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.nio.file.Files;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/** Uji ZtEngine terhadap SDK palsu (tests/java/com/zerotier/sdk): proxy listener, penyimpanan, soket UDP, konversi tipe. */
public class ZtEngineTest {
    static int fails = 0;

    static void check(String name, Object got, Object want) {
        boolean ok = got == null ? want == null : got.equals(want);
        if (!ok) fails++;
        System.out.println((ok ? "ok    " : "GAGAL ") + name + (ok ? "" : " -> " + got + " (harusnya " + want + ")"));
    }

    public static void main(String[] args) throws Exception {
        System.setProperty("zt.skipnative", "true");
        check("available()", ZtEngine.available(), true);

        File dir = Files.createTempDirectory("zt-test").toFile();
        File outside = new File(dir.getParentFile(), "evil");
        outside.delete();

        DatagramSocket peer = new DatagramSocket(0, InetAddress.getByName("127.0.0.1"));
        peer.setSoTimeout(3000);
        com.zerotier.sdk.Node.peerPort = peer.getLocalPort();

        CountDownLatch gotNet = new CountDownLatch(1), gotFrame = new CountDownLatch(1), gotOnline = new CountDownLatch(1);
        CopyOnWriteArrayList<String> nets = new CopyOnWriteArrayList<>();
        CopyOnWriteArrayList<String> frames = new CopyOnWriteArrayList<>();
        final boolean[] protectedCalled = {false};
        final String[] cbThread = {""};

        ZtEngine.Listener l = new ZtEngine.Listener() {
            public void onNetwork(long nwid, String name, String status, long mac, int ip, int prefix, int mtu) {
                nets.add(String.format("%016x|%s|%s|%x|%s|%d|%d", nwid, name, status, mac,
                        (ip >>> 24) + "." + ((ip >> 16) & 255) + "." + ((ip >> 8) & 255) + "." + (ip & 255), prefix, mtu));
                cbThread[0] = Thread.currentThread().getName();
                gotNet.countDown();
            }
            public void onFrame(long nwid, long src, long dst, int type, byte[] f) {
                frames.add(String.format("%016x|%x|%x|%04x|%s", nwid, src, dst, type, new String(f)));
                gotFrame.countDown();
            }
            public void onOnline(boolean o) { if (o) gotOnline.countDown(); }
            public void onLog(String m) { System.out.println("      log: " + m); }
        };

        ZtEngine e = new ZtEngine(dir, s -> protectedCalled[0] = true, l);
        e.start();
        check("soket dilindungi dari VPN", protectedCalled[0], true);
        check("node ID dari address()", e.nodeId(), "89e92ceee5");
        check("identity.secret tersimpan", new File(dir, "identity.secret").isFile(), true);
        check("identity.public tersimpan", new File(dir, "identity.public").isFile(), true);
        check("peers.d/ (subfolder) tersimpan", new File(dir, "peers.d/aabbccddee.peer").isFile(), true);
        check("peekNodeId", ZtEngine.peekNodeId(dir), "89e92ceee5");
        check("path traversal ../ ditolak", com.zerotier.sdk.Node.putTraversal, -1);
        check("tidak ada file di luar folder", outside.exists(), false);
        check("get pertama: identitas belum ada", com.zerotier.sdk.Node.lastGetSize, -1L);

        long nwid = 0x8d1c312afa20d47eL;                       // bit tertinggi menyala: uji konversi long bertanda
        e.join(nwid);
        check("config jaringan diterima", gotNet.await(3, TimeUnit.SECONDS), true);
        check("isi config", nets.isEmpty() ? "" : nets.get(0), "8d1c312afa20d47e|Bit©ade|OK|29e92ceee51|10.147.17.5|24|2800");
        check("callback jaringan TIDAK jalan di thread inti (cegah kebuntuan saat join dengan config tersimpan)", cbThread[0], "zt-cb");
        check("event ONLINE", gotOnline.await(3, TimeUnit.SECONDS), true);

        e.subscribeArp(nwid, 0x0A931105);
        check("subscribe ARP (grup broadcast, ADI=IP)", com.zerotier.sdk.Node.lastSubscribe, "8d1c312afa20d47e/ffffffffffff/a931105");

        byte[] payload = "halo-dari-app".getBytes();
        e.sendFrame(nwid, 0x029e92ceee51L, 0x029e92ceee99L, 0x0800, payload);
        byte[] rb = new byte[2048];
        DatagramPacket rp = new DatagramPacket(rb, rb.length);
        peer.receive(rp);
        check("payload frame keluar lewat UDP", new String(rb, 0, rp.getLength()), "halo-dari-app");
        check("argumen processVirtualNetworkFrame", String.join("|", com.zerotier.sdk.Node.lastFrame), "8d1c312afa20d47e|29e92ceee51|29e92ceee99|800|13");

        byte[] in = "dari-jaringan".getBytes();
        peer.send(new DatagramPacket(in, in.length, InetAddress.getByName("127.0.0.1"), e.localPort()));
        check("frame masuk dari UDP", gotFrame.await(3, TimeUnit.SECONDS), true);
        check("isi frame masuk", frames.isEmpty() ? "" : frames.get(0), "8d1c312afa20d47e|29e92ceee99|29e92ceee51|0800|dari-jaringan");

        e.stop();
        check("Node.close() dipanggil", com.zerotier.sdk.Node.closed, true);

        // jalankan ulang dengan folder yang sama: identitas harus DIBACA lewat dataStoreGet (bukan dibuat ulang)
        ZtEngine e2 = new ZtEngine(dir, s -> { }, l);
        e2.start();
        check("start ulang: identity.secret terbaca (ukuran)", com.zerotier.sdk.Node.lastGetSize, (long) "89e92ceee5:0:rahasia".length());
        e2.stop();

        peer.close();
        System.out.println(fails == 0 ? "SEMUA LULUS" : fails + " GAGAL");
        System.exit(fails == 0 ? 0 : 1);
    }
}
