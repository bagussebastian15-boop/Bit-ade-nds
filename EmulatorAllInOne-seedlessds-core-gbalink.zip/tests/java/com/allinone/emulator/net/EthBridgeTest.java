package com.allinone.emulator.net;

import java.util.ArrayList;
import java.util.List;

/** Uji EthBridge tanpa Android: dua jembatan dihubungkan langsung (seperti dua HP di satu jaringan ZeroTier). */
public class EthBridgeTest {
    static int fails = 0;

    static void check(String name, Object got, Object want) {
        boolean ok = got == null ? want == null : got.equals(want);
        if (!ok) fails++;
        System.out.println((ok ? "ok    " : "GAGAL ") + name + (ok ? "" : " -> " + got + " (harusnya " + want + ")"));
    }

    static byte[] ipPacket(String src, String dst, int payload, int padding) {
        int total = 20 + payload;
        byte[] p = new byte[total + padding];
        p[0] = 0x45;
        p[2] = (byte) (total >> 8); p[3] = (byte) total;
        int s = EthBridge.parseIp(src), d = EthBridge.parseIp(dst);
        for (int i = 0; i < 4; i++) { p[12 + i] = (byte) (s >>> (24 - 8 * i)); p[16 + i] = (byte) (d >>> (24 - 8 * i)); }
        for (int i = 20; i < total; i++) p[i] = (byte) i;
        return p;
    }

    static class Node {
        final long mac; final String ip; EthBridge bridge; Node peer;
        final List<byte[]> tunOut = new ArrayList<>();
        final List<String> wire = new ArrayList<>();
        Node(long mac, String ip, int prefix) {
            this.mac = mac; this.ip = ip;
            bridge = new EthBridge(mac, EthBridge.parseIp(ip), prefix,
                (dst, src, type, payload) -> {
                    wire.add(String.format("%x>%x/%04x/%d", src, dst, type, payload.length));
                    if (peer != null && (dst == peer.mac || dst == EthBridge.BROADCAST || (dst >> 40 & 1) == 1))
                        peer.bridge.fromNet(src, dst, type, payload);
                },
                (b, off, len) -> { byte[] c = new byte[len]; System.arraycopy(b, off, c, 0, len); tunOut.add(c); });
        }
    }

    public static void main(String[] args) {
        Node a = new Node(0x020000000001L, "10.147.17.5", 24);
        Node b = new Node(0x020000000002L, "10.147.17.9", 24);
        a.peer = b; b.peer = a;

        byte[] pkt = ipPacket("10.147.17.5", "10.147.17.9", 40, 0);
        a.bridge.fromTun(pkt, pkt.length);
        check("paket tiba di TUN tujuan", b.tunOut.size(), 1);
        check("isi paket utuh", java.util.Arrays.equals(b.tunOut.get(0), pkt), true);
        check("urutan frame: ARP request, ARP reply, IPv4", a.wire.size() + "/" + b.wire.size(), "2/1");
        check("frame pertama = ARP broadcast", a.wire.get(0).contains("/0806/28"), true);

        a.wire.clear(); b.wire.clear(); b.tunOut.clear();
        a.bridge.fromTun(pkt, pkt.length);
        check("kirim kedua tanpa ARP lagi", a.wire.size() + "/" + b.tunOut.size(), "1/1");

        byte[] padded = ipPacket("10.147.17.9", "10.147.17.5", 10, 18);
        a.tunOut.clear();
        a.bridge.fromNet(b.mac, a.mac, EthBridge.ETH_IPV4, padded);
        check("padding Ethernet dibuang", a.tunOut.get(0).length, 30);

        byte[] other = ipPacket("10.147.17.9", "10.147.17.77", 10, 0);
        a.tunOut.clear();
        a.bridge.fromNet(b.mac, a.mac, EthBridge.ETH_IPV4, other);
        check("paket untuk IP lain diabaikan", a.tunOut.size(), 0);

        a.wire.clear();
        byte[] outside = ipPacket("10.147.17.5", "8.8.8.8", 10, 0);
        a.bridge.fromTun(outside, outside.length);
        check("tujuan di luar subnet dibuang", a.wire.size(), 0);

        a.wire.clear();
        byte[] bc = ipPacket("10.147.17.5", "10.147.17.255", 10, 0);
        a.bridge.fromTun(bc, bc.length);
        check("broadcast subnet -> MAC broadcast", a.wire.get(0).contains(">ffffffffffff/0800"), true);

        a.wire.clear();
        byte[] mc = ipPacket("10.147.17.5", "224.0.0.251", 10, 0);
        a.bridge.fromTun(mc, mc.length);
        check("multicast -> MAC 01:00:5e", a.wire.get(0).contains(">1005efb/0800") || a.wire.get(0).contains(">1005e0000fb/0800"), true);

        Node c = new Node(0x020000000003L, "10.147.17.20", 24);
        c.wire.clear();
        byte[] lone = ipPacket("10.147.17.20", "10.147.17.99", 10, 0);
        for (int i = 0; i < 20; i++) c.bridge.fromTun(lone, lone.length);
        check("ARP dibatasi lajunya (tanpa banjir)", c.wire.size(), 1);

        Node d = new Node(0x020000000004L, "10.147.17.30", 24), e = new Node(0x020000000005L, "10.147.17.31", 24);
        d.peer = e; e.peer = d;
        check("probe: belum ada jawaban sebelum ARP", d.bridge.macOf(EthBridge.parseIp("10.147.17.31")), 0L);
        d.bridge.probe(EthBridge.parseIp("10.147.17.31"));
        check("probe: ARP dijawab, MAC dikenal", d.bridge.macOf(EthBridge.parseIp("10.147.17.31")), 0x020000000005L);
        check("covers: dalam dan luar subnet", d.bridge.covers(EthBridge.parseIp("10.147.17.99")) + "/" + d.bridge.covers(EthBridge.parseIp("8.8.8.8")), "true/false");

        System.out.println(fails == 0 ? "SEMUA LULUS" : fails + " GAGAL");
        System.exit(fails == 0 ? 0 : 1);
    }
}
