package com.allinone.emulator.net;

import java.util.List;

/** Uji penemuan server lewat siaran: host mengumumkan, pemain lain menerima, tanpa Android dan tanpa ZeroTier. */
public class ZtDiscoveryTest {
    static int fails = 0;

    static void check(String name, Object got, Object want) {
        boolean ok = got == null ? want == null : got.equals(want);
        if (!ok) fails++;
        System.out.println((ok ? "ok    " : "GAGAL ") + name + (ok ? "" : " -> " + got + " (harusnya " + want + ")"));
    }

    static int ip(String s) { return EthBridge.parseIp(s); }

    static String names(List<ZtDiscovery.Player> l) {
        StringBuilder sb = new StringBuilder();
        for (ZtDiscovery.Player p : l) sb.append(sb.length() == 0 ? "" : ",").append(p.name);
        return sb.toString();
    }

    /** Server terbuka (tanpa invite) dari host berIP tertentu: kembalikan invite yang terbaca. */
    static String invite(String hostIpStr, int hostIp, int listener, long t) {
        ZtDiscovery.announce("Terbuka", "Game", "SNES", "x", 7755, 2);
        ZtDiscovery.handle(ZtDiscovery.buildPacket(hostIp, 24), listener, t);
        for (ZtDiscovery.Server s : ZtDiscovery.servers(t)) if (s.host.equals(hostIpStr)) return s.invite;
        return "NOT-FOUND";
    }

    public static void main(String[] args) {
        int host = ip("10.102.103.211"), me = ip("10.102.103.50");

        check("belum mengumumkan -> tidak ada paket", ZtDiscovery.buildPacket(host, 24), null);
        ZtDiscovery.announce("Bagus - Mortal Kombat", "Mortal Kombat", "ARCADE_MAME", "Bagus", 7755, 2);
        byte[] pkt = ZtDiscovery.buildPacket(host, 24);
        check("paket dibuat", pkt != null, true);
        check("tujuan = siaran subnet /24", ZtDiscovery.ipStr(EthBridge.ipToInt(pkt, 16)), "10.102.103.255");
        check("tujuan = siaran subnet /16", ZtDiscovery.ipStr(EthBridge.ipToInt(ZtDiscovery.buildPacket(host, 16), 16)), "10.102.255.255");
        check("prefix /32 -> 255.255.255.255", ZtDiscovery.ipStr(EthBridge.ipToInt(ZtDiscovery.buildPacket(host, 32), 16)), "255.255.255.255");
        check("sumber = IP host", ZtDiscovery.ipStr(EthBridge.ipToInt(pkt, 12)), "10.102.103.211");
        check("protokol UDP", pkt[9] & 0xff, 17);

        // checksum header IPv4 harus valid: jumlah seluruh word (termasuk checksum) = 0xffff
        int sum = 0;
        for (int i = 0; i < 20; i += 2) sum += ((pkt[i] & 0xff) << 8) | (pkt[i + 1] & 0xff);
        while ((sum >>> 16) != 0) sum = (sum & 0xffff) + (sum >>> 16);
        check("checksum header IPv4 valid", sum, 0xffff);

        long t = 1_000_000;
        check("paket sendiri diabaikan tapi dihabiskan", ZtDiscovery.handle(pkt, host, t), true);
        check("tidak masuk daftar sendiri", ZtDiscovery.servers(t).size(), 0);

        check("pemain lain menerima", ZtDiscovery.handle(pkt, me, t), true);
        List<ZtDiscovery.Server> l = ZtDiscovery.servers(t);
        check("satu server terdaftar", l.size(), 1);
        ZtDiscovery.Server s = l.get(0);
        check("alamat host", s.host + ":" + s.port, "10.102.103.211:7755");
        check("nama/judul/konsol/pemilik", s.name + "|" + s.title + "|" + s.console + "|" + s.owner,
            "Bagus - Mortal Kombat|Mortal Kombat|ARCADE_MAME|Bagus");
        check("pemain 1/2", s.players + "/" + s.max, "1/2");

        ZtDiscovery.setPlayers(2);
        ZtDiscovery.handle(ZtDiscovery.buildPacket(host, 24), me, t + 3000);
        check("pembaruan, bukan duplikat", ZtDiscovery.servers(t + 3000).size() + " " + ZtDiscovery.servers(t + 3000).get(0).players, "1 2");

        check("masih ada sebelum kedaluwarsa", ZtDiscovery.servers(t + 3000 + ZtDiscovery.TTL_MS).size(), 1);
        check("hilang setelah kedaluwarsa", ZtDiscovery.servers(t + 3001 + ZtDiscovery.TTL_MS).size(), 0);

        // paket bukan milik kita
        byte[] other = ZtDiscovery.buildPacket(host, 24).clone();
        other[22] = 0x1E; other[23] = 0x4B;                         // port tujuan lain
        check("port lain tidak dihabiskan", ZtDiscovery.handle(other, me, t), false);
        check("frame pendek tidak dihabiskan", ZtDiscovery.handle(new byte[10], me, t), false);
        check("null tidak dihabiskan", ZtDiscovery.handle(null, me, t), false);

        // paket rusak / isi aneh tidak boleh membuat server palsu atau melempar galat
        byte[] junk = ZtDiscovery.udpPacket(ip("10.102.103.9"), -1, 7756, 7756, "AIOSRV1\nport=99999\ntitle=x\nconsole=y\n".getBytes());
        check("port tidak sah ditolak", ZtDiscovery.handle(junk, me, t) + " " + ZtDiscovery.servers(t).size(), "true 0");
        byte[] nomagic = ZtDiscovery.udpPacket(ip("10.102.103.9"), -1, 7756, 7756, "hello".getBytes());
        check("tanpa tanda pengenal tidak dihabiskan", ZtDiscovery.handle(nomagic, me, t), false);

        // banjir: maksimal 64 server
        for (int i = 1; i <= 100; i++) {
            ZtDiscovery.stopAnnounce();
            ZtDiscovery.announce("S" + i, "Game", "SNES", "x", 7755, 2);
            ZtDiscovery.handle(ZtDiscovery.buildPacket(ip("10.102.103." + (i + 100)), 24), me, t);
        }
        check("dibatasi 64 server", ZtDiscovery.servers(t).size(), 64);

        ZtDiscovery.stopAnnounce();
        check("berhenti mengumumkan", ZtDiscovery.isAnnouncing(), false);

        // ---- kehadiran pemain (tanpa server) + ajakan ----
        ZtDiscovery.clearFound();
        check("belum ada identitas -> tidak ada paket kehadiran", ZtDiscovery.buildPresencePacket(host, 24), null);
        ZtDiscovery.setSelf("Bagus", "8d1c312afa");
        byte[] pres = ZtDiscovery.buildPresencePacket(host, 24);
        check("paket kehadiran dibuat", pres != null, true);
        check("kehadiran: tujuan siaran subnet", ZtDiscovery.ipStr(EthBridge.ipToInt(pres, 16)), "10.102.103.255");
        check("kehadiran sendiri dihabiskan", ZtDiscovery.handle(pres, host, t), true);
        check("tidak melihat diri sendiri", ZtDiscovery.players(t).size(), 0);
        check("pemain lain menerima kehadiran", ZtDiscovery.handle(pres, me, t), true);
        check("satu pemain terlihat", ZtDiscovery.players(t).size(), 1);
        ZtDiscovery.Player pl = ZtDiscovery.players(t).get(0);
        check("pemain: ip|nama|node", pl.ip + "|" + pl.name + "|" + pl.node, "10.102.103.211|Bagus|8d1c312afa");
        check("kehadiran bukan server", ZtDiscovery.servers(t).size(), 0);
        ZtDiscovery.handle(pres, me, t + 3000);
        check("kehadiran berulang = satu entri", ZtDiscovery.players(t + 3000).size(), 1);
        check("pemain masih ada sebelum kedaluwarsa", ZtDiscovery.players(t + 3000 + ZtDiscovery.TTL_MS).size(), 1);
        check("pemain hilang setelah kedaluwarsa", ZtDiscovery.players(t + 3001 + ZtDiscovery.TTL_MS).size(), 0);

        // tiga HP: A, B, C saling melihat
        ZtDiscovery.clearFound();
        int a = ip("10.102.103.1"), b = ip("10.102.103.2"), c = ip("10.102.103.3");
        ZtDiscovery.setSelf("A", "aaaaaaaaaa"); byte[] pa = ZtDiscovery.buildPresencePacket(a, 24);
        ZtDiscovery.setSelf("B", "bbbbbbbbbb"); byte[] pb = ZtDiscovery.buildPresencePacket(b, 24);
        ZtDiscovery.setSelf("C", "cccccccccc"); byte[] pc = ZtDiscovery.buildPresencePacket(c, 24);
        for (byte[] x : new byte[][] { pa, pb, pc }) ZtDiscovery.handle(x, c, t);   // HP C mendengar ketiganya (dirinya sendiri diabaikan)
        check("C melihat A dan B saja", names(ZtDiscovery.players(t)), "A,B");

        // ajakan: host mengumumkan server dengan invite = IP pemain tertentu
        ZtDiscovery.announce("A ajak B", "Mortal Kombat", "ARCADE_MAME", "A", 7755, 2, "10.102.103.2");
        ZtDiscovery.handle(ZtDiscovery.buildPacket(a, 24), b, t);
        ZtDiscovery.Server inv = ZtDiscovery.servers(t).get(0);
        check("ajakan terbaca di server", inv.invite, "10.102.103.2");
        check("server terbuka: invite kosong", invite("10.102.103.9", ip("10.102.103.9"), b, t), "");
        ZtDiscovery.stopAnnounce();

        // penanda GBA Link Cable ikut di siaran (hanya untuk GBA); klien lama tanpa field ini = bukan link
        ZtDiscovery.clearFound();
        ZtDiscovery.announce("Link", "Mario Kart", "GBA", "A", 7755, 2, "", true);
        ZtDiscovery.handle(ZtDiscovery.buildPacket(a, 24), b, t);
        check("siaran GBA link terbaca", ZtDiscovery.servers(t).get(0).link, true);
        ZtDiscovery.clearFound();
        ZtDiscovery.announce("Biasa", "Mario Kart", "GBA", "A", 7755, 2);
        ZtDiscovery.handle(ZtDiscovery.buildPacket(a, 24), b, t);
        check("siaran GBA biasa bukan link", ZtDiscovery.servers(t).get(0).link, false);
        ZtDiscovery.clearFound();
        ZtDiscovery.announce("Snes", "Game", "SNES", "A", 7755, 2, "", true);
        ZtDiscovery.handle(ZtDiscovery.buildPacket(a, 24), b, t);
        check("link diabaikan untuk non-GBA", ZtDiscovery.servers(t).get(0).link, false);
        ZtDiscovery.stopAnnounce();

        // paket kehadiran rusak tidak membuat pemain palsu / galat
        ZtDiscovery.clearFound();
        byte[] bad = ZtDiscovery.udpPacket(a, -1, 7756, 7756, "AIOPLR1\nname=\n".getBytes());
        check("kehadiran tanpa nama -> dipakai IP", ZtDiscovery.handle(bad, me, t) + " " + ZtDiscovery.players(t).get(0).name, "true 10.102.103.1");
        ZtDiscovery.clearFound();
        for (int i = 1; i <= 100; i++) ZtDiscovery.handle(ZtDiscovery.udpPacket(ip("10.102.104." + i), -1, 7756, 7756, ("AIOPLR1\nname=P" + i + "\n").getBytes()), me, t);
        check("pemain dibatasi 64", ZtDiscovery.players(t).size(), 64);
        ZtDiscovery.clearSelf();
        check("clearSelf -> tidak ada paket kehadiran", ZtDiscovery.buildPresencePacket(host, 24), null);

        System.out.println(fails == 0 ? "SEMUA LULUS" : fails + " GAGAL");
        if (fails != 0) System.exit(1);
    }
}
