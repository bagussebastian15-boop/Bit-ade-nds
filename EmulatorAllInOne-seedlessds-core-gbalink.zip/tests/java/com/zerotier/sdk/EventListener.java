package com.zerotier.sdk;
public interface EventListener { void onEvent(Event event); void onTrace(String message); }
