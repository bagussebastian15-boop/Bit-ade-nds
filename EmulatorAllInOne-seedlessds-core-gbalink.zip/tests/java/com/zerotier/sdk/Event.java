package com.zerotier.sdk;
public enum Event { EVENT_UP, EVENT_ONLINE, EVENT_OFFLINE }
