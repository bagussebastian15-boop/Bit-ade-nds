package com.zerotier.sdk;

import java.net.InetAddress;
import java.net.InetSocketAddress;

/** SDK PALSU untuk uji ZtEngine di komputer: meniru bentuk API Node asli (tanpa kriptografi/jaringan sungguhan). */
public class Node {
    public static volatile int peerPort;                 // soket penerima uji
    public static volatile long lastGetSize = -2;        // ukuran identity.secret yang terbaca lewat dataStoreGet
    public static volatile String[] lastFrame;           // frame terakhir dari aplikasi: nwid/src/dst/type/len
    public static volatile String lastSubscribe;
    public static volatile boolean closed;
    public static volatile int putTraversal = 99;        // hasil put("../evil")

    private DataStoreGetListener get; private DataStorePutListener put; private PacketSender sender;
    private EventListener events; private VirtualNetworkFrameListener frames; private VirtualNetworkConfigListener cfg;
    private final java.util.concurrent.ConcurrentLinkedQueue<Long> joined = new java.util.concurrent.ConcurrentLinkedQueue<>();

    public Node(long now) { }

    public ResultCode init(DataStoreGetListener g, DataStorePutListener p, PacketSender s, EventListener e,
                           VirtualNetworkFrameListener f, VirtualNetworkConfigListener c, PathChecker pc) {
        get = g; put = p; sender = s; events = e; frames = f; cfg = c;
        long[] size = new long[1];
        byte[] buf = new byte[64];
        long n = get.onDataStoreGet("identity.secret", buf, 0, size);
        lastGetSize = n < 0 ? -1 : size[0];
        if (n < 0) {                                       // identitas baru
            put.onDataStorePut("identity.secret", "89e92ceee5:0:rahasia".getBytes(), true);
            put.onDataStorePut("identity.public", "89e92ceee5:0:publik".getBytes(), false);
        }
        putTraversal = put.onDataStorePut("../evil", new byte[]{1}, false);
        put.onDataStorePut("peers.d/aabbccddee.peer", new byte[]{1, 2, 3}, false);
        return ResultCode.RESULT_OK;
    }

    public long address() { return 0x89e92ceee5L; }

    public ResultCode join(long nwid) { joined.add(nwid); return ResultCode.RESULT_OK; }
    public ResultCode leave(long nwid) { return ResultCode.RESULT_OK; }

    public ResultCode multicastSubscribe(long nwid, long group, long adi) {
        lastSubscribe = String.format("%x/%x/%x", nwid, group, adi);
        return ResultCode.RESULT_OK;
    }

    public ResultCode processBackgroundTasks(long now, long[] nextDeadline) {
        Long nw;
        while ((nw = joined.poll()) != null) {
            VirtualNetworkConfig c = new VirtualNetworkConfig();
            c.mac = 0x029e92ceee51L; c.name = "Bit©ade"; c.status = VirtualNetworkStatus.NETWORK_STATUS_OK; c.mtu = 2800;
            c.addrs = new InetSocketAddress[]{ new InetSocketAddress(ipv4(10, 147, 17, 5), 24) };
            cfg.onNetworkConfigurationUpdated(nw, VirtualNetworkConfigOperation.VIRTUAL_NETWORK_CONFIG_OPERATION_UP, c);
            events.onEvent(Event.EVENT_ONLINE);
        }
        nextDeadline[0] = now + 50;
        return ResultCode.RESULT_OK;
    }

    /** Frame dari aplikasi -> "dikirim ke jaringan" = paket UDP ke peer uji berisi payload frame. */
    public ResultCode processVirtualNetworkFrame(long now, long nwid, long src, long dst, long etherType, long vlan,
                                                 byte[] frame, long[] nextDeadline) {
        lastFrame = new String[]{Long.toHexString(nwid), Long.toHexString(src), Long.toHexString(dst), Long.toHexString(etherType), "" + frame.length};
        sender.onSendPacketRequested(-1, new InetSocketAddress(ipv4(127, 0, 0, 1), peerPort), frame, 0);
        nextDeadline[0] = now + 50;
        return ResultCode.RESULT_OK;
    }

    /** Paket UDP "dari jaringan" -> dijadikan frame Ethernet IPv4 ke aplikasi. */
    public ResultCode processWirePacket(long now, long localSocket, InetSocketAddress remote, byte[] data, long[] nextDeadline) {
        frames.onVirtualNetworkFrame(0x8d1c312afa20d47eL, 0x029e92ceee99L, 0x029e92ceee51L, 0x0800, 0, data);
        nextDeadline[0] = now + 50;
        return ResultCode.RESULT_OK;
    }

    public void close() { closed = true; }

    private static InetAddress ipv4(int a, int b, int c, int d) {
        try { return InetAddress.getByAddress(new byte[]{(byte) a, (byte) b, (byte) c, (byte) d}); }
        catch (Exception e) { throw new RuntimeException(e); }
    }
}
