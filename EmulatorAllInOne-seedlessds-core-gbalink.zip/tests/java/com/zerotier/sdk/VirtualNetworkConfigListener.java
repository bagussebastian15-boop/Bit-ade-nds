package com.zerotier.sdk;
public interface VirtualNetworkConfigListener { int onNetworkConfigurationUpdated(long networkId, VirtualNetworkConfigOperation op, VirtualNetworkConfig config); }
