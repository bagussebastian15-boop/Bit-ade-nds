package com.zerotier.sdk;
import java.net.InetSocketAddress;
public interface PathChecker { boolean onPathCheck(long address, InetSocketAddress addr); InetSocketAddress onPathLookup(long address, int family); }
