package com.zerotier.sdk;
import java.net.InetSocketAddress;
public interface PacketSender { int onSendPacketRequested(long localSocket, InetSocketAddress remoteAddr, byte[] packetData, int ttl); }
